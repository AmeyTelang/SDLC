from __future__ import annotations

import re

_ACTIONS_PY = (
    "click",
    "dblclick",
    "fill",
    "check",
    "uncheck",
    "hover",
    "press",
    "type",
    "tap",
    "select_option",
    "set_input_files",
    "focus",
    "scroll_into_view_if_needed",
    "drag_to",
    "clear",
    "wait_for",
)
_ACTIONS_TS = (
    "click",
    "dblclick",
    "fill",
    "check",
    "uncheck",
    "hover",
    "press",
    "type",
    "tap",
    "selectOption",
    "setInputFiles",
    "focus",
    "scrollIntoViewIfNeeded",
    "dragTo",
    "clear",
    "waitFor",
)
_HAS_PIN = (".first", ".nth(", ".last")
_HAS_LOCATOR = ("get_by", "getby", ".locator(")


def _has_locator(line: str) -> bool:
    low = line.lower()
    return any(tok in low for tok in _HAS_LOCATOR)


def _already_pinned(line: str) -> bool:
    return any(p in line for p in _HAS_PIN)


def _match_close(line: str, open_idx: int) -> int:
    depth = 0
    for k in range(open_idx, len(line)):
        if line[k] == "(":
            depth += 1
        elif line[k] == ")":
            depth -= 1
            if depth == 0:
                return k
    return -1


def _harden_action_line(line: str, actions, pin: str) -> str:
    if not _has_locator(line) or _already_pinned(line):
        return line
    for a in actions:
        tok = "." + a + "("
        i = line.find(tok)
        if i != -1:
            return line[:i] + pin + line[i:]
    return line


def _harden_expect_line(line: str, pin: str) -> str:
    if "expect(" not in line or not _has_locator(line) or _already_pinned(line):
        return line
    start = line.find("expect(")
    open_idx = start + len("expect")
    close_idx = _match_close(line, open_idx)
    if close_idx == -1:
        return line
    return line[:close_idx] + pin + line[close_idx:]


def _inject_timeout_py(script: str) -> str:
    if "set_default_timeout" in script:
        return script
    lines = script.splitlines()
    for idx, ln in enumerate(lines):
        if re.match(r"\s*def\s+test_\w*\s*\(.*\)\s*:", ln):
            indent = (
                re.match(r"(\s*)", lines[idx + 1]).group(1)
                if idx + 1 < len(lines)
                else "    "
            )
            indent = indent or "    "
            lines.insert(idx + 1, f"{indent}page.set_default_timeout(30000)")
            break
    return "\n".join(lines)


def _inject_timeout_ts(script: str) -> str:
    if "setDefaultTimeout" in script:
        return script
    lines = script.splitlines()
    for idx, ln in enumerate(lines):
        if "async ({" in ln and "page" in ln and "=> {" in ln:
            lines.insert(idx + 1, "  page.setDefaultTimeout(30000);")
            break
    return "\n".join(lines)


def harden_script(script: str, language: str) -> str:
    if not script:
        return script
    is_py = str(language).lower().startswith("py")
    actions = _ACTIONS_PY if is_py else _ACTIONS_TS
    pin = ".first" if is_py else ".first()"
    out = []
    for line in script.splitlines():
        line = _harden_action_line(line, actions, pin)
        line = _harden_expect_line(line, pin)
        out.append(line)
    hardened = "\n".join(out)
    return _inject_timeout_py(hardened) if is_py else _inject_timeout_ts(hardened)
