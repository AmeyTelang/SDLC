"""HITL approval registry for the TestGenX Web Studio.

Lifecycle
---------
    DRAFT -> PENDING -> APPROVED -> EXECUTED
                     \
                      -> CHANGES_REQUESTED -> (regenerate) -> DRAFT (iter + 1)

Delta in this version
---------------------
Fixes the orphaned change request. Two guarantees:

1. `request()` reuses the SAME record when the test_id is pinned, so a
   revision increments `iteration` and clears `feedback` rather than creating
   a parallel record.
2. `supersede_duplicates()` retires any older record for the same logical
   test that an earlier build orphaned — so pre-existing stale cards
   disappear on the next regeneration instead of lingering forever.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

DRAFT = "draft"
PENDING = "pending"
APPROVED = "approved"
CHANGES_REQUESTED = "changes_requested"
REJECTED = "rejected"
EXECUTED = "executed"
SUPERSEDED = "superseded"

LEAD_QUEUE_STATUSES = (PENDING, APPROVED)
# SUPERSEDED is deliberately absent -> retired cards vanish from My Scripts.
ENGINEER_STATUSES = (DRAFT, PENDING, CHANGES_REQUESTED, APPROVED)


@dataclass
class ReviewEvent:
    at: datetime
    actor: str
    action: str
    comment: Optional[str] = None
    iteration: int = 1

    def to_dict(self) -> dict:
        return {
            "at": self.at.isoformat() + "Z",
            "actor": self.actor,
            "action": self.action,
            "comment": self.comment,
            "iteration": self.iteration,
        }


@dataclass
class ApprovalRecord:
    test_id: str
    approval_id: str
    title: str
    file_name: str
    project_id: Optional[str]
    project_name: Optional[str]
    language: str
    step_count: int
    iteration: int
    requested_by: Optional[str] = None
    artifact: dict = field(default_factory=dict, repr=False)
    source: dict = field(default_factory=dict, repr=False)
    status: str = DRAFT
    approver: Optional[str] = None
    comment: Optional[str] = None
    feedback: Optional[str] = None  # OPEN change request
    addressed_feedback: Optional[str] = None  # RESOLVED change request
    superseded_by: Optional[str] = None
    history: List[ReviewEvent] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    submitted_at: Optional[datetime] = None
    decided_at: Optional[datetime] = None
    executed_at: Optional[datetime] = None
    _event: threading.Event = field(default_factory=threading.Event, repr=False)

    def summary(self) -> dict:
        return {
            "test_id": self.test_id,
            "approval_id": self.approval_id,
            "title": self.title,
            "file_name": self.file_name,
            "project_id": self.project_id,
            "project_name": self.project_name,
            "language": self.language,
            "step_count": self.step_count,
            "iteration": self.iteration,
            "requested_by": self.requested_by,
            "status": self.status,
            "approver": self.approver,
            "comment": self.comment,
            "feedback": self.feedback,
            "addressed_feedback": self.addressed_feedback,
            "superseded_by": self.superseded_by,
            "created_at": self.created_at.isoformat() + "Z",
            "submitted_at": (
                self.submitted_at.isoformat() + "Z" if self.submitted_at else None
            ),
            "decided_at": (
                self.decided_at.isoformat() + "Z" if self.decided_at else None
            ),
            "executed_at": (
                self.executed_at.isoformat() + "Z" if self.executed_at else None
            ),
            "history": [h.to_dict() for h in self.history],
            "source": self.source,
        }

    def to_dict(self) -> dict:
        return {**self.summary(), "artifact": self.artifact}

    def _log(self, actor, action, comment=None):
        self.history.append(
            ReviewEvent(
                at=datetime.utcnow(),
                actor=actor or "system",
                action=action,
                comment=comment or None,
                iteration=self.iteration,
            )
        )


class ApprovalGate:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._records: Dict[str, ApprovalRecord] = {}
        self._iterations: Dict[str, int] = {}

    # ------------------------------------------------------------------
    # 1. Generation — same test_id == same record, iteration + 1
    # ------------------------------------------------------------------
    def request(
        self,
        test_id: str,
        *,
        title: str = "",
        file_name: str = "",
        project_id: Optional[str] = None,
        project_name: Optional[str] = None,
        language: str = "python",
        step_count: int = 0,
        artifact: Optional[dict] = None,
        source: Optional[dict] = None,
        requested_by: Optional[str] = None,
    ) -> ApprovalRecord:
        with self._lock:
            previous = self._records.get(test_id)
            iteration = self._iterations.get(test_id, 0) + 1
            self._iterations[test_id] = iteration

            rec = ApprovalRecord(
                test_id=test_id,
                approval_id=uuid.uuid4().hex[:12],
                title=title,
                file_name=file_name,
                project_id=project_id,
                project_name=project_name,
                language=language,
                step_count=step_count,
                iteration=iteration,
                requested_by=requested_by
                or (previous.requested_by if previous else None),
                artifact=artifact or {},
                source=source or (previous.source if previous else {}),
                status=DRAFT,
            )

            actor = rec.requested_by or "engineer"
            was_returned = bool(previous and previous.status == CHANGES_REQUESTED)
            resolved = previous.feedback if was_returned else None

            if previous:
                rec.history = list(previous.history)

            # The open change request is now RESOLVED.
            rec.feedback = None
            rec.addressed_feedback = resolved
            rec._log(actor, "revised" if was_returned else "generated", resolved)

            self._records[test_id] = rec
            return rec

    # ------------------------------------------------------------------
    # Retire orphaned records for the same logical test.
    # ------------------------------------------------------------------
    def supersede_duplicates(
        self,
        keep_test_id: str,
        *,
        owner: Optional[str] = None,
        title: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> List[str]:
        """Mark older records for the same test as SUPERSEDED.

        Guards against records orphaned by a build that minted a new test_id
        per generation: same owner + same title + same project, but a
        different id. Returns the retired ids so the client can drop them.
        """
        if not title:
            return []
        retired: List[str] = []
        key = title.strip().lower()

        with self._lock:
            keeper = self._records.get(keep_test_id)
            for tid, r in list(self._records.items()):
                if tid == keep_test_id:
                    continue
                if r.status in (EXECUTED, SUPERSEDED, REJECTED):
                    continue
                if owner and r.requested_by != owner:
                    continue
                if project_id and r.project_id != project_id:
                    continue
                if (r.title or "").strip().lower() != key:
                    continue

                r.status = SUPERSEDED
                r.superseded_by = keep_test_id
                r.feedback = None
                r._log("system", "superseded", f"Replaced by {keep_test_id}")
                retired.append(tid)

                # Carry the oldest history forward so the trail survives.
                if keeper and len(r.history) > len(keeper.history):
                    keeper.history = list(r.history) + [
                        h
                        for h in keeper.history
                        if h.action in ("generated", "revised")
                    ]
        return retired

    # ------------------------------------------------------------------
    # 2. Engineer submits
    # ------------------------------------------------------------------
    def submit(
        self, test_id: str, submitted_by: str = "engineer", note: str = ""
    ) -> ApprovalRecord:
        with self._lock:
            rec = self._records.get(test_id)
            if rec is None:
                raise KeyError(f"No generated script found for test '{test_id}'.")
            if rec.status not in (DRAFT, CHANGES_REQUESTED):
                raise ValueError(
                    f"Script '{test_id}' is '{rec.status}' and cannot be submitted."
                )
            rec.status = PENDING
            rec.submitted_at = datetime.utcnow()
            rec.comment = note or None
            rec.feedback = None
            rec._event.clear()
            rec._log(submitted_by, "submitted", note)
            return rec

    def withdraw(self, test_id: str, actor: str = "engineer") -> ApprovalRecord:
        with self._lock:
            rec = self._records.get(test_id)
            if rec is None:
                raise KeyError(f"No approval request found for test '{test_id}'.")
            if rec.status != PENDING:
                raise ValueError("Only a pending script can be withdrawn.")
            rec.status = DRAFT
            rec.submitted_at = None
            rec._log(actor, "withdrawn")
            return rec

    # ------------------------------------------------------------------
    # 3. Lead decision
    # ------------------------------------------------------------------
    def approve(self, test_id, approver="Test Lead", comment="") -> ApprovalRecord:
        return self._decide(test_id, APPROVED, approver, comment, "approved")

    def send_back(
        self, test_id: str, approver: str = "Test Lead", feedback: str = ""
    ) -> ApprovalRecord:
        with self._lock:
            rec = self._records.get(test_id)
            if rec is None:
                raise KeyError(f"No approval request found for test '{test_id}'.")
            if rec.status != PENDING:
                return rec
            rec.status = CHANGES_REQUESTED
            rec.approver = approver or "Test Lead"
            rec.feedback = feedback or None
            rec.addressed_feedback = None
            rec.comment = feedback or None
            rec.decided_at = datetime.utcnow()
            rec._event.set()
            rec._log(approver, "sent_back", feedback)
            return rec

    def reject(self, test_id, approver="Test Lead", comment="") -> ApprovalRecord:
        return self._decide(test_id, REJECTED, approver, comment, "rejected")

    def _decide(self, test_id, status, approver, comment, action) -> ApprovalRecord:
        with self._lock:
            rec = self._records.get(test_id)
            if rec is None:
                raise KeyError(f"No approval request found for test '{test_id}'.")
            if rec.status != PENDING:
                return rec
            rec.status = status
            rec.approver = approver or "Test Lead"
            rec.comment = comment or None
            rec.decided_at = datetime.utcnow()
            rec._event.set()
            rec._log(approver, action, comment)
            return rec

    # ------------------------------------------------------------------
    # 4. Execution
    # ------------------------------------------------------------------
    def wait(self, test_id: str, timeout: Optional[float] = None) -> ApprovalRecord:
        rec = self.get(test_id)
        if rec is None:
            raise KeyError(f"No approval request found for test '{test_id}'.")
        rec._event.wait(timeout)
        return rec

    def assert_approved(self, test_id: str) -> ApprovalRecord:
        rec = self.get(test_id)
        if rec is None:
            raise PermissionError(
                f"Execution blocked: no approval request exists for '{test_id}'."
            )
        if rec.status == DRAFT:
            raise PermissionError(
                f"Execution blocked: '{test_id}' is still a draft and has not been "
                "submitted for review."
            )
        if rec.status == CHANGES_REQUESTED:
            raise PermissionError(
                f"Execution blocked: the Test Lead returned '{test_id}' for regeneration."
            )
        if rec.status == SUPERSEDED:
            raise PermissionError(
                f"Execution blocked: '{test_id}' was replaced by a newer revision."
            )
        if rec.status not in (APPROVED, EXECUTED):
            raise PermissionError(
                f"Execution blocked: script '{test_id}' is '{rec.status}'; "
                "Test Lead approval is required before hand-off."
            )
        return rec

    def mark_executed(self, test_id: str) -> Optional[ApprovalRecord]:
        with self._lock:
            rec = self._records.get(test_id)
            if rec is None:
                return None
            rec.status = EXECUTED
            rec.executed_at = datetime.utcnow()
            rec._log(rec.approver or "system", "executed")
            return rec

    # ------------------------------------------------------------------
    # 5. Queries
    # ------------------------------------------------------------------
    def get(self, test_id: str) -> Optional[ApprovalRecord]:
        if not test_id:
            return None
        with self._lock:
            return self._records.get(test_id)

    def queue(self, project_id: Optional[str] = None) -> List[dict]:
        with self._lock:
            items = [
                r
                for r in self._records.values()
                if r.status in LEAD_QUEUE_STATUSES
                and (project_id is None or r.project_id == project_id)
            ]
        items.sort(key=lambda r: r.submitted_at or r.created_at, reverse=True)
        return [r.summary() for r in items]

    def my_scripts(self, email: str) -> List[dict]:
        with self._lock:
            items = [
                r
                for r in self._records.values()
                if r.requested_by == email and r.status in ENGINEER_STATUSES
            ]
        items.sort(key=lambda r: r.created_at, reverse=True)
        return [r.summary() for r in items]

    def open_change_requests(self, email: str) -> List[dict]:
        with self._lock:
            return [
                r.summary()
                for r in self._records.values()
                if r.requested_by == email and r.status == CHANGES_REQUESTED
            ]

    def artifact(self, test_id: str) -> Optional[dict]:
        rec = self.get(test_id)
        return rec.to_dict() if rec else None

    def all(self) -> List[dict]:
        with self._lock:
            return [r.summary() for r in self._records.values()]

    def discard(self, test_id: str) -> None:
        with self._lock:
            self._records.pop(test_id, None)


approval_gate = ApprovalGate()
