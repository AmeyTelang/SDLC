"""Natural language -> Playwright script.

Division of responsibility
--------------------------
* ``step_intelligence`` (LLM) may only *clarify wording* of steps that the
  deterministic translator cannot compile. It can never change step count,
  order, or a step's literal values - those invariants are enforced in code.
* This module (deterministic) is the sole author of the emitted script. No
  model output is ever executed. That is what makes the generated artefact
  reviewable and reproducible for a validated environment.

The result carries a confidence score so the engineer can see, before
submitting, how much of the script rests on inference rather than explicit
instruction.
"""

from __future__ import annotations

import ast
import logging
import re
import uuid
from datetime import datetime
from typing import List, Optional

from agents import harden, locator_rules
from agents.step_intelligence import step_intelligence
from models.schemas import (
    GenerateRequest,
    GenerateResponse,
    TargetLanguage,
    TestCaseStep,
)

logger = logging.getLogger("testgenx.generation")

ASSERT_TIMEOUT_MS = 30000
DEFAULT_TIMEOUT_MS = 30000

ASSERT_MARKERS = (
    "verify",
    "assert",
    "should",
    "expect",
    "confirm",
    "ensure",
    "check that",
)


def _esc(value: str) -> str:
    return (value or "").replace("\\", "\\\\").replace('"', '\\"').strip()


class GenerationAgent:
    name = "generation"

    # ==================================================================
    # Public
    # ==================================================================
    def generate(self, req: GenerateRequest) -> GenerateResponse:
        test_id = uuid.uuid4().hex[:12]

        # Project context for configurable locator rules (scoped by url / id).
        self._project = {
            "id": getattr(req, "project_id", None),
            "aut_url": (req.base_url or ""),
        }

        # 1) Deterministic parse, then LLM clarification of ambiguous steps only.
        raw_steps = self._parse_steps(req.natural_language_steps)
        source = "deterministic"
        confidence = 1.0
        clarified = 0
        step_meta: List[dict] = []

        if raw_steps:
            texts = [s.action for s in raw_steps]
            refined, step_meta, confidence = step_intelligence.refine(
                texts,
                title=req.title,
                base_url=req.base_url or "",
                story_key=getattr(req, "jira_issue_key", "") or "",
            )
            clarified = sum(1 for m in step_meta if m.get("changed"))
            if clarified:
                source = "llm-assisted"
                raw_steps = [
                    TestCaseStep(
                        index=i, action=text, expectation=self._expectation(text)
                    )
                    for i, text in enumerate(refined, start=1)
                ]

        # 2) ALWAYS build the executable script deterministically.
        try:
            if req.language == TargetLanguage.PYTHON:
                script = self._build_python(req, test_id, raw_steps)
            else:
                script = self._build_ts(req, test_id, raw_steps)
        except Exception as exc:
            logger.error("Builder failed (%s); emitting minimal script.", exc)
            script = self._minimal_script(req, test_id)

        # 3) Strict-mode hardening (best-effort).
        try:
            script = harden.harden_script(script, req.language.value)
        except Exception as exc:
            logger.warning("harden failed (%s); using unhardened script.", exc)

        # 4) Final safety net: guarantee the Python script parses.
        if req.language == TargetLanguage.PYTHON:
            try:
                ast.parse(script)
            except Exception as exc:
                logger.error("Generated Python invalid (%s); using minimal.", exc)
                script = self._minimal_script(req, test_id)

        unmapped = script.count("TODO manual mapping needed")
        if unmapped and raw_steps:
            confidence = round(
                min(confidence, max(0.15, 1.0 - (unmapped / len(raw_steps)))), 3
            )

        extension = "py" if req.language == TargetLanguage.PYTHON else "spec.ts"
        slug = (
            re.sub(r"[^a-zA-Z0-9]+", "_", req.title.strip().lower()).strip("_")
            or "test"
        )

        return GenerateResponse(
            test_id=test_id,
            title=req.title,
            language=req.language,
            structured_steps=raw_steps,
            script=script,
            file_name=f"{slug}_{test_id}.{extension}",
            generated_by=source,
            confidence=confidence,
            steps_clarified=clarified,
            unmapped_steps=unmapped,
            step_analysis=step_meta,
            created_at=datetime.utcnow(),
        )

    # ==================================================================
    # Step parsing
    # ==================================================================
    @staticmethod
    def _expectation(line: str) -> Optional[str]:
        return line if any(k in line.lower() for k in ASSERT_MARKERS) else None

    def _parse_steps(self, text: str) -> List[TestCaseStep]:
        lines = [l.strip(" \t-*.0123456789)") for l in (text or "").splitlines()]
        lines = [l for l in lines if l]
        return [
            TestCaseStep(index=i, action=l, expectation=self._expectation(l))
            for i, l in enumerate(lines, start=1)
        ]

    # ==================================================================
    # Locator helpers
    # ==================================================================
    @staticmethod
    def _find_url(line: str) -> Optional[str]:
        match = re.search(r"https?://[^\s\"']+", line)
        return match.group(0) if match else None

    _ROLE_WORDS = {
        "button": "button",
        "link": "link",
        "tab": "tab",
        "menu": "menuitem",
        "menuitem": "menuitem",
        "option": "option",
        "item": "menuitem",
    }

    # Built-in fallback rule used ONLY when no external config file provides a
    # match. Add more apps via backend/config/locator_rules.json (no code change).
    _BUILTIN_RULES = [
        {
            "id": "builtin-saucedemo-cart",
            "scope": {"aut_url": "saucedemo"},
            "when": {
                "action": "click",
                "any": ["shopping cart", "cart icon", "the cart", "cart"],
            },
            "not": ["add to cart", "remove"],
            "locator": {
                "css": '.shopping_cart_link, #shopping_cart_container a, a[data-test="shopping-cart-link"]'
            },
        },
    ]

    def _rule_click(self, target: str, indent: str, py: bool):
        project = getattr(self, "_project", None)
        code = locator_rules.click_code(target, indent, py, project)
        if code:
            return code
        recipe = locator_rules.match_rule(
            "click", target, project, rules=self._BUILTIN_RULES
        )
        locator = locator_rules.recipe_to_locator(recipe, py) if recipe else None
        if locator:
            return indent + (
                f"{locator}.click()" if py else f"await {locator}.click();"
            )
        return None

    def _rule_visible(self, target: str, indent: str, py: bool, timeout: int):
        project = getattr(self, "_project", None)
        code = locator_rules.visible_code(target, indent, py, timeout, project)
        if code:
            return code
        recipe = locator_rules.match_rule(
            "visible", target, project, rules=self._BUILTIN_RULES
        )
        locator = locator_rules.recipe_to_locator(recipe, py) if recipe else None
        if not locator:
            return None
        if py:
            return indent + f"expect({locator}).to_be_visible(timeout={timeout})"
        return (
            indent + f"await expect({locator}).toBeVisible({{ timeout: {timeout} }});"
        )

    def _loc_clickable(self, target: str, py: bool, role: Optional[str] = None) -> str:
        text = _esc(target)
        order = ["button", "link", "tab", "text"]
        if role:
            order = (
                [role] + [r for r in ["button", "link", "tab"] if r != role] + ["text"]
            )

        def one(kind: str) -> str:
            if kind == "text":
                return (
                    f'page.get_by_text("{text}")' if py else f'page.getByText("{text}")'
                )
            if py:
                return f'page.get_by_role("{kind}", name="{text}")'
            return f'page.getByRole("{kind}", {{ name: "{text}" }})'

        if py:
            chain = one(order[0])
            for kind in order[1:]:
                chain += f".or_({one(kind)})"
            return chain + ".first"

        chain = one(order[0])
        for kind in order[1:]:
            chain += f".or({one(kind)})"
        return chain + ".first()"

    def _loc_field(self, field: str, py: bool) -> str:
        text = _esc(field)
        if py:
            return (
                f'page.get_by_label("{text}")'
                f'.or_(page.get_by_placeholder("{text}"))'
                f'.or_(page.get_by_role("textbox", name="{text}")).first'
            )
        return (
            f'page.getByLabel("{text}")'
            f'.or(page.getByPlaceholder("{text}"))'
            f'.or(page.getByRole("textbox", {{ name: "{text}" }})).first()'
        )

    def _loc_text(self, value: str, py: bool) -> str:
        text = _esc(value)
        return (
            f'page.get_by_text("{text}").first'
            if py
            else f'page.getByText("{text}").first()'
        )

    def _loc_checkbox(self, label: str, py: bool) -> str:
        text = _esc(label)
        if py:
            return (
                f'page.get_by_role("checkbox", name="{text}")'
                f'.or_(page.get_by_label("{text}")).first'
            )
        return (
            f'page.getByRole("checkbox", {{ name: "{text}" }})'
            f'.or(page.getByLabel("{text}")).first()'
        )

    # ==================================================================
    # Core translator
    # ==================================================================
    def _line_to_code(self, line: str, indent: str, lang: TargetLanguage) -> str:
        py = lang == TargetLanguage.PYTHON
        s = line.strip()
        low = s.lower()
        is_assert = any(k in low for k in ASSERT_MARKERS) or "see" in low

        def wrap(code_py: str, code_ts: str) -> str:
            return indent + (code_py if py else code_ts)

        def multi(lines_py: List[str], lines_ts: List[str]) -> str:
            return "\n".join(indent + l for l in (lines_py if py else lines_ts))

        # ---- Navigation ----
        url = self._find_url(s)
        if (not is_assert) and any(
            k in low
            for k in ("open", "navigate", "go to", "visit", "browse to", "launch")
        ):
            if url:
                return wrap(f'page.goto("{url}")', f'await page.goto("{url}");')
            return wrap("pass  # already at base URL", "// already at base URL")

        if (not is_assert) and re.search(r"\b(reload|refresh)\b", low):
            return wrap("page.reload()", "await page.reload();")
        if (not is_assert) and ("go back" in low or low.strip() == "back"):
            return wrap("page.go_back()", "await page.goBack();")
        if (not is_assert) and ("go forward" in low or "navigate forward" in low):
            return wrap("page.go_forward()", "await page.goForward();")

        # ---- Login (portable across SauceDemo / Heroku / standard forms) ----
        creds = re.search(r"username\s+([^\s]+).*?password\s+([^\s]+)", s, re.I)
        if (not is_assert) and "login" in low and creds:
            user, password = _esc(creds.group(1)), _esc(creds.group(2))
            return multi(
                [
                    f'page.locator("#user-name, #username, input[name=\\"username\\"], input[name=\\"user\\"], input[type=\\"email\\"]")'
                    f'.or_(page.get_by_placeholder("Username")).or_(page.get_by_label("Username")).first.fill("{user}")',
                    f'page.locator("#password, input[name=\\"password\\"], input[type=\\"password\\"]")'
                    f'.or_(page.get_by_placeholder("Password")).or_(page.get_by_label("Password")).first.fill("{password}")',
                    'page.locator("#login-button, button[type=\\"submit\\"], input[type=\\"submit\\"]")'
                    '.or_(page.get_by_role("button", name=re.compile("log ?in|sign ?in|submit", re.I))).first.click()',
                ],
                [
                    f'await page.locator("#user-name, #username, input[name=\\"username\\"], input[name=\\"user\\"], input[type=\\"email\\"]")'
                    f'.or(page.getByPlaceholder("Username")).or(page.getByLabel("Username")).first().fill("{user}");',
                    f'await page.locator("#password, input[name=\\"password\\"], input[type=\\"password\\"]")'
                    f'.or(page.getByPlaceholder("Password")).or(page.getByLabel("Password")).first().fill("{password}");',
                    'await page.locator("#login-button, button[type=\\"submit\\"], input[type=\\"submit\\"]")'
                    '.or(page.getByRole("button", { name: /log ?in|sign ?in|submit/i })).first().click();',
                ],
            )

        # ---- Upload (hidden input) ----
        if (
            (not is_assert)
            and re.match(r"\s*upload\b", low)
            and not re.search(r"\b(click|press|tap|choose|select|hit)\b", low)
        ):
            match = re.search(
                r"""upload\s+(?:the\s+)?(?:file\s+)?['"]([^'"]+)['"]""", s, re.I
            ) or re.search(
                r"upload\s+(?:the\s+)?(?:file\s+)?(\S.+?)(?:\s+(?:to|into|in|using|via)\b.*)?$",
                s,
                re.I,
            )
            if match:
                path = _esc(match.group(1).strip().strip("'\""))
                if not path or path.lower() in ("a file", "file", "the file"):
                    return wrap(
                        "# TODO manual mapping needed: provide a real file path",
                        "// TODO manual mapping needed: provide a real file path",
                    )
                return wrap(
                    f'page.locator("input[type=\\"file\\"]").first.set_input_files(r"{path}")',
                    f'await page.locator("input[type=\\"file\\"]").first().setInputFiles("{path}");',
                )

        if not is_assert:
            # ---- Select dropdown option ----
            match = re.search(
                r'select\s+"?([^"]+?)"?\s+(?:from|in)\s+"?([^"]+?)"?$', s, re.I
            )
            if match:
                option, field = _esc(match.group(1)), match.group(2)
                return wrap(
                    f'{self._loc_field(field, True)}.select_option(label="{option}")',
                    f'await {self._loc_field(field, False)}.selectOption({{ label: "{option}" }});',
                )

            # ---- Check / uncheck ----
            match = re.search(
                r'\b(check|tick|enable)\b\s+(?:the\s+)?"?([^"]+?)"?(?:\s+checkbox)?$',
                s,
                re.I,
            )
            if match and "checkout" not in low:
                box = match.group(2)
                return wrap(
                    f"{self._loc_checkbox(box, True)}.check()",
                    f"await {self._loc_checkbox(box, False)}.check();",
                )
            match = re.search(
                r'\b(uncheck|untick|disable)\b\s+(?:the\s+)?"?([^"]+?)"?(?:\s+checkbox)?$',
                s,
                re.I,
            )
            if match:
                box = match.group(2)
                return wrap(
                    f"{self._loc_checkbox(box, True)}.uncheck()",
                    f"await {self._loc_checkbox(box, False)}.uncheck();",
                )

            # ---- Fill / type / enter ----
            match = re.search(
                r'(?:type|enter|input|fill)\s+"?([^"]+?)"?\s+(?:in|into|for)\s+(?:the\s+)?"?([^"]+?)"?(?:\s+field)?$',
                s,
                re.I,
            )
            if match:
                value, field = _esc(match.group(1)), match.group(2)
                return wrap(
                    f'{self._loc_field(field, True)}.fill("{value}")',
                    f'await {self._loc_field(field, False)}.fill("{value}");',
                )
            match = re.search(
                r'fill\s+(?:the\s+)?"?([^"]+?)"?\s+(?:field\s+)?with\s+"?([^"]+?)"?$',
                s,
                re.I,
            )
            if match:
                field, value = match.group(1), _esc(match.group(2))
                return wrap(
                    f'{self._loc_field(field, True)}.fill("{value}")',
                    f'await {self._loc_field(field, False)}.fill("{value}");',
                )

            # ---- Clear field ----
            match = re.search(r'clear\s+(?:the\s+)?"?([^"]+?)"?(?:\s+field)?$', s, re.I)
            if match:
                field = match.group(1)
                return wrap(
                    f"{self._loc_field(field, True)}.clear()",
                    f"await {self._loc_field(field, False)}.clear();",
                )

            # ---- Press key ----
            match = re.search(
                r'press\s+(?:the\s+)?"?(enter|tab|escape|esc|space|backspace|'
                r'arrow\s?up|arrow\s?down|arrow\s?left|arrow\s?right|[a-z0-9])"?\s*(?:key)?$',
                s,
                re.I,
            )
            if match:
                key = match.group(1).strip().title().replace(" ", "")
                key = {"Esc": "Escape"}.get(key, key)
                return wrap(
                    f'page.keyboard.press("{key}")',
                    f'await page.keyboard.press("{key}");',
                )

            # ---- Hover ----
            match = re.search(r'hover\s+(?:over\s+|on\s+)?"?([^"]+?)"?$', s, re.I)
            if match:
                target = match.group(1)
                return wrap(
                    f"{self._loc_clickable(target, True)}.hover()",
                    f"await {self._loc_clickable(target, False)}.hover();",
                )

            # ---- Double / right click ----
            match = re.search(r'double[- ]?click\s+(?:on\s+)?"?([^"]+?)"?$', s, re.I)
            if match:
                target = match.group(1)
                return wrap(
                    f"{self._loc_clickable(target, True)}.dblclick()",
                    f"await {self._loc_clickable(target, False)}.dblclick();",
                )
            match = re.search(r'right[- ]?click\s+(?:on\s+)?"?([^"]+?)"?$', s, re.I)
            if match:
                target = match.group(1)
                return wrap(
                    f'{self._loc_clickable(target, True)}.click(button="right")',
                    f'await {self._loc_clickable(target, False)}.click({{ button: "right" }});',
                )

            # ---- Generic click (role-aware) ----
            match = re.search(
                r'(?:click|tap|press|choose)\s+(?:on\s+)?(?:the\s+)?"?([^"]+?)"?'
                r"(?:\s+(button|link|tab|menu|menuitem|option|item))?$",
                s,
                re.I,
            )
            if match:
                target = match.group(1)
                role = (
                    self._ROLE_WORDS.get((match.group(2) or "").lower())
                    if match.group(2)
                    else None
                )
                configured = self._rule_click(target, indent, py)
                if configured:
                    return configured
                return wrap(
                    f"{self._loc_clickable(target, True, role)}.click()",
                    f"await {self._loc_clickable(target, False, role)}.click();",
                )

            # ---- Wait ----
            match = re.search(
                r"wait\s+(?:for\s+)?(\d+)\s*(?:s|sec|second|seconds|ms|millisecond|milliseconds)?",
                s,
                re.I,
            )
            if match and ("wait for " + match.group(1)) in low:
                amount = int(match.group(1))
                ms = amount if ("ms" in low or "millisecond" in low) else amount * 1000
                return wrap(
                    f"page.wait_for_timeout({ms})", f"await page.waitForTimeout({ms});"
                )
            match = re.search(
                r'wait\s+for\s+"?([^"]+?)"?(?:\s+to\s+(?:appear|be visible))?$', s, re.I
            )
            if match and not re.match(r"^\d+$", match.group(1).strip()):
                target = match.group(1)
                return wrap(
                    f'{self._loc_text(target, True)}.wait_for(state="visible", timeout={ASSERT_TIMEOUT_MS})',
                    f'await {self._loc_text(target, False)}.waitFor({{ state: "visible", timeout: {ASSERT_TIMEOUT_MS} }});',
                )

            # ---- Scroll ----
            match = re.search(r'scroll\s+(?:to\s+|into view\s+)?"?([^"]+?)"?$', s, re.I)
            if match and "down" not in low and "up" not in low:
                target = match.group(1)
                return wrap(
                    f"{self._loc_text(target, True)}.scroll_into_view_if_needed()",
                    f"await {self._loc_text(target, False)}.scrollIntoViewIfNeeded();",
                )
            if "scroll down" in low:
                return wrap(
                    "page.mouse.wheel(0, 800)", "await page.mouse.wheel(0, 800);"
                )
            if "scroll up" in low:
                return wrap(
                    "page.mouse.wheel(0, -800)", "await page.mouse.wheel(0, -800);"
                )

            # ---- Dialogs ----
            if re.search(r"\b(accept|confirm)\b.*\b(alert|dialog|popup|prompt)\b", low):
                return wrap(
                    'page.once("dialog", lambda d: d.accept())',
                    'page.once("dialog", d => d.accept());',
                )
            if re.search(r"\b(dismiss|cancel)\b.*\b(alert|dialog|popup|prompt)\b", low):
                return wrap(
                    'page.once("dialog", lambda d: d.dismiss())',
                    'page.once("dialog", d => d.dismiss());',
                )

        # ---- Assertions ----
        if is_assert:
            code = self._assertion_to_code(s, indent, py)
            if code is not None:
                return code

        return wrap(
            f"# TODO manual mapping needed: {s}", f"// TODO manual mapping needed: {s}"
        )

    # ------------------------------------------------------------------
    def _assertion_to_code(self, s: str, indent: str, py: bool) -> Optional[str]:
        timeout = ASSERT_TIMEOUT_MS
        low = s.lower()

        def wrap(code_py: str, code_ts: str) -> str:
            return indent + (code_py if py else code_ts)

        body = re.sub(
            r"^(verify|assert|confirm|expect|ensure|check that|should( see)?|see)\s+(that\s+)?",
            "",
            s,
            flags=re.I,
        ).strip()

        # File uploader / dropzone present -> attached (hidden input safe)
        if re.search(
            r"\b(file\s*uploader|upload\s*control|dropzone|drop\s*zone|file\s*input|uploader)\b",
            s,
            re.I,
        ):
            return wrap(
                'expect(page.locator("input[type=\\"file\\"]")'
                '.or_(page.get_by_text(re.compile("drop files|browse|upload", re.I)))'
                f".first).to_be_attached(timeout={timeout})",
                'await expect(page.locator("input[type=\\"file\\"]")'
                ".or(page.getByText(/drop files|browse|upload/i))"
                f".first()).toBeAttached({{ timeout: {timeout} }});",
            )

        # URL contains
        match = re.search(
            r'\b(url|address)\b.*?(?:contains|includes|has|is|=)\s+"?([^"]+?)"?$',
            body,
            re.I,
        )
        if match:
            fragment = re.escape(_esc(match.group(2)))
            return wrap(
                f'expect(page).to_have_url(re.compile(r".*{fragment}.*"), timeout={timeout})',
                f"await expect(page).toHaveURL(/.*{fragment}.*/, {{ timeout: {timeout} }});",
            )

        # Title
        match = re.search(
            r'\btitle\b.*?(?:contains|includes|has|is|=)\s+"?([^"]+?)"?$', body, re.I
        )
        if match:
            title = _esc(match.group(1))
            if "contains" in low or "includes" in low:
                return wrap(
                    f'expect(page).to_have_title(re.compile(r"{re.escape(title)}"), timeout={timeout})',
                    f"await expect(page).toHaveTitle(/{re.escape(title)}/, {{ timeout: {timeout} }});",
                )
            return wrap(
                f'expect(page).to_have_title("{title}", timeout={timeout})',
                f'await expect(page).toHaveTitle("{title}", {{ timeout: {timeout} }});',
            )

        # Field value
        match = re.search(
            r'"?([^"]+?)"?\s+(?:field\s+)?(?:has|contains|shows|equals?|=)\s+'
            r'(?:the\s+)?(?:value\s+)?"?([^"]+?)"?$',
            body,
            re.I,
        )
        if match and re.search(r"\b(field|input|value|textbox)\b", low):
            field, value = match.group(1), _esc(match.group(2))
            return wrap(
                f'expect({self._loc_field(field, True)}).to_have_value("{value}", timeout={timeout})',
                f'await expect({self._loc_field(field, False)}).toHaveValue("{value}", {{ timeout: {timeout} }});',
            )

        # Count
        match = re.search(
            r'(?:there\s+are\s+|shows?\s+|displays?\s+|has\s+)?(\d+)\s+"?([^"]+?)"?'
            r"(?:\s+(?:items|rows|results|elements|are\s+shown|visible))?$",
            body,
            re.I,
        )
        if match and re.search(
            r"\b(\d+)\s+(items|rows|results|elements|products|links)\b", low
        ):
            count, thing = match.group(1), _esc(match.group(2))
            locator = self._loc_text(thing, py)
            return wrap(
                f"expect({locator}).to_have_count({count}, timeout={timeout})",
                f"await expect({locator}).toHaveCount({count}, {{ timeout: {timeout} }});",
            )

        # Enabled / disabled
        if re.search(r"\bdisabled\b", low):
            target = re.sub(r"\bis\s+disabled\b.*$", "", body, flags=re.I).strip(" \"'")
            return wrap(
                f"expect({self._loc_clickable(target, True)}).to_be_disabled(timeout={timeout})",
                f"await expect({self._loc_clickable(target, False)}).toBeDisabled({{ timeout: {timeout} }});",
            )
        if re.search(r"\benabled\b", low):
            target = re.sub(r"\bis\s+enabled\b.*$", "", body, flags=re.I).strip(" \"'")
            return wrap(
                f"expect({self._loc_clickable(target, True)}).to_be_enabled(timeout={timeout})",
                f"await expect({self._loc_clickable(target, False)}).toBeEnabled({{ timeout: {timeout} }});",
            )

        # Checked / unchecked
        if re.search(r"\bunchecked\b|\bnot\s+checked\b", low):
            target = re.sub(r"\bis\s+(un)?checked\b.*$", "", body, flags=re.I).strip(
                " \"'"
            )
            return wrap(
                f"expect({self._loc_checkbox(target, True)}).not_to_be_checked(timeout={timeout})",
                f"await expect({self._loc_checkbox(target, False)}).not.toBeChecked({{ timeout: {timeout} }});",
            )
        if re.search(r"\bchecked\b", low):
            target = re.sub(r"\bis\s+checked\b.*$", "", body, flags=re.I).strip(" \"'")
            return wrap(
                f"expect({self._loc_checkbox(target, True)}).to_be_checked(timeout={timeout})",
                f"await expect({self._loc_checkbox(target, False)}).toBeChecked({{ timeout: {timeout} }});",
            )

        # Negative visibility
        if re.search(
            r"\b(not\s+(visible|shown|displayed|present)|hidden|disappears?|is\s+gone|removed)\b",
            low,
        ):
            target = re.sub(
                r"\b(is\s+)?(not\s+)?(visible|shown|displayed|present|hidden|gone|removed)\b.*$",
                "",
                body,
                flags=re.I,
            ).strip(" \"'")
            return wrap(
                f"expect({self._loc_text(target, True)}).to_be_hidden(timeout={timeout})",
                f"await expect({self._loc_text(target, False)}).toBeHidden({{ timeout: {timeout} }});",
            )

        # Positive visibility (default)
        target = re.sub(
            r"\s+is\s+(visible|shown|displayed|present)\.?$", "", body, flags=re.I
        ).strip(" \"'")
        target = re.sub(
            r"\s+(is\s+)?(visible|shown|displayed|present)\.?$", "", target, flags=re.I
        ).strip(" \"'")
        if not target:
            return None

        configured = self._rule_visible(target, indent, py, timeout)
        if configured:
            return configured

        return wrap(
            f"expect({self._loc_text(target, True)}).to_be_visible(timeout={timeout})",
            f"await expect({self._loc_text(target, False)}).toBeVisible({{ timeout: {timeout} }});",
        )

    # ==================================================================
    # Script assembly
    # ==================================================================
    @staticmethod
    def _evidence_slug(text: str) -> str:
        return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")[:40] or "step"

    def _minimal_script(self, req: GenerateRequest, test_id: str) -> str:
        base = (req.base_url or "").strip()
        NL = chr(10)

        if req.language == TargetLanguage.PYTHON:
            fn = "test_" + (
                re.sub(r"[^a-z0-9]+", "_", req.title.lower()).strip("_") or "generated"
            )
            lines = [
                "import os",
                "from playwright.sync_api import Page, expect",
                "",
                "",
                f"def {fn}(page: Page):",
                f'    os.makedirs(r"evidence/{test_id}", exist_ok=True)',
                f"    page.set_default_timeout({DEFAULT_TIMEOUT_MS})",
            ]
            if base:
                lines.append(f'    page.goto("{base}")')
            lines.append(
                f'    page.screenshot(path=r"evidence/{test_id}/step_01_open.png", full_page=True)'
            )
            return NL.join(lines) + NL

        label = _esc(req.title) or "Generated test"
        lines = [
            'import { test, expect } from "@playwright/test";',
            "",
            f'test("{label}", async ({{ page }}) => {{',
            f"  page.setDefaultTimeout({DEFAULT_TIMEOUT_MS});",
        ]
        if base:
            lines.append(f'  await page.goto("{base}");')
        lines.append(
            f'  await page.screenshot({{ path: "evidence/{test_id}/step_01_open.png", fullPage: true }});'
        )
        lines.append("});")
        return NL.join(lines) + NL

    def _build_python(self, req, test_id, steps) -> str:
        base = (req.base_url or "").strip()
        NL = chr(10)
        fn = "test_" + (
            re.sub(r"[^a-z0-9]+", "_", req.title.lower()).strip("_") or "generated"
        )

        out: List[str] = [
            '"""Auto-generated by TestGenX (deterministic engine).',
            "Each step runs defensively: a full-page screenshot is captured for",
            "every step (even on failure), remaining steps still execute, and the",
            'test fails at the end if any step failed."""',
            "import os",
            "import re",
            "from playwright.sync_api import Page, expect",
            "",
            "",
            f"def {fn}(page: Page):",
            f'    _EV = r"evidence/{test_id}"',
            "    os.makedirs(_EV, exist_ok=True)",
            f"    page.set_default_timeout({DEFAULT_TIMEOUT_MS})",
            "    _failures = []",
            "",
            "    def _capture(_n, _slug):",
            "        try:",
            '            page.screenshot(path=os.path.join(_EV, f"step_{_n:02d}_{_slug}.png"), full_page=True)',
            "        except Exception:",
            "            pass",
            "",
            "    def _run(_n, _name, _slug, _fn):",
            "        try:",
            "            _fn()",
            "        except Exception as _e:",
            '            _failures.append(f"Step {_n} - {_name}: {type(_e).__name__}: {_e}")',
            "        finally:",
            "            _capture(_n, _slug)",
            "",
        ]

        if base:
            out += [
                f'    page.goto("{base}")',
                "    try:",
                '        page.wait_for_load_state("networkidle", timeout=15000)',
                "    except Exception:",
                "        pass",
                "",
            ]

        for step in steps:
            slug = self._evidence_slug(step.action)
            name = _esc(step.action)[:120]
            code = self._line_to_code(step.action, "        ", req.language)
            if all(
                (not line.strip()) or line.strip().startswith("#")
                for line in code.splitlines()
            ):
                code += NL + "        pass"
            out += [
                f"    # Step {step.index}: {step.action}",
                f"    def _s{step.index}():",
                code,
                f'    _run({step.index}, "{name}", "{slug}", _s{step.index})',
                "",
            ]

        out.append(
            '    assert not _failures, "One or more steps failed: " + " | ".join(_failures)'
        )
        return NL.join(out) + NL

    def _build_ts(self, req, test_id, steps) -> str:
        base = (req.base_url or "").strip()
        NL = chr(10)
        label = _esc(req.title) or "Generated test"

        out: List[str] = [
            "// Auto-generated by TestGenX (deterministic engine).",
            "// Each step runs defensively: a screenshot is captured for every step",
            "// (even on failure); the test fails at the end if any step failed.",
            'import { test, expect } from "@playwright/test";',
            "",
            f'test("{label}", async ({{ page }}) => {{',
            f'  const _EV = "evidence/{test_id}";',
            "  const _failures = [];",
            f"  page.setDefaultTimeout({DEFAULT_TIMEOUT_MS});",
            '  const _pad = (n) => String(n).padStart(2, "0");',
            "  const _capture = async (n, slug) => {",
            "    try { await page.screenshot({ path: `${_EV}/step_${_pad(n)}_${slug}.png`, fullPage: true }); } catch (e) {}",
            "  };",
            "  const _run = async (n, name, slug, fn) => {",
            "    try { await fn(); } catch (e) { _failures.push(`Step ${n} - ${name}: ${e}`); }",
            "    finally { await _capture(n, slug); }",
            "  };",
        ]

        if base:
            out += [
                f'  await page.goto("{base}");',
                '  try { await page.waitForLoadState("networkidle", { timeout: 15000 }); } catch (e) {}',
            ]

        for step in steps:
            slug = self._evidence_slug(step.action)
            name = _esc(step.action)[:120]
            code = self._line_to_code(step.action, "    ", req.language)
            out += [
                f"  // Step {step.index}: {step.action}",
                f'  await _run({step.index}, "{name}", "{slug}", async () => {{',
                code,
                "  });",
            ]

        out.append(
            '  if (_failures.length) throw new Error("One or more steps failed: " + _failures.join(" | "));'
        )
        out.append("});")
        return NL.join(out) + NL


generation_agent = GenerationAgent()
