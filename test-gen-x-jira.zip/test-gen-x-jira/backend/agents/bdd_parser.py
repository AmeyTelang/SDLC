"""Deterministic Gherkin / BDD extraction from a JIRA story description.

Why a deterministic parser sits in front of the LLM
---------------------------------------------------
Accuracy is the requirement, so the model is never asked to *find* the
acceptance criteria - only to turn criteria we have already located into
executable test steps. This module produces the ground truth the synthesiser
is graded against:

* it normalises Atlassian Document Format (ADF), wiki markup and plain text
  into lines;
* it isolates the acceptance-criteria region of the description;
* it parses Feature / Background / Scenario / Scenario Outline / Examples and
  the Given-When-Then-And-But step keywords;
* it expands ``Scenario Outline`` placeholders against each ``Examples`` row,
  so a parameterised scenario becomes one concrete scenario per example.

Everything here is pure and side-effect free, which makes it directly
unit-testable and lets ``story_agent`` use it as both a pre-processor and a
coverage oracle.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

STEP_KEYWORDS = ("given", "when", "then", "and", "but")

_AC_HEADINGS = (
    "acceptance criteria",
    "acceptance criterion",
    "acceptance-criteria",
    "ac:",
    "acceptance tests",
    "definition of done",
)

_STOP_HEADINGS = (
    "technical notes",
    "out of scope",
    "dependencies",
    "attachments",
    "design notes",
    "non-functional",
    "assumptions",
    "open questions",
)

_BULLET = re.compile(r"^\s*(?:[-*\u2022\u25cf\u25aa]|\d+[.)])\s+")
_TAG = re.compile(r"^\s*@[\w-]+(\s+@[\w-]+)*\s*$")
_TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
_PLACEHOLDER = re.compile(r"<\s*([^<>]+?)\s*>")


# ----------------------------------------------------------------------
# Description normalisation
# ----------------------------------------------------------------------
def _adf_to_lines(node: Any, out: List[str]) -> None:
    """Flatten an Atlassian Document Format tree into text lines."""
    if node is None:
        return
    if isinstance(node, list):
        for item in node:
            _adf_to_lines(item, out)
        return
    if not isinstance(node, dict):
        return

    node_type = node.get("type")

    if node_type == "text":
        if out:
            out[-1] += node.get("text", "")
        else:
            out.append(node.get("text", ""))
        return
    if node_type == "hardBreak":
        out.append("")
        return
    if node_type in ("paragraph", "heading", "listItem", "tableRow", "codeBlock"):
        out.append("")
        _adf_to_lines(node.get("content"), out)
        return
    if node_type == "tableCell" or node_type == "tableHeader":
        cell: List[str] = [""]
        _adf_to_lines(node.get("content"), cell)
        text = " ".join(part.strip() for part in cell if part.strip())
        if out:
            out[-1] = (out[-1] + " | " + text).strip(" |") if out[-1] else text
        else:
            out.append(text)
        return

    _adf_to_lines(node.get("content"), out)


def normalise_description(description: Any) -> str:
    """Accept ADF, wiki markup or plain text; always return plain text."""
    if description is None:
        return ""

    if isinstance(description, dict):
        lines: List[str] = []
        _adf_to_lines(description, lines)
        text = "\n".join(lines)
    elif isinstance(description, (list, tuple)):
        text = "\n".join(str(part) for part in description)
    else:
        text = str(description)

    # Wiki / markdown decorations that carry no meaning for parsing.
    text = re.sub(r"\{code(:[^}]*)?\}|\{noformat\}|\{quote\}", "", text)
    text = re.sub(r"^\s*h[1-6]\.\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*#{1,6}\s*", "", text, flags=re.MULTILINE)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    return text.strip()


def _strip_decoration(line: str) -> str:
    line = _BULLET.sub("", line)
    line = line.strip()
    line = re.sub(r"^\*+\s*|\s*\*+$", "", line).strip()
    return line


# ----------------------------------------------------------------------
# Acceptance-criteria isolation
# ----------------------------------------------------------------------
def extract_acceptance_criteria(text: str) -> str:
    """Return the acceptance-criteria region, or the whole text if unlabelled."""
    if not text:
        return ""

    lines = text.split("\n")
    start: Optional[int] = None

    for idx, raw in enumerate(lines):
        probe = _strip_decoration(raw).lower().rstrip(":").strip()
        if any(probe.startswith(heading.rstrip(":")) for heading in _AC_HEADINGS):
            start = idx + 1
            break

    if start is None:
        # No explicit heading: if the body already reads as Gherkin, use it all.
        return text if _looks_like_gherkin(text) else text

    end = len(lines)
    for idx in range(start, len(lines)):
        probe = _strip_decoration(lines[idx]).lower().rstrip(":").strip()
        if probe and any(probe.startswith(stop) for stop in _STOP_HEADINGS):
            end = idx
            break

    region = "\n".join(lines[start:end]).strip()
    return region or text


def _looks_like_gherkin(text: str) -> bool:
    hits = 0
    for raw in text.split("\n"):
        probe = _strip_decoration(raw).lower()
        if probe.startswith(("given ", "when ", "then ")):
            hits += 1
    return hits >= 2


# ----------------------------------------------------------------------
# Data model
# ----------------------------------------------------------------------
@dataclass
class BddStep:
    keyword: str  # given | when | then
    raw_keyword: str  # given | when | then | and | but
    text: str

    def to_dict(self) -> dict:
        return {
            "keyword": self.keyword,
            "raw_keyword": self.raw_keyword,
            "text": self.text,
        }


@dataclass
class BddScenario:
    name: str
    steps: List[BddStep] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    example: Optional[Dict[str, str]] = None
    outline: bool = False

    @property
    def givens(self) -> List[BddStep]:
        return [s for s in self.steps if s.keyword == "given"]

    @property
    def whens(self) -> List[BddStep]:
        return [s for s in self.steps if s.keyword == "when"]

    @property
    def thens(self) -> List[BddStep]:
        return [s for s in self.steps if s.keyword == "then"]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "tags": self.tags,
            "outline": self.outline,
            "example": self.example,
            "steps": [s.to_dict() for s in self.steps],
        }


@dataclass
class BddFeature:
    feature: str = ""
    background: List[BddStep] = field(default_factory=list)
    scenarios: List[BddScenario] = field(default_factory=list)
    raw: str = ""
    structured: bool = False

    def to_dict(self) -> dict:
        return {
            "feature": self.feature,
            "background": [s.to_dict() for s in self.background],
            "scenarios": [s.to_dict() for s in self.scenarios],
            "structured": self.structured,
            "scenario_count": len(self.scenarios),
        }


# ----------------------------------------------------------------------
# Parsing
# ----------------------------------------------------------------------
def _split_keyword(line: str) -> Optional[Tuple[str, str]]:
    probe = _strip_decoration(line)
    match = re.match(r"^(given|when|then|and|but)\b[:\s]\s*(.+)$", probe, re.I)
    if not match:
        return None
    return match.group(1).lower(), match.group(2).strip()


def _parse_table(rows: List[str]) -> List[Dict[str, str]]:
    parsed: List[List[str]] = []
    for row in rows:
        match = _TABLE_ROW.match(row)
        if not match:
            continue
        cells = [cell.strip() for cell in match.group(1).split("|")]
        parsed.append(cells)
    if len(parsed) < 2:
        return []
    header = [h.strip() for h in parsed[0]]
    out: List[Dict[str, str]] = []
    for values in parsed[1:]:
        if all(not v for v in values):
            continue
        row = {}
        for idx, key in enumerate(header):
            row[key] = values[idx] if idx < len(values) else ""
        out.append(row)
    return out


def _substitute(text: str, example: Dict[str, str]) -> str:
    def repl(match: re.Match) -> str:
        key = match.group(1).strip()
        for candidate, value in example.items():
            if candidate.strip().lower() == key.lower():
                return value
        return match.group(0)

    return _PLACEHOLDER.sub(repl, text)


def parse_bdd(text: str) -> BddFeature:
    """Parse acceptance-criteria text into a structured feature."""
    feature = BddFeature(raw=text or "")
    if not text:
        return feature

    lines = text.split("\n")
    current: Optional[BddScenario] = None
    in_background = False
    pending_tags: List[str] = []
    last_keyword = "given"
    examples_buffer: List[str] = []
    collecting_examples = False
    unnamed_index = 0

    def flush_examples() -> None:
        nonlocal collecting_examples, examples_buffer
        if collecting_examples and current is not None and examples_buffer:
            rows = _parse_table(examples_buffer)
            if rows:
                current.outline = True
                setattr(current, "_examples", rows)
        collecting_examples = False
        examples_buffer = []

    def close_scenario() -> None:
        nonlocal current
        flush_examples()
        if current is not None and current.steps:
            feature.scenarios.append(current)
        current = None

    for raw_line in lines:
        probe = _strip_decoration(raw_line)
        if not probe:
            continue

        if collecting_examples and _TABLE_ROW.match(raw_line):
            examples_buffer.append(raw_line)
            continue

        if _TAG.match(probe):
            pending_tags = [t.lstrip("@") for t in probe.split()]
            continue

        lowered = probe.lower()

        if lowered.startswith("feature:"):
            close_scenario()
            feature.feature = probe.split(":", 1)[1].strip()
            feature.structured = True
            continue

        if lowered.startswith("background:"):
            close_scenario()
            in_background = True
            feature.structured = True
            continue

        if lowered.startswith(("scenario outline:", "scenario template:")):
            close_scenario()
            in_background = False
            feature.structured = True
            current = BddScenario(
                name=probe.split(":", 1)[1].strip() or "Scenario",
                tags=pending_tags,
                outline=True,
            )
            pending_tags = []
            continue

        if lowered.startswith(("scenario:", "example:")) and not lowered.startswith(
            "examples"
        ):
            close_scenario()
            in_background = False
            feature.structured = True
            current = BddScenario(
                name=probe.split(":", 1)[1].strip() or "Scenario",
                tags=pending_tags,
            )
            pending_tags = []
            continue

        if lowered.startswith("examples"):
            flush_examples()
            collecting_examples = True
            continue

        parsed = _split_keyword(probe)
        if parsed:
            raw_keyword, body = parsed
            if raw_keyword in ("and", "but"):
                keyword = last_keyword
            else:
                keyword = raw_keyword
                last_keyword = keyword

            step = BddStep(keyword=keyword, raw_keyword=raw_keyword, text=body)

            if in_background:
                feature.background.append(step)
                continue

            if current is None:
                unnamed_index += 1
                current = BddScenario(
                    name=f"Acceptance criterion {unnamed_index}",
                    tags=pending_tags,
                )
                pending_tags = []

            current.steps.append(step)
            # An unlabelled block that starts a fresh `Given` after a `Then`
            # is a new criterion in practice; split it so coverage is honest.
            continue

        # Non-keyword prose inside a scenario is treated as a continuation.
        if current is not None and current.steps:
            current.steps[-1].text = f"{current.steps[-1].text} {probe}".strip()

    close_scenario()

    feature.scenarios = _expand_outlines(feature.scenarios)
    if not feature.scenarios:
        feature.structured = False
    return feature


def _expand_outlines(scenarios: List[BddScenario]) -> List[BddScenario]:
    expanded: List[BddScenario] = []
    for scenario in scenarios:
        rows: List[Dict[str, str]] = getattr(scenario, "_examples", []) or []
        if not scenario.outline or not rows:
            expanded.append(scenario)
            continue
        for index, row in enumerate(rows, start=1):
            clone = BddScenario(
                name=f"{scenario.name} [{index}]",
                tags=list(scenario.tags),
                example=row,
                outline=True,
                steps=[
                    BddStep(
                        keyword=step.keyword,
                        raw_keyword=step.raw_keyword,
                        text=_substitute(step.text, row),
                    )
                    for step in scenario.steps
                ],
            )
            expanded.append(clone)
    return expanded


def parse_story(description: Any) -> Tuple[str, BddFeature]:
    """Convenience: raw description -> (acceptance criteria text, parsed feature)."""
    text = normalise_description(description)
    criteria = extract_acceptance_criteria(text)
    return criteria, parse_bdd(criteria)


def scenario_titles(feature: BddFeature) -> List[str]:
    return [s.name for s in feature.scenarios]


def iter_steps(feature: BddFeature) -> Iterable[BddStep]:
    yield from feature.background
    for scenario in feature.scenarios:
        yield from scenario.steps
