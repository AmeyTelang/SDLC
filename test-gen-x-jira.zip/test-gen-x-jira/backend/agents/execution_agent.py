from __future__ import annotations

from datetime import datetime
from typing import Optional

from agents.approval_gate import approval_gate
from agents.llm_client import llm_client
from models.schemas import ExecuteRequest, ExecuteResponse
from services import workspace
from services.playwright_runner import playwright_runner
from services import audit_hooks

ANALYSIS_SYSTEM = """You are a QA lead reviewing an automated Playwright run.
Given the status, counts and raw logs, write a concise (3-5 sentence) verdict:
what passed/failed, the most likely root cause of any failure, and one concrete
next action. Be specific, no fluff, no markdown headers."""


class ExecutionAgent:
    name = "execution"

    def execute(
        self,
        req: ExecuteRequest,
        file_name: str,
        script: str,
        project_id: Optional[str] = None,
        project_name: Optional[str] = None,
        enforce_approval: bool = True,
    ) -> ExecuteResponse:
        # ------------------------------------------------------------------
        # HITL GATE: never run a script the Test Lead has not approved.
        # `enforce_approval=False` is only for legacy/auto-run call paths.
        # ------------------------------------------------------------------
        if enforce_approval:
            try:
                approval_gate.assert_approved(req.test_id)
            except PermissionError as exc:
                audit_hooks.execution_blocked(
                    req.test_id, actor=None, role=None, reason=str(exc)
                )
                raise

        project_id = project_id or getattr(req, "project_id", None)
        project_name = project_name or getattr(req, "project_name", None)

        out_dir = workspace.output_dir(project_id, project_name)
        playwright_runner.write_script(out_dir, file_name, script or "")

        rr = playwright_runner.run(
            out_dir, file_name, req.language, test_id=req.test_id, headless=req.headless
        )

        analysis, analyzed_by = self._analyse(
            rr.status, rr.total, rr.passed, rr.failed, rr.stdout, rr.stderr
        )

        return ExecuteResponse(
            test_id=req.test_id,
            status=rr.status,
            total=rr.total,
            passed=rr.passed,
            failed=rr.failed,
            duration_ms=rr.duration_ms,
            step_results=rr.step_results,
            evidence=rr.evidence,
            stdout=rr.stdout,
            stderr=rr.stderr,
            analysis=analysis,
            analyzed_by=analyzed_by,
            evidence_mode=rr.evidence_mode,
            finished_at=datetime.utcnow(),
        )

    def _analyse(self, status, total, passed, failed, stdout, stderr):
        user = (
            f"Status: {status}\nTotal: {total}\nPassed: {passed}\nFailed: {failed}\n\n"
            f"--- STDOUT ---\n{stdout[-2500:]}\n\n--- STDERR ---\n{stderr[-1500:]}\n"
        )
        text = llm_client.chat(ANALYSIS_SYSTEM, user, temperature=0.2)
        if text:
            return text.strip(), "llm"
        return self._fallback(status, total, passed, failed, stderr), "fallback"

    @staticmethod
    def _fallback(status, total, passed, failed, stderr) -> str:
        if status == "passed":
            return (
                f"All {passed}/{total} checks passed. The generated script executed cleanly with no "
                f"failing assertions. Recommended next action: promote this test into the regression "
                f"suite and parameterise the test data."
            )
        if status == "error":
            return (
                "The run could not complete due to an environment or setup error. Verify the Playwright "
                "runtime is installed (`playwright install`) and that the target application/URL is "
                "reachable, then re-run."
            )
        hint = ""
        if stderr and stderr.strip():
            hint = f" First error line: '{stderr.strip().splitlines()[0][:200]}'."
        return (
            f"{failed} of {total} checks failed.{hint} The most likely cause is a locator or assertion "
            f"mismatch. Recommended next action: review the failing step's locator/expected text and "
            f"regenerate that step."
        )


execution_agent = ExecutionAgent()
