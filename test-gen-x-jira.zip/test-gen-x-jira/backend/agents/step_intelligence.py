"""LLM step intelligence for the Playwright generation agent.

The deterministic translator in ``generation_agent`` is excellent when a step
is already unambiguous ("Click on \"Checkout\""). It degrades to a
``# TODO manual mapping needed`` comment when a step is vague
("the user proceeds", "validate the page").

This module closes that gap *without* handing control of the emitted code to a
model. It performs a narrow, auditable job:

* classify every raw step as clear / ambiguous;
* rewrite ONLY the ambiguous ones into the imperative, locator-friendly
  grammar the deterministic translator already understands;
* return per-step confidence and a reason.

Invariants enforced in code, not merely requested in the prompt:
  1. step count never changes;
  2. order never changes;
  3. a step already classified as clear is returned verbatim;
  4. any rewrite that loses the step's literal quoted values is rejected.

If the model is unavailable or violates an invariant, the original steps are
returned untouched. Generation therefore never regresses.
"""

from __future__ import annotations

import logging
import re
from typing import List, Optional, Sequence, Tuple

from agents.llm_client import llm_client

logger = logging.getLogger("testgenx.stepintel")

CALL_TYPE = "generation.step_intelligence"

# Verbs the deterministic translator can already compile.
_KNOWN_VERBS = (
    "open",
    "navigate",
    "go to",
    "visit",
    "browse to",
    "launch",
    "reload",
    "refresh",
    "login",
    "click",
    "tap",
    "press",
    "choose",
    "select",
    "type",
    "enter",
    "input",
    "fill",
    "clear",
    "check",
    "uncheck",
    "tick",
    "untick",
    "hover",
    "upload",
    "scroll",
    "wait",
    "verify",
    "assert",
    "confirm",
    "expect",
    "ensure",
    "should",
    "double-click",
    "right-click",
    "accept",
    "dismiss",
)

# Markers of a step that cannot be compiled deterministically.
_VAGUE = (
    "appropriate",
    "relevant",
    "necessary",
    "as needed",
    "etc",
    "and so on",
    "properly",
    "correctly",
    "works",
    "valid data",
    "some ",
    "any ",
    "the user proceeds",
    "continues",
    "does the needful",
    "handle",
)

SYSTEM = """You normalise QA test steps into the imperative grammar a Playwright test runner can compile.

You will receive numbered steps. Some are already compilable and are marked KEEP - return those EXACTLY as given, unchanged.
For steps marked REWRITE, restate the same intent using this grammar:
  - Navigation:  Open the application   |   Navigate to "<url>"
  - Click:       Click on "<label>"   |   Click on "<label>" button|link|tab
  - Input:       Enter "<value>" into "<field>"
  - Select:      Select "<option>" from "<field>"
  - Toggle:      Check "<label>"   |   Uncheck "<label>"
  - Upload:      Upload file "<path>"
  - Wait:        Wait for "<label>"
  - Assertion:   Verify that "<label>" is visible   |   Verify that the URL contains "<fragment>"

HARD RULES:
- Return EXACTLY as many steps as you received, in the SAME order.
- Preserve every quoted literal, URL, username, password and number from the original step. Never change, drop or invent a value.
- Never merge or split steps. Never add assertions that were not implied.
- If a REWRITE step is too vague to express without inventing detail, return it unchanged and set confidence below 0.4 with a reason.
- An assertion step must stay an assertion; an action step must stay an action.

Return STRICT JSON ONLY:
{"steps":[{"index":1,"text":"...","confidence":0.0,"changed":false,"reason":"<=10 words"}]}"""


def _quoted_literals(text: str) -> List[str]:
    literals = re.findall(r'"([^"]+)"', text or "")
    literals += re.findall(r"https?://[^\s\"']+", text or "")
    return [item.strip() for item in literals if item.strip()]


def is_ambiguous(step: str) -> bool:
    """Would the deterministic translator struggle with this step?"""
    probe = (step or "").strip().lower()
    if not probe:
        return True
    if len(probe.split()) <= 2:
        return True
    if any(marker in probe for marker in _VAGUE):
        return True
    if not any(probe.startswith(verb) or f" {verb} " in probe for verb in _KNOWN_VERBS):
        return True
    # An action verb with no target and no quoted literal is unresolvable.
    if re.match(r"^(click|press|tap|choose|select)\b", probe) and not _quoted_literals(
        step
    ):
        if len(probe.split()) <= 3:
            return True
    return False


def _preserves_literals(original: str, rewritten: str) -> bool:
    for literal in _quoted_literals(original):
        if literal.lower() not in (rewritten or "").lower():
            return False
    return True


def _assertion(text: str) -> bool:
    probe = (text or "").lower()
    return any(
        marker in probe
        for marker in (
            "verify",
            "assert",
            "should",
            "expect",
            "confirm",
            "ensure",
            "check that",
        )
    )


class StepIntelligence:
    """Clarify ambiguous natural-language steps before code generation."""

    name = "step_intelligence"

    def refine(
        self,
        steps: Sequence[str],
        *,
        title: str = "",
        base_url: str = "",
        story_key: str = "",
    ) -> Tuple[List[str], List[dict], float]:
        """Return ``(steps, per_step_metadata, overall_confidence)``."""
        originals = [str(s or "").strip() for s in steps]
        if not originals:
            return [], [], 0.0

        flags = [is_ambiguous(step) for step in originals]
        meta = [
            {
                "index": i + 1,
                "original": text,
                "text": text,
                "changed": False,
                "confidence": 0.55 if flags[i] else 0.95,
                "reason": (
                    "Ambiguous - not compilable as written." if flags[i] else "Clear."
                ),
            }
            for i, text in enumerate(originals)
        ]

        if not any(flags) or not llm_client.available:
            if any(flags) and not llm_client.available:
                logger.info("Step intelligence skipped: no model available.")
            return originals, meta, self._overall(meta)

        payload = llm_client.chat_json(
            SYSTEM,
            self._prompt(originals, flags, title, base_url),
            temperature=0.0,
            call_type=CALL_TYPE,
            story_key=story_key,
        )
        if not payload:
            return originals, meta, self._overall(meta)

        raw = payload.get("steps")
        if not isinstance(raw, list) or len(raw) != len(originals):
            logger.info(
                "Step intelligence returned %s entries for %d steps; keeping originals.",
                len(raw) if isinstance(raw, list) else "no",
                len(originals),
            )
            return originals, meta, self._overall(meta)

        refined: List[str] = []
        for position, (original, ambiguous) in enumerate(zip(originals, flags)):
            item = raw[position] if isinstance(raw[position], dict) else {}
            candidate = str(item.get("text") or "").strip()
            try:
                confidence = max(0.0, min(1.0, float(item.get("confidence", 0.0))))
            except (TypeError, ValueError):
                confidence = 0.0
            reason = str(item.get("reason") or "").strip()[:120]

            record = meta[position]

            if not ambiguous:
                # Clear steps are never allowed to drift.
                refined.append(original)
                record["confidence"] = max(record["confidence"], confidence or 0.95)
                continue

            rejected: Optional[str] = None
            if not candidate:
                rejected = "empty rewrite"
            elif not _preserves_literals(original, candidate):
                rejected = "rewrite dropped a literal value"
            elif _assertion(original) != _assertion(candidate):
                rejected = "rewrite changed action/assertion type"
            elif confidence < 0.4:
                rejected = "model confidence too low"

            if rejected:
                logger.info("Step %d rewrite rejected (%s).", position + 1, rejected)
                refined.append(original)
                record.update(
                    {
                        "text": original,
                        "changed": False,
                        "confidence": min(record["confidence"], 0.45),
                        "reason": f"Kept original - {rejected}.",
                    }
                )
                continue

            refined.append(candidate)
            record.update(
                {
                    "text": candidate,
                    "changed": candidate != original,
                    "confidence": confidence,
                    "reason": reason or "Clarified into compilable grammar.",
                }
            )

        return refined, meta, self._overall(meta)

    @staticmethod
    def _overall(meta: Sequence[dict]) -> float:
        if not meta:
            return 0.0
        return round(sum(m["confidence"] for m in meta) / len(meta), 3)

    @staticmethod
    def _prompt(
        steps: Sequence[str], flags: Sequence[bool], title: str, base_url: str
    ) -> str:
        lines: List[str] = []
        if title:
            lines.append(f"TEST TITLE: {title}")
        if base_url:
            lines.append(f"APPLICATION UNDER TEST: {base_url}")
        lines.append("")
        lines.append("STEPS:")
        for position, (text, ambiguous) in enumerate(zip(steps, flags), start=1):
            marker = "REWRITE" if ambiguous else "KEEP"
            lines.append(f"{position}. [{marker}] {text}")
        return "\n".join(lines)


step_intelligence = StepIntelligence()
