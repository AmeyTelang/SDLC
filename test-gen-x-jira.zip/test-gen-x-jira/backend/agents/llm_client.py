"""Hardened LLM client for TestGenX.

Production changes over the previous build
------------------------------------------
* No ``print``. Structured logging only.
* Bounded retries with exponential backoff on transient failures.
* A real HTTP fallback path when the SDK is unavailable (previously dead code).
* ``chat_json`` returns a *validated* JSON object, with brace-balanced
  extraction so a chatty model never breaks a caller.
* Token usage is recorded for every call, success or failure, and is tagged
  with a ``call_type`` so the Token Usage page can break spend down by
  operation (story import, test-case synthesis, step intelligence, ...).
"""

from __future__ import annotations

import json
import logging
import random
import time
from typing import Any, Dict, List, Optional

import config

try:
    from token_tracker import record_usage, normalize_usage, MODULE_WEB_STUDIO
except ImportError:  # pragma: no cover
    from .token_tracker import record_usage, normalize_usage, MODULE_WEB_STUDIO

try:  # Optional: a dedicated authoring module id if the tracker defines one.
    from token_tracker import MODULE_AUTHORING  # type: ignore
except Exception:  # pragma: no cover
    MODULE_AUTHORING = MODULE_WEB_STUDIO

logger = logging.getLogger("testgenx.llm")

MAX_ATTEMPTS = 3
BACKOFF_BASE_S = 0.6
BACKOFF_CAP_S = 6.0

# Substrings that indicate a retry is worth making.
_TRANSIENT = (
    "timeout",
    "timed out",
    "rate limit",
    "429",
    "500",
    "502",
    "503",
    "504",
    "connection",
    "temporarily",
    "overloaded",
)


def _is_transient(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(token in text for token in _TRANSIENT)


def _backoff(attempt: int) -> float:
    raw = min(BACKOFF_CAP_S, BACKOFF_BASE_S * (2 ** (attempt - 1)))
    return raw * (0.7 + random.random() * 0.6)


def extract_json_object(text: Optional[str]) -> Optional[dict]:
    """Pull the first well-formed JSON object out of a model response.

    Handles fenced code blocks and leading/trailing prose. Returns ``None``
    rather than raising, so every caller can fall back deterministically.
    """
    if not text:
        return None

    body = text.strip()
    if body.startswith("```"):
        body = body.split("\n", 1)[-1]
        if body.rstrip().endswith("```"):
            body = body.rstrip()[:-3]
        body = body.strip()

    try:
        parsed = json.loads(body)
        return parsed if isinstance(parsed, dict) else None
    except Exception:
        pass

    start = body.find("{")
    while start != -1:
        depth = 0
        in_string = False
        escaped = False
        for idx in range(start, len(body)):
            ch = body[idx]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        candidate = json.loads(body[start : idx + 1])
                        if isinstance(candidate, dict):
                            return candidate
                    except Exception:
                        pass
                    break
        start = body.find("{", start + 1)
    return None


class LLMClient:
    def __init__(self) -> None:
        self.model = config.MISTRAL_MODEL
        self.api_key = config.MISTRAL_API_KEY
        self.timeout = getattr(config, "LLM_TIMEOUT_SECONDS", 60)
        self._client = None
        self._mode = "unavailable"

        if getattr(config, "FORCE_FALLBACK", False):
            logger.info("TESTGENX_FORCE_FALLBACK is set - LLM disabled.")
            return
        if not self.api_key:
            logger.warning("MISTRAL_API_KEY not set - running in fallback mode.")
            return

        try:
            from mistralai import Mistral  # type: ignore

            self._client = Mistral(api_key=self.api_key)
            self._mode = "sdk"
        except Exception as exc:  # pragma: no cover
            logger.info("Mistral SDK unavailable (%s); using HTTP transport.", exc)
            self._mode = "http"

    # ------------------------------------------------------------------
    @property
    def available(self) -> bool:
        return self._mode in {"sdk", "http"}

    @property
    def mode(self) -> str:
        return self._mode

    # ------------------------------------------------------------------
    def _record(
        self,
        usage: Any,
        call_type: str,
        story_key: str,
        module: str,
        success: bool,
    ) -> None:
        try:
            record_usage(
                call_type=call_type,
                model=self.model,
                usage=normalize_usage(usage),
                module=module,
                story_key=story_key or "",
                success=success,
            )
        except Exception as exc:  # usage tracking must never break a workflow
            logger.warning("Token usage tracking failed (%s).", exc)

    # ------------------------------------------------------------------
    def chat(
        self,
        system: str,
        user: str,
        temperature: float = 0.2,
        call_type: str = "chat",
        story_key: str = "",
        module: Optional[str] = None,
        json_mode: bool = False,
        max_attempts: int = MAX_ATTEMPTS,
    ) -> Optional[str]:
        """Return the assistant message, or ``None`` if the call cannot succeed."""
        if not self.available:
            return None

        module = module or MODULE_WEB_STUDIO
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

        last_error: Optional[Exception] = None
        for attempt in range(1, max_attempts + 1):
            try:
                if self._mode == "sdk":
                    content, usage = self._chat_sdk(messages, temperature, json_mode)
                else:
                    content, usage = self._chat_http(messages, temperature, json_mode)
                self._record(usage, call_type, story_key, module, success=True)
                return content
            except Exception as exc:
                last_error = exc
                retryable = _is_transient(exc) and attempt < max_attempts
                logger.warning(
                    "LLM call '%s' failed on attempt %d/%d (%s)%s",
                    call_type,
                    attempt,
                    max_attempts,
                    exc,
                    " - retrying." if retryable else " - giving up.",
                )
                if not retryable:
                    break
                time.sleep(_backoff(attempt))

        self._record(None, call_type, story_key, module, success=False)
        logger.info(
            "LLM unavailable for '%s' (%s); caller will fall back.",
            call_type,
            last_error,
        )
        return None

    def chat_json(
        self,
        system: str,
        user: str,
        temperature: float = 0.0,
        call_type: str = "chat.json",
        story_key: str = "",
        module: Optional[str] = None,
        max_attempts: int = MAX_ATTEMPTS,
    ) -> Optional[dict]:
        """Chat and return a parsed JSON object, or ``None``."""
        raw = self.chat(
            system,
            user,
            temperature=temperature,
            call_type=call_type,
            story_key=story_key,
            module=module,
            json_mode=True,
            max_attempts=max_attempts,
        )
        payload = extract_json_object(raw)
        if payload is None and raw:
            logger.info("LLM '%s' returned no parseable JSON object.", call_type)
        return payload

    # ------------------------------------------------------------------
    def _chat_sdk(self, messages: List[dict], temperature: float, json_mode: bool):
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        resp = self._client.chat.complete(**kwargs)  # type: ignore[union-attr]
        content = resp.choices[0].message.content
        return content, getattr(resp, "usage", None)

    def _chat_http(self, messages: List[dict], temperature: float, json_mode: bool):
        import urllib.request

        body: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}

        request = urllib.request.Request(
            "https://api.mistral.ai/v1/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return payload["choices"][0]["message"]["content"], payload.get("usage")


llm_client = LLMClient()
