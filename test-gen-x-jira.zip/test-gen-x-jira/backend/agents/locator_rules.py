from __future__ import annotations

import json
import os
import re
from functools import lru_cache
from typing import Any, Dict, List, Optional

# Default config path: backend/config/locator_rules.json (override via env).
_DEFAULT_PATH = os.getenv(
    "TESTGENX_LOCATOR_RULES",
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "config",
        "locator_rules.json",
    ),
)


def _q(s: str) -> str:
    return (s or "").replace("\\", "\\\\").replace('"', '\\"')


@lru_cache(maxsize=8)
def _load_raw(path: str, mtime: float) -> str:
    # Cached by (path, mtime) so edits are picked up without a restart, and each
    # path caches independently. Returns a JSON string (hashable, immutable).
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and isinstance(data.get("rules"), list):
            return json.dumps(data)
    except Exception:
        pass
    return '{"rules": []}'


def load_rules(path: Optional[str] = None) -> List[Dict[str, Any]]:
    p = path or _DEFAULT_PATH
    try:
        mtime = os.path.getmtime(p)
    except Exception:
        return []  # file missing -> no rules (backward compatible)
    try:
        return json.loads(_load_raw(p, mtime)).get("rules", [])
    except Exception:
        return []


def _scope_ok(rule: Dict[str, Any], project: Optional[Dict[str, Any]]) -> bool:
    scope = rule.get("scope")
    if not scope:
        return True  # global rule
    project = project or {}
    pid = str(project.get("id", "") or "")
    aut = str(project.get("aut_url", "") or project.get("base_url", "") or "").lower()
    if "project_id" in scope and str(scope["project_id"]) != pid:
        return False
    if "aut_url" in scope and str(scope["aut_url"]).lower() not in aut:
        return False
    return True


def _text_matches(
    target_low: str, when: Dict[str, Any], nots: List[str]
) -> Optional[int]:
    """Return a specificity score if matched, else None. Higher = more specific."""
    for n in nots:
        if n and n.lower() in target_low:
            return None
    best = None
    # regex
    for rx in when.get("regex", []) or []:
        try:
            if re.search(rx, target_low, re.I):
                best = max(best or 0, 50 + len(rx))
        except Exception:
            continue
    # any-of substrings
    for kw in when.get("any", []) or []:
        k = (kw or "").lower()
        if k and k in target_low:
            best = max(best or 0, len(k))  # longer keyword = more specific
    # exact
    for kw in when.get("exact", []) or []:
        if (kw or "").lower() == target_low:
            best = max(best or 0, 100 + len(kw))
    return best


def match_rule(
    action: str,
    target: str,
    project: Optional[Dict[str, Any]] = None,
    rules: Optional[List[Dict[str, Any]]] = None,
) -> Optional[Dict[str, Any]]:
    """Return the best-matching rule's LOCATOR recipe (dict) or None."""
    rules = rules if rules is not None else load_rules()
    if not rules:
        return None
    target_low = (target or "").strip().lower()
    candidates = []
    for r in rules:
        when = r.get("when", {}) or {}
        if str(when.get("action", "any")).lower() not in (action.lower(), "any"):
            continue
        if not _scope_ok(r, project):
            continue
        score = _text_matches(target_low, when, r.get("not", []) or [])
        if score is None:
            continue
        # scoped rules outrank global ones at equal text score
        scoped = 1 if r.get("scope") else 0
        candidates.append((scoped, score, r))
    if not candidates:
        return None
    candidates.sort(key=lambda t: (t[0], t[1]), reverse=True)
    return candidates[0][2].get("locator")


def recipe_to_locator(recipe: Dict[str, Any], py: bool) -> Optional[str]:
    """Compile a locator recipe -> a Playwright locator expression string.
    Returns None for an invalid/empty recipe."""
    if not isinstance(recipe, dict):
        return None
    if "css" in recipe:
        sel = _q(recipe["css"])
        return (
            f'page.locator("{sel}").first' if py else f'page.locator("{sel}").first()'
        )
    if "testid" in recipe:
        v = _q(recipe["testid"])
        return (
            f'page.get_by_test_id("{v}").first'
            if py
            else f'page.getByTestId("{v}").first()'
        )
    if "role" in recipe:
        role = _q(str(recipe.get("role", "")))
        name = recipe.get("name")
        if py:
            if name:
                return f'page.get_by_role("{role}", name="{_q(name)}").first'
            return f'page.get_by_role("{role}").first'
        if name:
            return f'page.getByRole("{role}", {{ name: "{_q(name)}" }}).first()'
        return f'page.getByRole("{role}").first()'
    if "label" in recipe:
        v = _q(recipe["label"])
        return (
            f'page.get_by_label("{v}").first'
            if py
            else f'page.getByLabel("{v}").first()'
        )
    if "placeholder" in recipe:
        v = _q(recipe["placeholder"])
        return (
            f'page.get_by_placeholder("{v}").first'
            if py
            else f'page.getByPlaceholder("{v}").first()'
        )
    if "text" in recipe:
        v = _q(recipe["text"])
        return (
            f'page.get_by_text("{v}").first' if py else f'page.getByText("{v}").first()'
        )
    return None


def click_code(
    action_target: str, indent: str, py: bool, project: Optional[Dict[str, Any]] = None
) -> Optional[str]:
    rec = match_rule("click", action_target, project)
    loc = recipe_to_locator(rec, py) if rec else None
    if not loc:
        return None
    return indent + (f"{loc}.click()" if py else f"await {loc}.click();")


def visible_code(
    action_target: str,
    indent: str,
    py: bool,
    timeout: int,
    project: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    rec = match_rule("visible", action_target, project)
    loc = recipe_to_locator(rec, py) if rec else None
    if not loc:
        return None
    if py:
        return indent + f"expect({loc}).to_be_visible(timeout={timeout})"
    return indent + f"await expect({loc}).toBeVisible({{ timeout: {timeout} }});"
