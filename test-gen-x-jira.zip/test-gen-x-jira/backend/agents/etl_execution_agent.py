"""
ETL Execution Agent
- Executes SQL validation queries against target database
- Analyzes results and provides verdict
- Generates execution report with step-level details
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

try:
    from mistralai import Mistral

    _HAS_MISTRAL = True
except Exception:
    _HAS_MISTRAL = False

from models.schemas import (
    ETLExecuteRequest,
    ETLExecuteResponse,
    ETLStepResult,
)

# Shared token/cost tracker (top-level module at backend root). Best-effort.
try:
    from token_tracker import record_usage, MODULE_ETL
except Exception:  # pragma: no cover
    record_usage = None
    MODULE_ETL = "etl"

logger = logging.getLogger("testgenx.etl_execution")

# Model used for the analysis/verdict LLM call.
_ANALYSIS_MODEL = "mistral-large-latest"

ANALYSIS_SYSTEM = """You are a QA analyst reviewing ETL transformation validation results.
Given the test status, counts, step-by-step results and SQL output, write a concise 
(2-3 sentence) verdict: what passed/failed, the root cause of any failure, and one 
concrete remediation action. Be specific, no fluff, no markdown."""


class ETLExecutionAgent:
    """Agentic component for ETL SQL validation execution and analysis."""

    name = "etl_execution"

    def __init__(self, db_url: str = "sqlite:///./etl_target.db", api_key: str = ""):
        """Initialize with database connection and optional Mistral for analysis."""
        self.db_path = self._resolve_sqlite_path(db_url)
        self.llm_client = None
        if _HAS_MISTRAL and api_key:
            self.llm_client = Mistral(api_key=api_key)

    def execute(
        self,
        req: ETLExecuteRequest,
    ) -> ETLExecuteResponse:
        """
        Execute SQL validation steps and return detailed results.

        Args:
            req: ETLExecuteRequest with generated script

        Returns:
            ETLExecuteResponse with pass/fail status and step results
        """
        step_results: List[ETLStepResult] = []
        passed = 0
        failed = 0
        error_count = 0
        logs: List[str] = []

        conn = None
        try:
            conn = self._connect()
            cur = conn.cursor()

            for step in req.script.test_steps:
                sql = (step.data or "").strip().rstrip(";")
                if not sql:
                    continue

                try:
                    cur.execute(sql)
                    rows = cur.fetchall()
                    row_count = len(rows)

                    # Validation logic: 0 rows = PASS, >0 rows = FAIL
                    status = "PASS" if row_count == 0 else "FAIL"
                    actual_result = self._format_result(rows, row_count)

                    if status == "PASS":
                        passed += 1
                    else:
                        failed += 1

                    step_results.append(
                        ETLStepResult(
                            index=step.index,
                            action=step.action,
                            expected_result=step.expected_result,
                            actual_result=actual_result,
                            status=status,
                        )
                    )

                    logs.append(f"[{status}] {step.action} → {actual_result}")

                except Exception as e:
                    error_count += 1
                    failed += 1
                    error_msg = str(e)
                    step_results.append(
                        ETLStepResult(
                            index=step.index,
                            action=step.action,
                            expected_result=step.expected_result,
                            actual_result=f"ERROR: {error_msg}",
                            status="ERROR",
                        )
                    )
                    logs.append(f"[ERROR] {step.action} → {error_msg}")

        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            logs.append(f"FATAL: {e}")

        finally:
            if conn:
                conn.close()

        # Determine overall status
        overall_status = "PASS" if failed == 0 and passed > 0 else "FAIL"

        # Generate analysis using LLM if available
        analysis, analyzed_by = self._analyze(
            overall_status,
            passed,
            failed,
            error_count,
            logs,
            story_key=getattr(req.script, "story_key", "") or "",
        )

        return ETLExecuteResponse(
            test_id=req.test_id,
            story_key=req.script.story_key,
            target_table=req.script.target_table,
            overall_status=overall_status,
            passed=passed,
            failed=failed,
            error_count=error_count,
            step_results=step_results,
            log="\n".join(logs),
            analysis=analysis,
            analyzed_by=analyzed_by,
            finished_at=datetime.utcnow(),
        )

    # ==================================================================
    # Private: Database & Analysis
    # ==================================================================

    @staticmethod
    def _resolve_sqlite_path(url: str) -> str:
        """Extract file path from SQLite URL."""
        if url.startswith("sqlite:///"):
            return url.replace("sqlite:///", "", 1)
        return url

    def _connect(self) -> sqlite3.Connection:
        """Establish database connection."""
        return sqlite3.connect(self.db_path)

    @staticmethod
    def _format_result(rows: List[Tuple], count: int) -> str:
        """Format database result for readability."""
        if count == 0:
            return "0 rows (as expected)"
        elif count <= 3:
            return f"{count} rows returned: {rows}"
        else:
            return f"{count} rows returned; sample: {rows[:3]}"

    def _analyze(
        self,
        status: str,
        passed: int,
        failed: int,
        error_count: int,
        logs: List[str],
        story_key: str = "",
    ) -> Tuple[str, str]:
        """Generate analysis of execution results using LLM."""
        if not self.llm_client:
            # Fallback: deterministic analysis
            if error_count > 0:
                return (
                    f"Execution encountered {error_count} error(s) in database queries. "
                    f"Review logs and SQL syntax.",
                    "deterministic",
                )
            elif failed > 0:
                return (
                    f"Validation FAILED: {failed} rule(s) violated. "
                    f"{passed} rule(s) passed. Review failing validation queries.",
                    "deterministic",
                )
            elif passed > 0:
                return (
                    f"Validation PASSED: All {passed} transformation rule(s) are correct. "
                    f"Ready to push results.",
                    "deterministic",
                )
            else:
                return "No validation rules executed.", "deterministic"

        try:
            user = f"""Execution Status: {status}
Passed: {passed}
Failed: {failed}
Errors: {error_count}

Execution Log:
{chr(10).join(logs[-20:])}  # Last 20 log lines

Provide a concise verdict (2-3 sentences): what passed/failed, root cause, and next action."""

            resp = self.llm_client.chat.complete(
                model=_ANALYSIS_MODEL,
                messages=[
                    {"role": "system", "content": ANALYSIS_SYSTEM},
                    {"role": "user", "content": user},
                ],
                temperature=0.1,
            )
            # Record token consumption + cost for the ETL module (best-effort).
            if record_usage is not None:
                try:
                    record_usage(
                        call_type="etl_analysis",
                        model=_ANALYSIS_MODEL,
                        usage=getattr(resp, "usage", None),
                        module=MODULE_ETL,
                        story_key=story_key,
                    )
                except Exception as exc:
                    logger.warning("Token usage tracking failed (%s).", exc)
            analysis = resp.choices[0].message.content
            return analysis, "Mistral AI"

        except Exception as e:
            logger.warning(f"LLM analysis failed: {e}; using fallback")
            return self._analyze(
                status, passed, failed, error_count, logs, story_key=story_key
            )


# Singleton instance
_etl_execution_agent: Optional[ETLExecutionAgent] = None


def get_etl_execution_agent(
    db_url: str = "sqlite:///./etl_target.db", api_key: str = ""
) -> ETLExecutionAgent:
    """Get or create ETL Execution Agent singleton."""
    global _etl_execution_agent
    if _etl_execution_agent is None:
        _etl_execution_agent = ETLExecutionAgent(db_url=db_url, api_key=api_key)
    return _etl_execution_agent
