"""
ETL Generation Agent
- Extracts ETL specifications from JIRA story descriptions
- Generates SQL validation test scripts based on extracted specifications
- Uses Mistral AI for intelligent extraction and script generation

Guarantees:
- DETERMINISTIC: temperature=0 + fixed random_seed => same spec yields the same
  SQL every iteration.
- SCHEMA-GROUNDED: the prompt includes an explicit per-column TYPE TABLE built
  from the real DB (declared_type, storage_type via typeof(), distinct stored
  values) plus a hard rule + worked example, so comparisons use the ACTUAL
  representation (e.g. is_active = 0/1) instead of values guessed from the rule
  wording ('Y'/'N').
- GUARDRAIL: a deterministic post-processor unquotes numeric literals compared
  against numeric columns (e.g. is_active = '1' -> is_active = 1).
"""

from __future__ import annotations

import json
import logging
import re
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Set

try:
    from mistralai import Mistral

    _HAS_MISTRAL = True
except Exception:
    _HAS_MISTRAL = False

from models.schemas import (
    ETLExtractedSpec,
    ETLGenerateRequest,
    ETLGenerateResponse,
    ETLTestStep,
    BusinessRule,
    LovMapping,
)

# Shared token/cost tracker (top-level module at backend root). Best-effort:
# tracking must never break generation.
try:
    from token_tracker import record_usage, normalize_usage, MODULE_ETL
except Exception:  # pragma: no cover
    record_usage = None
    normalize_usage = None
    MODULE_ETL = "etl"

logger = logging.getLogger("testgenx.etl_generation")

# Fixed seed so the same spec always yields the same SQL script.
_SEED = 42
_NUMERIC_STORAGE = {"integer", "real"}


class ETLGenerationAgent:
    "Agentic component for ETL specification extraction and SQL test generation."

    def __init__(self, api_key: str = "", model: str = "mistral-large-latest"):
        self.model = model
        self.client = None
        if _HAS_MISTRAL and api_key:
            self.client = Mistral(api_key=api_key)

    # ================================================================== #
    # Public: Extraction                                                 #
    # ================================================================== #
    def extract_spec(
        self, story_key: str, description: str = "", summary: str = ""
    ) -> ETLExtractedSpec:
        "Extract an ETL spec (business rules + LOVs) from a JIRA story."
        system = (
            "You are an ETL business analyst agent. Extract a structured ETL "
            "validation specification from a JIRA story description. Return ONLY "
            'valid JSON. Never return null for string fields — use "" instead.'
        )
        user = f"""Story: {story_key}
Summary: {summary}
Description:
{description}

Extract and return ONLY valid JSON with this exact schema:
{{
  "summary": string,
  "source_table": string,
  "target_table": string,
  "business_rules": [{{"id": string, "description": string}}],
  "lovs": [{{"field": string, "source_value": string, "target_value": string}}]
}}

Requirements:
- Extract ALL business rules mentioned in the description
- Extract ALL LOV (List of Values) mappings
- Ensure source_table and target_table are clearly identified
- Return valid JSON only, no markdown or explanations"""
        data = (
            self._extract_json(
                self._chat(
                    system, user, call_type="etl_extract_spec", story_key=story_key
                )
            )
            or {}
        )
        return ETLExtractedSpec(
            story_key=story_key,
            summary=data.get("summary") or "",
            source_table=data.get("source_table") or "",
            target_table=data.get("target_table") or "",
            business_rules=[
                BusinessRule(**self._to_dict(r))
                for r in (data.get("business_rules") or [])
            ],
            lovs=[LovMapping(**self._to_dict(l)) for l in (data.get("lovs") or [])],
            raw_description=description or "",
        )

    # ================================================================== #
    # Public: Generation (deterministic + schema-grounded)               #
    # ================================================================== #
    def generate(self, req) -> ETLGenerateResponse:
        """Generate SQL validation test script from an extracted specification.
        Accepts an ETLGenerateRequest, an ETLExtractedSpec, or a plain dict."""
        spec = getattr(req, "spec", req)
        spec_dict = self._to_dict(spec)

        story_key = spec_dict.get("story_key", "") or ""
        target_table = spec_dict.get("target_table", "") or ""
        schema_context = spec_dict.get("schema_context") or {}

        # Deterministic, human-readable per-column type table (the strongest
        # grounding signal) + the set of numeric columns for the guardrail.
        type_table, numeric_cols = self._build_type_table(schema_context)
        spec_for_prompt = {k: v for k, v in spec_dict.items() if k != "schema_context"}

        system = (
            "You are a DETERMINISTIC ETL test generation agent. Given an ETL spec and a "
            "COLUMN TYPE TABLE describing the ACTUAL database, generate SQL validation "
            "queries that verify the TARGET table is correct after the rules/LOVs are "
            "applied to source data. Return ONLY valid JSON. Escape newlines as \\n inside "
            "JSON strings; never emit raw control characters.\n"
            "NON-NEGOTIABLE RULES:\n"
            "1) DETERMINISM: For identical input, produce byte-for-byte identical output. "
            "Emit exactly ONE query per business rule, in spec order. UPPERCASE SQL "
            "keywords. No comments with timestamps, no random aliases, no LIMIT.\n"
            "2) USE ACTUAL STORED VALUES (CRITICAL): The COLUMN TYPE TABLE lists each "
            "column's storage type and its real distinct values. You MUST compare every "
            "column ONLY against values from its own list, using the correct type: "
            "integer/real values are UNQUOTED (e.g. 0, 1); text values are quoted "
            "(e.g. 'Y'). NEVER compare an integer column to a text literal, and NEVER "
            "invent encodings. If a column's values are [0, 1], you MUST use 0/1 — not "
            "'Y'/'N', not 'true'/'false'.\n"
            "3) CROSS-ENCODING TRANSLATION: When a rule relates a source coded column to a "
            "target coded column with different encodings (e.g. source deprecated_flag is "
            "text 'Y'/'N' and target is_active is integer 0/1), translate EXPLICITLY using "
            "each column's real values.\n"
            "   WORKED EXAMPLE (follow this pattern exactly):\n"
            "   Rule: 'is_active is the inverse of deprecated_flag'.\n"
            "   Types: source deprecated_flag = text ['Y','N']; target is_active = integer [0,1].\n"
            "   CORRECT SQL:\n"
            "     SELECT * FROM target_product tp JOIN source_product sp ON tp.product_id = sp.product_id\n"
            "     WHERE tp.is_active <> CASE WHEN sp.deprecated_flag = 'Y' THEN 0 ELSE 1 END;\n"
            "   (deprecated 'Y' => is_active 0; 'N' => 1. Do NOT emit THEN 'N'/THEN 'Y'.)\n"
            "4) DATATYPE-SAFE: CAST(col AS INTEGER/REAL) for numeric, TRIM(col) for text; "
            "no implicit coercion.\n"
            "5) Each query returns 0 rows when CORRECT and >0 (the violating rows) when INVALID.\n"
            "6) Every test_step.data must be a SELECT present verbatim in sql_script."
        )
        user = f"""ETL Spec:
{json.dumps(spec_for_prompt, indent=2, sort_keys=True, default=str)}

COLUMN TYPE TABLE (authoritative — use these EXACT stored values & types):
{type_table}

Generate validation SQL and return ONLY valid JSON with this exact schema:
{{
  "target_table": string,
  "sql_script": "Complete SQL: exactly one query per business rule, in spec order, each grounded in the COLUMN TYPE TABLE values and datatype-safe.",
  "test_steps": [
    {{"index": number, "action": string, "data": string (exact SQL SELECT), "expected_result": "0 rows returned"}}
  ]
}}

Requirements:
- Every compared literal MUST come from the COLUMN TYPE TABLE (or the spec lovs)
- Integer/real columns compared to UNQUOTED numeric literals; text columns to quoted text
- Each test_step.data must be a SELECT present verbatim in sql_script
- Return valid JSON only"""

        data = (
            self._extract_json(
                self._chat(
                    system, user, call_type="etl_generate_sql", story_key=story_key
                )
            )
            or {}
        )

        # Deterministic guardrail: unquote numeric literals for numeric columns.
        sql_script = self._normalize_numeric_literals(
            data.get("sql_script") or "", numeric_cols
        )
        steps: List[ETLTestStep] = []
        for s in data.get("test_steps") or []:
            sd = self._to_dict(s)
            sd["data"] = self._normalize_numeric_literals(
                str(sd.get("data") or ""), numeric_cols
            )
            steps.append(ETLTestStep(**sd))

        return ETLGenerateResponse(
            test_id=str(uuid.uuid4()),
            story_key=story_key,
            target_table=data.get("target_table") or target_table,
            sql_script=sql_script,
            test_steps=steps,
            generated_by="Mistral AI",
            created_at=datetime.utcnow(),
        )

    # Back-compat alias used by some orchestrator code paths.
    def generate_sql_script(self, spec) -> ETLGenerateResponse:
        return self.generate(spec)

    # ================================================================== #
    # Private: schema grounding helpers                                  #
    # ================================================================== #
    @staticmethod
    def _build_type_table(schema_context: Dict[str, Any]):
        """Return (human_readable_table, numeric_column_names).
        numeric_column_names includes both bare and table-qualified names."""
        lines: List[str] = []
        numeric: Set[str] = set()
        if not schema_context:
            return "(no schema context available)", numeric
        for table, tinfo in sorted(schema_context.items()):
            if not isinstance(tinfo, dict):
                continue
            for col in tinfo.get("columns", []) or []:
                name = col.get("name", "")
                storage = col.get("storage_types") or []
                declared = col.get("declared_type", "") or ""
                stype = storage[0] if storage else (declared.lower() or "text")
                vals = col.get("distinct_values", [])
                # Render values with correct quoting for the hint.
                rendered = ", ".join(
                    (str(v) if isinstance(v, (int, float)) else f"'{v}'") for v in vals
                )
                lines.append(
                    f"- {table}.{name}: {stype} (declared {declared or 'n/a'}), "
                    f"values [{rendered}]"
                )
                if any(
                    s in _NUMERIC_STORAGE for s in [s.lower() for s in storage]
                ) or declared.lower() in (
                    "integer",
                    "int",
                    "real",
                    "numeric",
                    "bigint",
                    "smallint",
                ):
                    numeric.add(name)
                    numeric.add(f"{table}.{name}")
        return ("\n".join(lines) if lines else "(no columns found)", numeric)

    @staticmethod
    def _normalize_numeric_literals(sql: str, numeric_cols: Set[str]) -> str:
        """Deterministically unquote integer/real literals that are compared
        against a numeric column, e.g.  is_active = '1'  ->  is_active = 1.
        Handles optional table alias/qualifier before the column name."""
        if not sql or not numeric_cols:
            return sql
        bare = sorted({c.split(".")[-1] for c in numeric_cols}, key=len, reverse=True)
        for col in bare:
            if not col:
                continue
            # (alias.)?col <op> 'number'   ->   ... <op> number
            pattern = re.compile(
                r"((?:[A-Za-z_]\w*\.)?"
                + re.escape(col)
                + r"\s*(?:=|<>|!=|>=|<=|>|<)\s*)'(-?\d+(?:\.\d+)?)'"
            )
            sql = pattern.sub(lambda m: m.group(1) + m.group(2), sql)
        return sql

    # ================================================================== #
    # Private: LLM Communication                                         #
    # ================================================================== #
    def _chat(
        self, system: str, user: str, call_type: str = "etl_chat", story_key: str = ""
    ) -> str:
        "Call Mistral API with system and user messages (deterministic)."
        if not self.client:
            raise RuntimeError("Mistral client not initialized")
        kwargs = dict(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0,
            response_format={"type": "json_object"},
        )
        try:
            resp = self.client.chat.complete(random_seed=_SEED, **kwargs)
        except TypeError:
            resp = self.client.chat.complete(**kwargs)
        # Record token consumption + cost for the ETL module (best-effort).
        if record_usage is not None:
            try:
                record_usage(
                    call_type=call_type,
                    model=self.model,
                    usage=getattr(resp, "usage", None),
                    module=MODULE_ETL,
                    story_key=story_key,
                )
            except Exception as exc:  # never break generation on tracking
                logger.warning("Token usage tracking failed (%s).", exc)
        return resp.choices[0].message.content

    @staticmethod
    def _to_dict(obj) -> Dict[str, Any]:
        if isinstance(obj, dict):
            return dict(obj)
        if hasattr(obj, "model_dump"):
            return obj.model_dump()
        if hasattr(obj, "dict"):
            return obj.dict()
        return dict(obj or {})

    @staticmethod
    def _sanitize(text: str) -> str:
        "Escape control characters inside JSON string values."
        out = []
        in_str = False
        escaped = False
        for ch in text:
            if in_str:
                if escaped:
                    out.append(ch)
                    escaped = False
                    continue
                if ch == "\\":
                    out.append(ch)
                    escaped = True
                    continue
                if ch == '"':
                    in_str = False
                    out.append(ch)
                    continue
                if ch == "\n":
                    out.append("\\n")
                elif ch == "\r":
                    out.append("\\r")
                elif ch == "\t":
                    out.append("\\t")
                elif ord(ch) < 0x20:
                    out.append("\\u%04x" % ord(ch))
                else:
                    out.append(ch)
            else:
                if ch == '"':
                    in_str = True
                out.append(ch)
        return "".join(out)

    @classmethod
    def _extract_json(cls, text: str) -> Any:
        "Extract JSON from response, handling markdown fences and control chars."
        fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
        if fence:
            text = fence.group(1)
        text = (text or "").strip()
        idxs = [i for i in [text.find("{"), text.find("[")] if i != -1]
        if idxs:
            text = text[min(idxs) :]
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return json.loads(cls._sanitize(text))


# Singleton instance
_etl_generation_agent: Optional[ETLGenerationAgent] = None


def get_etl_generation_agent(
    api_key: str = "", model: str = "mistral-large-latest"
) -> ETLGenerationAgent:
    "Get or create ETL Generation Agent singleton."
    global _etl_generation_agent
    if _etl_generation_agent is None:
        _etl_generation_agent = ETLGenerationAgent(api_key=api_key, model=model)
    return _etl_generation_agent
