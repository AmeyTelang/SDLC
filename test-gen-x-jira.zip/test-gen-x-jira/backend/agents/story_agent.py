"""Story -> Xray test case synthesis.

Accuracy strategy
-----------------
Test-case fidelity is the whole point of this agent, so it does not simply
ask a model for steps and hope. It runs a four-stage pipeline:

1. **Ground** - ``bdd_parser`` deterministically locates and parses the
   acceptance criteria. That parse is the oracle: every scenario it finds
   MUST appear in the generated test case.
2. **Synthesise** - the model converts each scenario into Xray
   Action / Data / Expected Result steps under a strict JSON contract at
   temperature 0, and self-reports per-step confidence.
3. **Validate & repair** - the result is scored against the oracle for
   scenario coverage, field completeness and lexical grounding in the source
   criteria. If defects are found, the model gets one targeted repair pass
   naming exactly what is wrong, then is re-scored.
4. **Fall back** - if the model is unavailable or never converges, a
   deterministic Given/When/Then -> Action/Data/Expected mapping produces a
   usable, clearly-labelled low-confidence draft. The workflow never dead-ends.

The resulting :class:`TestCaseQuality` is surfaced to the reviewer, so a
low-confidence draft is visibly a draft rather than silently wrong.
"""

from __future__ import annotations

import logging
import re
from typing import Dict, List, Optional, Sequence, Set, Tuple

from agents import bdd_parser
from agents.bdd_parser import BddFeature, BddScenario, BddStep
from agents.llm_client import MODULE_AUTHORING, llm_client
from models.testcase_schemas import (
    ConfidenceBand,
    GeneratedTestCase,
    TestCaseGenerateRequest,
    TestCaseQuality,
    XrayStep,
)

logger = logging.getLogger("testgenx.story")

CALL_TYPE_SYNTHESIS = "testcase.synthesis"
CALL_TYPE_REPAIR = "testcase.repair"

MAX_REPAIRS = 1
MAX_CRITERIA_CHARS = 12000

_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "but",
    "by",
    "for",
    "from",
    "given",
    "has",
    "have",
    "if",
    "in",
    "into",
    "is",
    "it",
    "of",
    "on",
    "or",
    "should",
    "than",
    "that",
    "the",
    "then",
    "there",
    "this",
    "to",
    "when",
    "with",
    "will",
    "shall",
    "user",
    "system",
}

SYNTHESIS_SYSTEM = """You are a senior QA analyst authoring an Xray manual test case from a user story's BDD acceptance criteria.

CONTRACT - follow exactly:
- Ground every step in the supplied acceptance criteria. Never invent a requirement, field, value, screen or rule that is not stated or directly implied by the criteria.
- Cover EVERY scenario listed. Produce at least one step per scenario; produce separate steps when a scenario has multiple distinct actions.
- Map Gherkin to Xray columns:
  * Given  -> setup/navigation step, or fold into `precondition` when it is shared by all scenarios.
  * When   -> `action` (an imperative instruction a tester performs).
  * Then   -> `expected_result` on the step that produces it.
- `action` MUST be an imperative instruction ("Enter ... into ...", "Click ...", "Navigate to ..."). Never phrase it as a question or a passive statement.
- `data` holds concrete literals only (usernames, amounts, dates, payloads). Use "" when the criteria state no value. Never fabricate a value.
- `expected_result` MUST be observable and specific. Never write "works as expected".
- `source_scenario` MUST exactly match one of the supplied scenario names.
- `confidence` is YOUR honest 0.0-1.0 certainty that the step faithfully reflects the criteria. Use a low value when the criteria are vague; do not inflate.
- `rationale` is at most 12 words explaining the mapping.

Return STRICT JSON ONLY, no prose, matching:
{
  "summary": "<concise test case title>",
  "description": "<1-2 sentence purpose>",
  "precondition": "<shared setup, or empty string>",
  "priority": "High|Medium|Low",
  "labels": ["..."],
  "confidence": 0.0,
  "steps": [
    {
      "index": 1,
      "action": "...",
      "data": "",
      "expected_result": "...",
      "source_scenario": "...",
      "source_keywords": ["given","when","then"],
      "confidence": 0.0,
      "rationale": "..."
    }
  ]
}"""

REPAIR_SYSTEM = """You are correcting a draft Xray test case that failed validation against its source acceptance criteria.

Fix ONLY the listed defects. Preserve every step that is already correct, including its wording and order. Do not renumber arbitrarily - keep indexes sequential from 1. Do not invent requirements to satisfy a defect; if the criteria genuinely do not specify something, say so in `rationale` and set a low `confidence`.

Return the COMPLETE corrected test case as STRICT JSON in the same schema as the draft. No prose."""


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------
def _tokens(text: str) -> Set[str]:
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", (text or "").lower())
    return {w for w in words if w not in _STOPWORDS}


def _scenario_block(feature: BddFeature) -> str:
    lines: List[str] = []
    if feature.feature:
        lines.append(f"Feature: {feature.feature}")
    if feature.background:
        lines.append("Background (applies to every scenario):")
        lines.extend(f"  {s.raw_keyword.title()} {s.text}" for s in feature.background)
    for scenario in feature.scenarios:
        lines.append("")
        lines.append(f"Scenario: {scenario.name}")
        if scenario.example:
            pairs = ", ".join(f"{k}={v}" for k, v in scenario.example.items())
            lines.append(f"  (example data: {pairs})")
        for step in scenario.steps:
            lines.append(f"  {step.raw_keyword.title()} {step.text}")
    return "\n".join(lines)


def _truncate(text: str, limit: int = MAX_CRITERIA_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n... [truncated]"


def _normalise_scenario_name(name: str, known: Sequence[str]) -> str:
    """Snap a model-supplied scenario name back onto a real one."""
    if not name:
        return known[0] if known else ""
    probe = name.strip().lower()
    for candidate in known:
        if candidate.strip().lower() == probe:
            return candidate
    # Tolerate paraphrase: pick the best token-overlap match above a floor.
    probe_tokens = _tokens(probe)
    best, best_score = "", 0.0
    for candidate in known:
        candidate_tokens = _tokens(candidate)
        if not candidate_tokens:
            continue
        overlap = len(probe_tokens & candidate_tokens) / len(candidate_tokens)
        if overlap > best_score:
            best, best_score = candidate, overlap
    return best if best_score >= 0.5 else (known[0] if known else name.strip())


# ----------------------------------------------------------------------
# Scoring
# ----------------------------------------------------------------------
def score_test_case(
    case: GeneratedTestCase,
    feature: BddFeature,
    criteria_text: str,
    model_self_report: float,
    generated_by: str,
    repair_attempts: int,
) -> TestCaseQuality:
    """Grade a synthesised case against the deterministic parse."""
    warnings: List[str] = []
    expected = [s.name for s in feature.scenarios]
    covered_raw = {s.source_scenario for s in case.steps if s.source_scenario}
    covered = [name for name in expected if name in covered_raw]
    missing = [name for name in expected if name not in covered_raw]

    coverage = (
        (len(covered) / len(expected)) if expected else (1.0 if case.steps else 0.0)
    )
    if missing:
        warnings.append(
            f"{len(missing)} acceptance scenario(s) have no corresponding step."
        )

    # Completeness: every step needs an action and an observable expectation.
    if case.steps:
        complete = sum(
            1 for s in case.steps if s.action.strip() and s.expected_result.strip()
        )
        completeness = complete / len(case.steps)
        vague = [
            s.index
            for s in case.steps
            if re.search(
                r"\b(works? as expected|as expected|correctly|properly|successful(ly)?)\s*\.?$",
                s.expected_result.strip(),
                re.I,
            )
        ]
        if vague:
            completeness *= 0.8
            warnings.append(
                f"Step(s) {', '.join(str(i) for i in vague)} have a non-observable expected result."
            )
        if not case.summary.strip():
            warnings.append("Test case has no summary.")
            completeness *= 0.9
    else:
        completeness = 0.0
        warnings.append("No steps were produced.")

    # Grounding: how much of the step vocabulary actually comes from the criteria.
    source_tokens = _tokens(criteria_text)
    step_tokens = _tokens(
        " ".join(f"{s.action} {s.data} {s.expected_result}" for s in case.steps)
    )
    if step_tokens and source_tokens:
        grounding = len(step_tokens & source_tokens) / len(step_tokens)
    else:
        grounding = 0.0
    if grounding < 0.35 and case.steps:
        warnings.append(
            "Step wording diverges sharply from the acceptance criteria - review for invented detail."
        )

    self_report = max(0.0, min(1.0, model_self_report or 0.0))
    if not self_report and case.steps:
        self_report = sum(s.confidence for s in case.steps) / len(case.steps)

    score = (
        0.40 * coverage
        + 0.25 * completeness
        + 0.20 * min(1.0, grounding / 0.6)
        + 0.15 * self_report
    )
    if generated_by == "deterministic":
        score = min(score, 0.55)
        warnings.append(
            "Produced by the deterministic fallback - no model was available. Review every step."
        )
    score = round(max(0.0, min(1.0, score)), 3)

    quality = TestCaseQuality(
        score=score,
        scenario_coverage=round(coverage, 3),
        covered_scenarios=covered,
        missing_scenarios=missing,
        grounding=round(grounding, 3),
        completeness=round(completeness, 3),
        model_self_report=round(self_report, 3),
        warnings=warnings,
        repair_attempts=repair_attempts,
        generated_by=generated_by,
    )
    return quality.recompute_band()


def _defects(quality: TestCaseQuality, case: GeneratedTestCase) -> List[str]:
    defects: List[str] = []
    if quality.missing_scenarios:
        defects.append(
            "These scenarios are NOT covered by any step and must be added: "
            + "; ".join(quality.missing_scenarios)
        )
    for step in case.steps:
        if not step.action.strip():
            defects.append(f"Step {step.index} has an empty action.")
        if not step.expected_result.strip():
            defects.append(f"Step {step.index} has an empty expected_result.")
        elif re.search(
            r"\b(works? as expected|as expected|correctly|properly)\s*\.?$",
            step.expected_result.strip(),
            re.I,
        ):
            defects.append(
                f"Step {step.index} expected_result '{step.expected_result}' is not observable; "
                "state the concrete outcome from the criteria."
            )
    if not case.summary.strip():
        defects.append("summary is empty.")
    if quality.grounding < 0.35 and case.steps:
        defects.append(
            "Several steps use vocabulary absent from the criteria; re-anchor them to the stated wording."
        )
    return defects


# ----------------------------------------------------------------------
# Deterministic fallback
# ----------------------------------------------------------------------
def _fallback_case(
    feature: BddFeature, summary_hint: str, story_key: str
) -> GeneratedTestCase:
    """Given/When/Then -> Action/Data/Expected without a model."""
    precondition = " ".join(
        s.text.rstrip(".") + "." for s in feature.background
    ).strip()
    steps: List[XrayStep] = []
    index = 1

    for scenario in feature.scenarios:
        givens = scenario.givens
        whens = scenario.whens
        thens = scenario.thens

        setup = "; ".join(g.text for g in givens)
        expectation = " ".join(t.text.rstrip(".") + "." for t in thens).strip()
        data = ""
        if scenario.example:
            data = ", ".join(f"{k}={v}" for k, v in scenario.example.items())

        if not whens:
            steps.append(
                XrayStep(
                    index=index,
                    action=(setup or scenario.name).strip(),
                    data=data,
                    expected_result=expectation
                    or "State observable per the acceptance criteria.",
                    source_scenario=scenario.name,
                    source_keywords=["given", "then"],
                    confidence=0.4,
                    rationale="Deterministic mapping; no When clause present.",
                )
            )
            index += 1
            continue

        for position, when in enumerate(whens):
            is_last = position == len(whens) - 1
            action = when.text
            if position == 0 and setup:
                action = (
                    f"With {setup}, {action[0].lower() + action[1:]}"
                    if action
                    else setup
                )
            steps.append(
                XrayStep(
                    index=index,
                    action=action.strip(),
                    data=data if position == 0 else "",
                    expected_result=(
                        expectation
                        if is_last
                        else "The action is accepted and the flow continues."
                    ),
                    source_scenario=scenario.name,
                    source_keywords=["given", "when", "then"] if is_last else ["when"],
                    confidence=0.45,
                    rationale="Deterministic Gherkin-to-Xray mapping.",
                )
            )
            index += 1

    if not steps:
        steps.append(
            XrayStep(
                index=1,
                action=(
                    feature.raw or summary_hint or "Execute the acceptance criteria."
                ).strip()[:400],
                data="",
                expected_result="The behaviour described in the story is observed.",
                source_scenario="Unstructured criteria",
                confidence=0.25,
                rationale="Criteria were not in BDD form.",
            )
        )

    title = summary_hint or feature.feature or f"{story_key} acceptance test"
    return GeneratedTestCase(
        summary=f"{title}".strip()[:240],
        description=f"Automated draft for {story_key} derived from the story acceptance criteria.",
        precondition=precondition,
        priority="Medium",
        labels=["testgenx", "bdd"],
        steps=steps,
    )


# ----------------------------------------------------------------------
# Payload -> model
# ----------------------------------------------------------------------
def _coerce(
    payload: dict, known_scenarios: Sequence[str]
) -> Tuple[GeneratedTestCase, float]:
    raw_steps = payload.get("steps")
    steps: List[XrayStep] = []
    if isinstance(raw_steps, list):
        for position, item in enumerate(raw_steps, start=1):
            if not isinstance(item, dict):
                continue
            item = dict(item)
            item["index"] = position
            item["source_scenario"] = _normalise_scenario_name(
                str(item.get("source_scenario") or ""), known_scenarios
            )
            keywords = item.get("source_keywords")
            if isinstance(keywords, str):
                item["source_keywords"] = [keywords]
            elif not isinstance(keywords, list):
                item["source_keywords"] = []
            try:
                steps.append(XrayStep(**item))
            except Exception as exc:
                logger.info("Discarding malformed step %d (%s).", position, exc)

    case = GeneratedTestCase(
        summary=payload.get("summary") or "",
        description=payload.get("description") or "",
        precondition=payload.get("precondition") or "",
        priority=(payload.get("priority") or "Medium"),
        labels=payload.get("labels") or [],
        steps=steps,
    )
    if case.priority not in ("High", "Medium", "Low"):
        case.priority = "Medium"

    try:
        self_report = float(payload.get("confidence") or 0.0)
    except (TypeError, ValueError):
        self_report = 0.0
    return case, self_report


def _renumber(case: GeneratedTestCase) -> GeneratedTestCase:
    for position, step in enumerate(case.steps, start=1):
        step.index = position
    return case


# ----------------------------------------------------------------------
# Agent
# ----------------------------------------------------------------------
class StoryAgent:
    name = "story"

    def parse(self, description) -> Tuple[str, BddFeature, List[str]]:
        criteria, feature = bdd_parser.parse_story(description)
        warnings: List[str] = []
        if not criteria.strip():
            warnings.append(
                "The story description is empty - nothing to derive a test from."
            )
        elif not feature.scenarios:
            warnings.append(
                "No Given/When/Then scenarios were detected. The criteria will be interpreted "
                "as free text, which lowers confidence."
            )
        elif not feature.structured:
            warnings.append(
                "Criteria use Given/When/Then but have no explicit 'Scenario:' headings; "
                "scenarios were inferred."
            )
        return criteria, feature, warnings

    # ------------------------------------------------------------------
    def generate(self, req: TestCaseGenerateRequest) -> GeneratedTestCase:
        criteria = (req.acceptance_criteria or "").strip()
        if not criteria:
            criteria, _, _ = self.parse(req.raw_description)

        feature = bdd_parser.parse_bdd(criteria)
        known = [s.name for s in feature.scenarios]
        criteria_for_model = _truncate(_scenario_block(feature) or criteria)

        if not llm_client.available:
            case = _renumber(_fallback_case(feature, req.summary, req.story_key))
            case.quality = score_test_case(
                case, feature, criteria, 0.0, "deterministic", 0
            )
            return case

        user_prompt = self._synthesis_prompt(req, criteria_for_model, known)
        payload = llm_client.chat_json(
            SYNTHESIS_SYSTEM,
            user_prompt,
            temperature=0.0,
            call_type=CALL_TYPE_SYNTHESIS,
            story_key=req.story_key,
            module=MODULE_AUTHORING,
        )

        if not payload:
            logger.info(
                "Synthesis returned nothing for %s; using fallback.", req.story_key
            )
            case = _renumber(_fallback_case(feature, req.summary, req.story_key))
            case.quality = score_test_case(
                case, feature, criteria, 0.0, "deterministic", 0
            )
            return case

        case, self_report = _coerce(payload, known)
        case = _renumber(case)
        quality = score_test_case(case, feature, criteria, self_report, "llm", 0)

        attempts = 0
        while attempts < MAX_REPAIRS and quality.band != ConfidenceBand.HIGH:
            defects = _defects(quality, case)
            if not defects:
                break
            attempts += 1
            logger.info(
                "Repairing test case for %s (attempt %d): %d defect(s).",
                req.story_key,
                attempts,
                len(defects),
            )
            repaired = llm_client.chat_json(
                REPAIR_SYSTEM,
                self._repair_prompt(case, defects, criteria_for_model, known),
                temperature=0.0,
                call_type=CALL_TYPE_REPAIR,
                story_key=req.story_key,
                module=MODULE_AUTHORING,
            )
            if not repaired:
                break
            candidate, candidate_report = _coerce(repaired, known)
            candidate = _renumber(candidate)
            candidate_quality = score_test_case(
                candidate, feature, criteria, candidate_report, "llm", attempts
            )
            # Only accept a repair that genuinely improves the case.
            if candidate_quality.score > quality.score and candidate.steps:
                case, quality = candidate, candidate_quality
            else:
                quality.repair_attempts = attempts
                break

        if not case.steps:
            case = _renumber(_fallback_case(feature, req.summary, req.story_key))
            quality = score_test_case(
                case, feature, criteria, 0.0, "deterministic", attempts
            )

        if not case.summary.strip():
            case.summary = (req.summary or feature.feature or req.story_key).strip()[
                :240
            ]

        case.quality = quality
        return case

    # ------------------------------------------------------------------
    @staticmethod
    def _synthesis_prompt(
        req: TestCaseGenerateRequest, criteria: str, known: Sequence[str]
    ) -> str:
        parts = [
            f"STORY KEY: {req.story_key}",
            f"STORY SUMMARY: {req.summary or '(none)'}",
        ]
        if req.aut_url:
            parts.append(f"APPLICATION UNDER TEST: {req.aut_url}")
        parts.append("")
        parts.append("ACCEPTANCE CRITERIA (the only source of truth):")
        parts.append(criteria)
        parts.append("")
        if known:
            parts.append(
                "SCENARIOS THAT MUST EACH BE COVERED (use these exact strings in source_scenario):"
            )
            parts.extend(f"- {name}" for name in known)
        else:
            parts.append(
                "No discrete scenarios were detected. Derive the smallest set of steps that "
                "verifies the stated behaviour, and set source_scenario to 'Unstructured criteria'."
            )
        if req.feedback:
            parts.append("")
            parts.append(
                "REVIEWER FEEDBACK from the previous iteration - address it explicitly:"
            )
            parts.append(req.feedback)
        return "\n".join(parts)

    @staticmethod
    def _repair_prompt(
        case: GeneratedTestCase,
        defects: Sequence[str],
        criteria: str,
        known: Sequence[str],
    ) -> str:
        import json

        draft = {
            "summary": case.summary,
            "description": case.description,
            "precondition": case.precondition,
            "priority": case.priority,
            "labels": case.labels,
            "steps": [
                {
                    "index": s.index,
                    "action": s.action,
                    "data": s.data,
                    "expected_result": s.expected_result,
                    "source_scenario": s.source_scenario,
                    "confidence": s.confidence,
                    "rationale": s.rationale,
                }
                for s in case.steps
            ],
        }
        return "\n".join(
            [
                "ACCEPTANCE CRITERIA (source of truth):",
                criteria,
                "",
                "SCENARIOS THAT MUST EACH BE COVERED:",
                *[f"- {name}" for name in known],
                "",
                "CURRENT DRAFT:",
                json.dumps(draft, indent=2),
                "",
                "DEFECTS TO FIX:",
                *[f"- {defect}" for defect in defects],
            ]
        )


story_agent = StoryAgent()
