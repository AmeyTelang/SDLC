"""
token_tracker.py  (backend ROOT — top-level module)
----------------------------------------------------
Shared AI token + cost tracker for TestGenX. Imported by the AI agents:

    * agents/etl_generation_agent.py  -> ETL Validation  (module="etl")
    * agents/etl_execution_agent.py   -> ETL Validation  (module="etl")
    * agents/llm_client.py            -> Web Studio       (module="web-studio")

Because this file sits at the backend root (same level as `config.py` /
`models/`), agents import it ABSOLUTELY:  `from token_tracker import ...`.

One shared SQLite table (`ai_token_usage`) tagged with `module` powers the
shared "Token Usage" header page. DB path resolution (first hit wins):
    1. env TESTGENX_TOKEN_DB   (recommended: absolute path)
    2. env TOKEN_DB_PATH
    3. config.TOKEN_DB_PATH / config.DB_PATH
    4. fallback "testgenx.db" in CWD
"""

import os
import sqlite3
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

_CUSTOM_PRICING: Dict[str, tuple] = {}


def _resolve_db_path() -> str:
    env = os.getenv("TESTGENX_TOKEN_DB") or os.getenv("TOKEN_DB_PATH")
    if env:
        return env
    try:
        import config as _cfg  # backend root config

        global _CUSTOM_PRICING
        _CUSTOM_PRICING = getattr(_cfg, "MISTRAL_PRICING", None) or {}
        p = getattr(_cfg, "TOKEN_DB_PATH", None) or getattr(_cfg, "DB_PATH", None)
        if p:
            return p
    except Exception:
        pass
    return "testgenx.db"


_DB_PATH = _resolve_db_path()

MODULE_ETL = "etl"
MODULE_WEB_STUDIO = "web-studio"
MODULE_LABELS = {
    MODULE_ETL: "Backend ETL Studio",
    MODULE_WEB_STUDIO: "Web Studio",
}

# USD per 1M tokens: (input_rate, output_rate). Longest substring match wins.
# Source: Mistral AI Studio pricing, 2026.
_DEFAULT_PRICING: Dict[str, tuple] = {
    "mistral-medium-3.5": (1.50, 7.50),
    "mistral-medium": (0.40, 2.00),
    "mistral-large": (0.50, 1.50),
    "mistral-small": (0.15, 0.60),
    "magistral-medium": (2.00, 5.00),
    "magistral-small": (0.50, 1.50),
    "codestral": (0.30, 0.90),
    "devstral": (0.40, 2.00),
    "ministral-8b": (0.15, 0.15),
    "ministral-3b": (0.10, 0.10),
    "open-mistral-nemo": (0.02, 0.04),
}
_PRICING: Dict[str, tuple] = {**_DEFAULT_PRICING, **_CUSTOM_PRICING}
_lock = threading.Lock()


def _rates_for(model: str) -> tuple:
    if not model:
        return (0.0, 0.0)
    m = model.lower()
    best = ""
    for key in _PRICING:
        if key in m and len(key) > len(best):
            best = key
    return _PRICING[best] if best else (0.0, 0.0)


def compute_cost(
    model: str, prompt_tokens: int, completion_tokens: int
) -> Dict[str, float]:
    in_rate, out_rate = _rates_for(model)
    input_cost = (prompt_tokens or 0) / 1_000_000 * in_rate
    output_cost = (completion_tokens or 0) / 1_000_000 * out_rate
    return {
        "input_cost": round(input_cost, 8),
        "output_cost": round(output_cost, 8),
        "total_cost": round(input_cost + output_cost, 8),
    }


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def delete_db() -> None:
    with _lock, _connect() as conn:
        conn.execute("""
              DROP TABLE IF EXISTS ai_token_usage""")


def init_db() -> None:
    """Create table if missing; migrate legacy tables (adds `module`)."""
    with _lock, _connect() as conn:
        # conn.execute("""
        #          DROP TABLE IF EXISTS ai_token_usage""")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ai_token_usage (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at        TEXT    NOT NULL,
                module            TEXT    NOT NULL DEFAULT 'etl',
                call_type         TEXT    NOT NULL,
                model             TEXT    NOT NULL,
                story_key         TEXT,
                prompt_tokens     INTEGER NOT NULL DEFAULT 0,
                completion_tokens INTEGER NOT NULL DEFAULT 0,
                total_tokens      INTEGER NOT NULL DEFAULT 0,
                input_cost        REAL    NOT NULL DEFAULT 0,
                output_cost       REAL    NOT NULL DEFAULT 0,
                total_cost        REAL    NOT NULL DEFAULT 0,
                success           INTEGER NOT NULL DEFAULT 1
            )
            """)
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(ai_token_usage)")}
        if "module" not in cols:
            conn.execute(
                "ALTER TABLE ai_token_usage ADD COLUMN module TEXT NOT NULL DEFAULT 'etl'"
            )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_usage_module ON ai_token_usage (module)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_usage_story ON ai_token_usage (story_key)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_usage_created ON ai_token_usage (created_at)"
        )


def normalize_usage(raw: Any) -> Dict[str, int]:
    """Coerce a provider usage object (SDK model OR dict) into a plain dict."""
    if raw is None:
        return {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    get = raw.get if isinstance(raw, dict) else (lambda k, d=0: getattr(raw, k, d))
    prompt = int(get("prompt_tokens", 0) or 0)
    completion = int(get("completion_tokens", 0) or 0)
    total = int(get("total_tokens", 0) or 0) or (prompt + completion)
    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total,
    }


def record_usage(
    call_type: str,
    model: str,
    usage: Optional[Any],
    module: str = MODULE_ETL,
    story_key: str = "",
    success: bool = True,
) -> Dict[str, Any]:
    """Persist one AI call's tokens + cost. Returns the stored row."""
    u = usage if isinstance(usage, dict) else normalize_usage(usage)
    prompt = int(u.get("prompt_tokens") or 0)
    completion = int(u.get("completion_tokens") or 0)
    total = int(u.get("total_tokens") or (prompt + completion))
    cost = compute_cost(model, prompt, completion)
    row = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "module": module or MODULE_ETL,
        "call_type": call_type,
        "model": model,
        "story_key": story_key or "",
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": total,
        "input_cost": cost["input_cost"],
        "output_cost": cost["output_cost"],
        "total_cost": cost["total_cost"],
        "success": 1 if success else 0,
    }
    init_db()
    with _lock, _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO ai_token_usage
                (created_at, module, call_type, model, story_key, prompt_tokens,
                 completion_tokens, total_tokens, input_cost, output_cost,
                 total_cost, success)
            VALUES
                (:created_at, :module, :call_type, :model, :story_key, :prompt_tokens,
                 :completion_tokens, :total_tokens, :input_cost, :output_cost,
                 :total_cost, :success)
            """,
            row,
        )
        row["id"] = cur.lastrowid
    return row


# --------------------------------------------------------------------------- #
# Reporting helpers for the shared Token Usage page                           #
# --------------------------------------------------------------------------- #
def _where(module: Optional[str], story_key: Optional[str]) -> tuple:
    clauses, params = [], []
    if module and module != "all":
        clauses.append("module = ?")
        params.append(module)
    if story_key:
        clauses.append("story_key = ?")
        params.append(story_key)
    sql = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    return sql, params


def get_usage(module=None, story_key=None, limit: int = 200) -> List[Dict[str, Any]]:
    init_db()
    where, params = _where(module, story_key)
    q = f"SELECT * FROM ai_token_usage{where} ORDER BY id DESC LIMIT ?"
    with _connect() as conn:
        return [dict(r) for r in conn.execute(q, params + [limit]).fetchall()]


def get_summary(module=None, story_key=None) -> Dict[str, Any]:
    init_db()
    where, params = _where(module, story_key)
    with _connect() as conn:
        totals = conn.execute(
            f"""SELECT COUNT(*) AS calls,
                       COALESCE(SUM(prompt_tokens),0)     AS prompt_tokens,
                       COALESCE(SUM(completion_tokens),0) AS completion_tokens,
                       COALESCE(SUM(total_tokens),0)      AS total_tokens,
                       COALESCE(SUM(total_cost),0)        AS total_cost
                FROM ai_token_usage{where}""",
            params,
        ).fetchone()
        by_module = conn.execute(
            f"""SELECT module, COUNT(*) AS calls,
                       COALESCE(SUM(total_tokens),0) AS total_tokens,
                       COALESCE(SUM(total_cost),0)   AS total_cost
                FROM ai_token_usage{where}
                GROUP BY module ORDER BY total_cost DESC""",
            params,
        ).fetchall()
        by_type = conn.execute(
            f"""SELECT module, call_type, COUNT(*) AS calls,
                       COALESCE(SUM(total_tokens),0) AS total_tokens,
                       COALESCE(SUM(total_cost),0)   AS total_cost
                FROM ai_token_usage{where}
                GROUP BY module, call_type ORDER BY total_cost DESC""",
            params,
        ).fetchall()
    return {
        "module": module or "all",
        "calls": totals["calls"],
        "prompt_tokens": totals["prompt_tokens"],
        "completion_tokens": totals["completion_tokens"],
        "total_tokens": totals["total_tokens"],
        "total_cost": round(totals["total_cost"] or 0.0, 6),
        "by_module": [
            {**dict(r), "label": MODULE_LABELS.get(r["module"], r["module"])}
            for r in by_module
        ],
        "by_call_type": [dict(r) for r in by_type],
    }
