from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
# BASE_DIR = Path("C:/Users/Sanjeev/Desktop/Sushavon/hydra-backup")
GENERATED_DIR = BASE_DIR / "generated_tests"
GENERATED_DIR.mkdir(exist_ok=True)
EVIDENCE_DIR = GENERATED_DIR / "evidence"
EVIDENCE_DIR.mkdir(exist_ok=True)
REPORTS_DIR = BASE_DIR / "reports"
REPORTS_DIR.mkdir(exist_ok=True)
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_FILE = DATA_DIR / "db.json"

# LLM
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "mistral-large-latest")
FORCE_FALLBACK = os.getenv("TESTGENX_FORCE_FALLBACK", "false").lower() in {
    "1",
    "true",
    "yes",
}
LLM_TIMEOUT_SECONDS = int(os.getenv("TESTGENX_LLM_TIMEOUT", "45"))

# CORS
ALLOWED_ORIGINS = os.getenv(
    "TESTGENX_ALLOWED_ORIGINS",
    "http://localhost:9090,http://127.0.0.1:5173",
).split(",")

# Branding
ORG_NAME = os.getenv("TESTGENX_ORG_NAME", "TCS · AI-led Testing")
REPORT_CLASSIFICATION = os.getenv(
    "TESTGENX_REPORT_CLASSIFICATION", "Confidential — POC"
)

# Execution
DEFAULT_HEADLESS = os.getenv("TESTGENX_HEADLESS", "true").lower() in {
    "1",
    "true",
    "yes",
}
EXECUTION_TIMEOUT_SECONDS = int(os.getenv("TESTGENX_EXEC_TIMEOUT", "120"))
