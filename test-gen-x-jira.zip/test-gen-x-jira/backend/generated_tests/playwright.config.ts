import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: ".",
  timeout: 30000,
  use: { headless: true, screenshot: "on", trace: "retain-on-failure" },
  reporter: [["json", { outputFile: "results.json" }], ["list"]],
});
