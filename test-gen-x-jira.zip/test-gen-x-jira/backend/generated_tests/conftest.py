import importlib.util


def _has(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None


def pytest_configure(config):
    # Friendly, explicit guidance surfaced in the run logs (not a crash).
    if not _has("pytest_playwright"):
        print(
            "\n[TestGenX] pytest-playwright is not installed in this environment.\n"
            "          Install it to run real browser tests:\n"
            "            pip install pytest-playwright\n"
            "            playwright install chromium\n"
        )
