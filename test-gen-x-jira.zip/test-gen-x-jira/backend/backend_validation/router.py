from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from . import xray_validator
from . import db
from . import seed as seeder

router = APIRouter(tags=["xray-validation"])

# ---- single shared connection (seeded at startup) ------------------------- #
DB_PATH = os.environ.get("TGX_VALIDATION_DB", "data/validation.db")
_conn = None


def get_conn():
    global _conn
    if _conn is None:
        _conn = db.connect(DB_PATH)
    return _conn


def seed_on_startup(drop: bool = True) -> Dict[str, int]:
    """Create + seed the source/target tables. Call from the app startup event."""
    return seeder.seed_startup(get_conn(), drop=drop)


# --------------------------------------------------------------------------- #
# Models
# --------------------------------------------------------------------------- #
class Step(BaseModel):
    action: str = ""
    data: str = ""
    expected: str = ""


class LoadReq(BaseModel):
    story_key: str
    test_key: Optional[str] = None
    jira_secret: Optional[str] = None


class ParseReq(BaseModel):
    story_description: str


class ValidateReq(BaseModel):
    entity: Optional[str] = None
    story_description: str
    xray_steps: List[Step] = Field(default_factory=list)
    test_key: str
    source_table: str = "source.product"
    target_table: str = "target.product"
    source_key: str = "product_code"
    target_key: str = "code"
    exclude_col: str = "product_type"
    exclude_value: str = "Device"
    prefer_ai: bool = True


class ImportReq(BaseModel):
    result: Dict[str, Any]
    jira_secret: Optional[str] = None


# --------------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------------- #
@router.get("/health")
def health():
    conn = get_conn()
    tables = db.list_tables(conn)
    return {
        "module": "xray-validation",
        "ai_available": bool(os.environ.get("MISTRAL_API_KEY")),
        "jira_configured": bool(os.environ.get("JIRA_BASE_URL")),
        "db_path": DB_PATH,
        "db_seeded": len(tables) > 0,
        "tables": tables,
    }


@router.get("/db/status")
def db_status():
    conn = get_conn()
    out = {}
    for t in db.list_tables(conn):
        out[t] = len(db.fetch_all(conn, t))
    return {"db_path": DB_PATH, "tables": out}


@router.post("/reseed")
def reseed():
    counts = seed_on_startup(drop=True)
    return {"reseeded": True, "rows": counts}


@router.post("/parse-story")
def parse_story(req: ParseReq):
    return xray_validator.parse_story(req.story_description)


@router.post("/load")
def load(req: LoadReq):
    """Fetch the story description (rules + LOVs) and the Xray steps."""
    try:
        from .jira_client import JiraXrayClient, resolve_credentials

        client = JiraXrayClient(resolve_credentials(req.jira_secret))
        description = client.get_story_description(req.story_key)
        print(description)
        test_key = req.test_key or req.story_key
        steps = client.get_test_steps(test_key)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"JIRA/Xray error: {exc}")

    parsed = xray_validator.parse_story(description)
    entity = xray_validator.detect_entity(description, prefer_ai=True)
    return {
        "story_key": req.story_key,
        "test_key": test_key,
        "description": description,
        "entity": entity,
        "rules": parsed["rules"],
        "lovs": parsed["lovs"],
        "steps": steps,
    }


@router.post("/validate")
def validate(req: ValidateReq):
    conn = get_conn()
    if not db.list_tables(conn):
        # lazy seed if the startup hook wasn't wired
        seed_on_startup(drop=True)
    try:
        entity = (
            req.entity
            or xray_validator.detect_entity(
                req.story_description, prefer_ai=req.prefer_ai
            )
        ).lower()
        config = xray_validator.ENTITY_CONFIG.get(entity)
        if not config:
            raise HTTPException(
                status_code=400,
                detail="Unable to detect entity. Expected product, trial, or site.",
            )
        result = xray_validator.validate_test_with_db(
            conn,
            req.story_description,
            [s.model_dump() for s in req.xray_steps],
            req.test_key,
            prefer_ai=req.prefer_ai,
            **config,
        )
        result["entity"] = entity
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Validation error: {exc}")


@router.post("/import")
def import_results(req: ImportReq):
    try:
        from .jira_client import JiraXrayClient, resolve_credentials

        client = JiraXrayClient(resolve_credentials(req.jira_secret))
        resp = client.import_execution(req.result)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Xray import error: {exc}")
    return {"imported": True, "response": resp}
