from __future__ import annotations

from typing import Any, Dict, List
import openpyxl

from . import db


def load_workbook_tables(path_or_stream) -> Dict[str, List[Dict[str, Any]]]:
    """Return {sheet_name: [row_dict, ...]} for every sheet in the workbook."""
    wb = openpyxl.load_workbook(path_or_stream, data_only=True, read_only=True)
    tables: Dict[str, List[Dict[str, Any]]] = {}
    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            tables[ws.title] = []
            continue
        headers = [str(h).strip() if h is not None else "" for h in rows[0]]
        data = []
        for r in rows[1:]:
            if r is None or all(c is None for c in r):
                continue
            data.append({headers[i]: r[i] for i in range(len(headers)) if headers[i]})
        tables[ws.title] = data
    wb.close()
    return tables


def seed_db_from_workbook(conn, path_or_stream, drop: bool = True) -> Dict[str, int]:
    """Read a workbook and seed each sheet as a SQLite table.

    Sheets named like 'README' are ignored (only source/target-style sheets are
    seeded). Returns {normalized_table: rows_inserted}.
    """
    tables = load_workbook_tables(path_or_stream)
    seedable = {
        name: rows
        for name, rows in tables.items()
        if name.lower() not in ("readme", "notes", "lovs")
    }
    return db.seed_tables(conn, seedable, drop=drop)
