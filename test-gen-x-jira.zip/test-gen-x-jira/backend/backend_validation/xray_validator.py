from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

ENTITY_CONFIG = {
    "product": {
        "source_table": "source.product",
        "target_table": "target.product",
        "source_key": "product_code",
        "target_key": "code",
        "exclude_col": "product_type",
        "exclude_value": "Device",
    },
    "trial": {
        "source_table": "source.trial",
        "target_table": "target.trial",
        "source_key": "trial_id",
        "target_key": "trial_guid",
        "exclude_col": "phase",
        "exclude_value": "N/A",
    },
    "site": {
        "source_table": "source.site",
        "target_table": "target.site",
        "source_key": "site_id",
        "target_key": "site_guid",
        "exclude_col": "",
        "exclude_value": "",
    },
}


def _heuristic_entity(story_description: str) -> str:
    text = (story_description or "").lower()
    scores = {
        "product": sum(
            token in text
            for token in (
                "product_id",
                "product_code",
                "product_type",
                "dosage_form",
                "deprecated_flag",
                "manufacturer_org_id",
                "product_guid",
            )
        ),
        "trial": sum(
            token in text
            for token in (
                "trial_id",
                "trial_code",
                "trial_number",
                "trial_guid",
                "phase",
                "planned_start_date",
                "planned_end_date",
                "sponsor_org_id",
            )
        ),
        "site": sum(
            token in text
            for token in (
                "site_id",
                "site_code",
                "site_guid",
                "site_status",
                "enrollment_status",
                "open_date",
                "close_date",
                "is_open",
            )
        ),
    }
    highest = max(scores.values())
    if highest == 0:
        return "product"
    winners = [entity for entity, score in scores.items() if score == highest]
    return winners[0]


def detect_entity(story_description: str, prefer_ai: bool = True) -> str:
    """Classify the story as product, trial, or site.

    Mistral is used when configured. A deterministic keyword classifier is used
    only when AI is disabled, unavailable, or returns an unsupported value.
    """
    if prefer_ai and os.environ.get("MISTRAL_API_KEY"):
        try:
            client = MistralValidator()._client()
            response = client.chat.complete(
                model=os.environ.get("TGX_MISTRAL_MODEL", "mistral-large-latest"),
                temperature=0,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "Classify the primary data-transformation entity from the "
                            "story description. Return exactly one lowercase word: "
                            "product, trial, or site. Return no explanation."
                        ),
                    },
                    {"role": "user", "content": story_description or ""},
                ],
            )
            content = MistralValidator._content_text(
                response.choices[0].message.content
            )
            entity = content.strip().lower().split()[0].strip(".,:;`'\"")
            if entity in ENTITY_CONFIG:
                return entity
        except Exception:
            pass
    return _heuristic_entity(story_description)


# --------------------------------------------------------------------------- #
# 1. Parse business rules + LOVs from the story description
# --------------------------------------------------------------------------- #
def parse_story(description: str) -> Dict[str, Any]:
    rules: List[str] = []
    lovs: Dict[str, Dict[str, str]] = {}
    section = None
    for raw in (description or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        low = line.lower().rstrip(":")
        if low in ("business rules", "rules"):
            section = "rules"
            continue
        if low in ("lovs", "lov", "list of values", "value mappings"):
            section = "lovs"
            continue
        if section == "rules":
            rules.append(re.sub(r"^[-*\d.\)\s]+", "", line))
        elif section == "lovs":
            m = re.match(r"^([A-Za-z0-9_ ]+?)\s*:\s*(.+)$", line)
            if m:
                name = m.group(1).strip().lower().replace(" ", "_")
                pairs = {}
                for tok in m.group(2).split(","):
                    if "=" in tok:
                        k, v = tok.split("=", 1)
                        pairs[k.strip()] = v.strip()
                if pairs:
                    lovs[name] = pairs
    return {"rules": rules, "lovs": lovs}


# --------------------------------------------------------------------------- #
# 2. Small transform helpers (deterministic primitives)
# --------------------------------------------------------------------------- #
def _norm(s: Any) -> str:
    return re.sub(r"\s+", " ", str(s if s is not None else "").strip().lower())


def _values_equal(a: Any, b: Any) -> bool:
    """Compare two cell values: numeric-aware first (9 == 9.00), else normalized text."""
    try:
        return abs(float(a) - float(b)) < 1e-9
    except (TypeError, ValueError):
        return _norm(a) == _norm(b)


def _blank(v: Any) -> bool:
    return v is None or str(v).strip() == ""


def _title(s: Any) -> str:
    return " ".join(w.capitalize() for w in str(s or "").strip().split())


def _round2(v: Any) -> str:
    try:
        return f"{round(float(v), 2):.2f}"
    except Exception:
        return str(v)


def _get(row: Dict[str, Any], col: str) -> Any:
    if row is None:
        return None
    if col in row:
        return row[col]
    # case-insensitive column fallback
    low = {str(k).lower(): k for k in row}
    return row.get(low.get(col.lower(), col))


def _index_by(rows: List[Dict[str, Any]], key_col: str) -> Dict[str, Dict[str, Any]]:
    idx = {}
    for r in rows or []:
        k = _get(r, key_col)
        if k is not None:
            idx[str(k)] = r
    return idx


# --------------------------------------------------------------------------- #
# 3. Data-aware step validation
# --------------------------------------------------------------------------- #
class DataContext:
    """Holds parsed rules/LOVs + loaded source/target rows and key columns."""

    def __init__(
        self,
        rules,
        lovs,
        source_rows,
        target_rows,
        source_key="PROD_ID",
        target_key="product_key",
        exclude_col="DISCONTINUED_FLAG",
        exclude_value="Y",
    ):
        self.rules = rules
        self.lovs = lovs
        self.source_rows = source_rows or []
        self.target_rows = target_rows or []
        self.source_key = source_key
        self.target_key = target_key
        self.exclude_col = exclude_col
        self.exclude_value = exclude_value
        self.src_idx = _index_by(self.source_rows, source_key)
        self.tgt_idx = _index_by(self.target_rows, target_key)

    def active_source(self) -> List[Dict[str, Any]]:
        out = []
        for r in self.source_rows:
            v = _get(r, self.exclude_col)
            if str(v).strip().upper() != str(self.exclude_value).upper():
                out.append(r)
        return out

    def lov(self, name: str, code: Any) -> Optional[str]:
        m = self.lovs.get(name) or self.lovs.get(name.lower())
        if not m:
            return None
        return m.get(str(code)) or m.get(str(code).strip())


def _parse_data_field(data: str) -> Dict[str, str]:
    """Turn 'PROD_ID=P001; COL=STATUS_CODE' into {'PROD_ID':'P001','COL':'STATUS_CODE'}."""
    out: Dict[str, str] = {}
    for tok in re.split(r"[;,]", data or ""):
        if "=" in tok:
            k, v = tok.split("=", 1)
            out[k.strip()] = v.strip()
    return out


def _resolve_lov_any(ctx: DataContext, code: Any) -> Optional[str]:
    for name in ctx.lovs:
        v = ctx.lov(name, code)
        if v is not None:
            return v
    return None


def validate_step_with_data(ctx: DataContext, step: Dict[str, str]) -> Dict[str, str]:
    """Decide PASS/FAIL/UNKNOWN for a single Xray step using the real data."""
    action = _norm(step.get("action"))
    data = step.get("data", "") or ""
    expected = str(step.get("expected", "") or "").strip()
    fields = _parse_data_field(data)

    # ---- dataset-level checks -------------------------------------------- #
    if "rowcount" in action or "row count" in action or "count" in action:
        actual = len(ctx.target_rows)
        expct = len(ctx.active_source())
        status = "PASS" if actual == expct else "FAIL"
        return {
            "status": status,
            "actual": str(actual),
            "comment": f"target rows={actual} vs active source={expct}",
        }

    if "key parity" in action or "key_parity" in action or "orphan" in action:
        missing = [k for k in ctx.tgt_idx if k not in ctx.src_idx]
        status = "PASS" if not missing else "FAIL"
        return {
            "status": status,
            "actual": f"{len(missing)} orphan keys",
            "comment": (
                "every target key maps to a source key"
                if not missing
                else f"orphans: {missing[:5]}"
            ),
        }

    if "exclude" in action or "discontinued" in action or "filter" in action:
        # the referenced key must NOT be present in target
        key = fields.get(ctx.source_key) or fields.get("key") or expected
        present = str(key) in ctx.tgt_idx
        status = "PASS" if not present else "FAIL"
        return {
            "status": status,
            "actual": "excluded" if not present else "present",
            "comment": f"{key} should be excluded from target",
        }

    # ---- explicit source/target identifiers (Trial/Site Xray steps) ------- #
    source_id = fields.get("SOURCE_ID") or fields.get("source_id")
    target_id = fields.get("TARGET_ID") or fields.get("target_id")
    target_col = fields.get("TARGET_COLUMN") or fields.get("target_column")
    if source_id is not None and target_id is not None and target_col:
        src = ctx.src_idx.get(str(source_id))
        tgt = ctx.tgt_idx.get(str(target_id))
        actual = _get(tgt, target_col) if tgt else None
        computed = _compute_expected(ctx, src, target_col, fields) if src else None
        comparison = computed if computed is not None else expected
        if actual is not None:
            status = "PASS" if _values_equal(actual, comparison) else "FAIL"
            return {
                "status": status,
                "actual": str(actual),
                "comment": f"{target_col} for source {source_id}",
            }

    # ---- per-key transformed value --------------------------------------- #
    key = fields.get(ctx.source_key) or fields.get("key")
    if key is not None and str(key) in ctx.src_idx:
        src = ctx.src_idx[str(key)]
        tgt = ctx.tgt_idx.get(str(key)) or ctx.tgt_idx.get(
            str(_get(src, ctx.source_key))
        )
        target_col = fields.get("COL") or fields.get("TARGET") or fields.get("FIELD")
        actual = _get(tgt, target_col) if (tgt and target_col) else None

        # try to compute what the rules SHOULD produce for a few known fields
        computed = _compute_expected(ctx, src, target_col, fields)
        cmp_val = computed if computed is not None else expected

        if actual is not None:
            status = "PASS" if _values_equal(actual, cmp_val) else "FAIL"
            return {
                "status": status,
                "actual": str(actual),
                "comment": f"{target_col} for {key}: expected {cmp_val}",
            }
        # no target column referenced -> compare computed to step.expected
        if computed is not None:
            status = "PASS" if _values_equal(computed, expected) else "FAIL"
            return {
                "status": status,
                "actual": str(computed),
                "comment": f"rule output for {key}",
            }

    # ---- plain LOV code -> value (no key needed) ------------------------- #
    code = None
    if fields:
        # take the first value that looks like a code
        code = next(iter(fields.values()))
    elif data:
        code = data.strip()
    if code is not None:
        val = _resolve_lov_any(ctx, code)
        if val is not None:
            status = "PASS" if _norm(val) == _norm(expected) else "FAIL"
            return {"status": status, "actual": val, "comment": f"LOV {code} -> {val}"}

    return {
        "status": "UNKNOWN",
        "actual": "",
        "comment": "no data-driven rule matched; refine step or enable AI",
    }


def _compute_expected(
    ctx: DataContext,
    src: Dict[str, Any],
    target_col: Optional[str],
    fields: Dict[str, str],
) -> Optional[str]:
    """Apply common migration rules to a source row for a given target column."""
    if not target_col:
        return None
    col = target_col.lower()
    if col == "phase":
        return {
            "Phase I": "Phase 1",
            "Phase I/II": "Phase 2",
            "Phase II": "Phase 2",
            "Phase II/III": "Phase 3",
            "Phase III": "Phase 3",
            "Phase IV": "Phase 4",
            "Pilot": "Phase 1",
            "N/A": "NA",
        }.get(str(_get(src, "phase")).strip(), "N/A")
    if col == "site_status":
        return {
            "Not Started": "Not Started",
            "Ready": "Ready",
            "Enrolling": "Enrolling",
            "Enrolling - On Hold": "Enrolling On Hold",
            "Enrolling On Hold": "Enrolling On Hold",
            "Closed (Completed)": "Completed",
            "Closed (Terminated)": "Terminated",
            "Closed (Withdrawn)": "Withdrawn",
        }.get(str(_get(src, "enrollment_status")).strip())
    if col == "is_open":
        status = str(_get(src, "enrollment_status") or "").strip()
        return "0" if _get(src, "close_date") or status.startswith("Closed (") else "1"
    if col == "status" and _get(src, "trial_id") is not None:
        source_status = {
            1: "Draft",
            2: "Planned",
            3: "Recruiting",
            4: "Active",
            5: "Suspended",
            6: "Completed",
            7: "Terminated",
            8: "Archived",
        }.get(int(_get(src, "status_code")))
        return {
            "Draft": "Planned",
            "Planned": "Planned",
            "Recruiting": "Recruiting",
            "Active": "Active",
            "Suspended": "Cancelled",
            "Completed": "Completed",
            "Terminated": "Cancelled",
            "Archived": "Cancelled",
        }.get(source_status)
    # Only compute when the required SOURCE column is present in the row;
    # otherwise return None so the caller compares the actual target cell to
    # the step's expected value directly (schema-agnostic behaviour).
    if col in ("product_name", "name"):
        raw = _get(src, fields.get("SRC", "PROD_NAME"))
        return None if raw is None else _title(raw)
    if col in ("status",):
        code = _get(src, "STATUS_CODE")
        return None if code is None else ctx.lov("product_status", code)
    if col in ("category",):
        code = _get(src, "CATEGORY_CODE")
        return None if code is None else ctx.lov("category", code)
    if col in ("uom",):
        code = _get(src, "UOM_CODE")
        if code is None:
            return None
        if _blank(code):
            return "Each"
        v = ctx.lov("uom", code)
        return v if v is not None else "Each"
    if col in ("unit_price", "price"):
        raw = _get(src, fields.get("SRC", "PRICE"))
        return None if raw is None else _round2(raw)
    if col in ("currency_code", "currency"):
        cur = _get(src, "CURRENCY")
        if cur is None:
            return None
        return "USD" if _blank(cur) else str(cur).strip()
    if col in ("product_key", "key"):
        raw = _get(src, ctx.source_key)
        return None if raw is None else str(raw)
    return None


# --------------------------------------------------------------------------- #
# 4. Optional AI validator (used only when a step is UNKNOWN)
# --------------------------------------------------------------------------- #
class MistralValidator:
    def __init__(self, api_key=None, model=None, server_url=None):
        self.api_key = api_key or os.environ.get("MISTRAL_API_KEY", "")
        self.model = model or os.environ.get(
            "TGX_MISTRAL_MODEL", "mistral-large-latest"
        )
        self.server_url = server_url or os.environ.get("TGX_MISTRAL_SERVER_URL") or None
        if not self.api_key:
            raise RuntimeError(
                "MISTRAL_API_KEY is required because every Xray step must be AI validated"
            )

    def _client(self):
        try:
            from mistralai import Mistral
        except Exception:
            from mistralai.client import Mistral
        kwargs = {"api_key": self.api_key}
        if self.server_url:
            kwargs["server_url"] = self.server_url
        return Mistral(**kwargs)

    @staticmethod
    def _step_rows(ctx: DataContext, step: Dict[str, str]):
        fields = _parse_data_field(step.get("data", ""))
        source_id = (
            fields.get("SOURCE_ID")
            or fields.get("source_id")
            or fields.get(ctx.source_key)
            or fields.get(ctx.source_key.upper())
            or fields.get("key")
            or fields.get("KEY")
        )
        target_id = (
            fields.get("TARGET_ID")
            or fields.get("target_id")
            or fields.get(ctx.target_key)
            or fields.get(ctx.target_key.upper())
        )
        source_row = ctx.src_idx.get(str(source_id)) if source_id is not None else None
        target_row = ctx.tgt_idx.get(str(target_id)) if target_id is not None else None
        if target_row is None and source_id is not None:
            target_row = ctx.tgt_idx.get(str(source_id))
        return fields, source_row, target_row

    @staticmethod
    def _content_text(content: Any) -> str:
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "".join(
                (
                    part.get("text", "")
                    if isinstance(part, dict)
                    else getattr(part, "text", str(part))
                )
                for part in content
            )
        return str(content)

    def validate_step(
        self,
        ctx: DataContext,
        step: Dict[str, str],
        deterministic_verdict: Optional[Dict[str, str]] = None,
    ) -> Dict[str, str]:
        client = self._client()
        fields, source_row, target_row = self._step_rows(ctx, step)
        system_prompt = (
            "You are the mandatory validation authority for one data-migration Xray step. "
            "Evaluate the step against the supplied business rules, LOV mappings, source data, "
            "target data, expected result, and deterministic evidence. Do not invent missing data. "
            "A PASS requires evidence that the actual target result complies with the applicable "
            "business rule and LOV. Return FAIL for a demonstrated mismatch. Return UNKNOWN when "
            "the supplied evidence is insufficient or the relevant rows cannot be resolved. "
            "Reply only as a JSON object with keys status, actual, and comment. "
            "status must be PASS, FAIL, or UNKNOWN."
        )
        payload = {
            "business_rules": ctx.rules,
            "lovs": ctx.lovs,
            "source_key": ctx.source_key,
            "target_key": ctx.target_key,
            "exclude_rule": {
                "column": ctx.exclude_col,
                "value": ctx.exclude_value,
            },
            "source_row_count": len(ctx.source_rows),
            "target_row_count": len(ctx.target_rows),
            "active_source_row_count": len(ctx.active_source()),
            "parsed_step_data": fields,
            "source_row": source_row,
            "target_row": target_row,
            "xray_step": {
                "action": step.get("action", ""),
                "data": step.get("data", ""),
                "expected": step.get("expected", ""),
            },
            "deterministic_evidence": deterministic_verdict or {},
        }
        response = client.chat.complete(
            model=self.model,
            temperature=0,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": json.dumps(payload, default=str)},
            ],
            response_format={"type": "json_object"},
        )
        raw = self._content_text(response.choices[0].message.content)
        verdict = json.loads(raw)
        status = str(verdict.get("status", "UNKNOWN")).strip().upper()
        if status not in {"PASS", "FAIL", "UNKNOWN"}:
            status = "UNKNOWN"
        return {
            "status": status,
            "actual": str(verdict.get("actual", "")),
            "comment": str(verdict.get("comment", "")),
        }


# --------------------------------------------------------------------------- #
# 5. Orchestrate: run all steps -> Xray-importable result
# --------------------------------------------------------------------------- #
def validate_test_with_data(
    story_description: str,
    xray_steps: List[Dict[str, str]],
    source_rows: List[Dict[str, Any]],
    target_rows: List[Dict[str, Any]],
    test_key: str,
    source_key: str = "PROD_ID",
    target_key: str = "product_key",
    exclude_col: str = "DISCONTINUED_FLAG",
    exclude_value: str = "Y",
    prefer_ai: bool = True,
) -> Dict[str, Any]:
    parsed = parse_story(story_description)
    ctx = DataContext(
        parsed["rules"],
        parsed["lovs"],
        source_rows,
        target_rows,
        source_key=source_key,
        target_key=target_key,
        exclude_col=exclude_col,
        exclude_value=exclude_value,
    )
    # AI validation is mandatory for every step. `prefer_ai` is retained only
    # for API compatibility and no longer disables AI execution.
    ai = MistralValidator()

    step_results, statuses = [], []
    for i, step in enumerate(xray_steps, start=1):
        deterministic_verdict = validate_step_with_data(ctx, step)
        try:
            verdict = ai.validate_step(
                ctx,
                step,
                deterministic_verdict=deterministic_verdict,
            )
        except Exception as exc:
            verdict = {
                "status": "UNKNOWN",
                "actual": deterministic_verdict.get("actual", ""),
                "comment": (
                    f"Mandatory AI validation failed: {type(exc).__name__}: {exc}. "
                    f"Deterministic evidence: {deterministic_verdict.get('comment', '')}"
                ),
            }
        status = str(verdict.get("status", "UNKNOWN")).upper()
        statuses.append(status)
        step_results.append(
            {
                "index": i,
                "status": {"PASS": "PASSED", "FAIL": "FAILED"}.get(status, "TODO"),
                "comment": verdict.get("comment", ""),
                "actualResult": verdict.get("actual", ""),
            }
        )

    overall = (
        "FAILED"
        if "FAIL" in statuses
        else ("TODO" if "UNKNOWN" in statuses else "PASSED")
    )
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S%z")
    return {
        "info": {
            "summary": f"Automated data validation for {test_key}",
            "description": "Every step was evaluated by Mistral against story rules, LOVs, source data, target data, and deterministic evidence.",
            "startDate": now,
            "finishDate": now,
        },
        "tests": [{"testKey": test_key, "status": overall, "steps": step_results}],
        "dataset": {
            "source_rows": len(source_rows),
            "target_rows": len(target_rows),
            "active_source_rows": len(ctx.active_source()),
        },
    }


def validate_test_with_db(
    conn,
    story_description: str,
    xray_steps: List[Dict[str, str]],
    test_key: str,
    source_table: str = "source.product",
    target_table: str = "target.product",
    source_key: str = "product_code",
    target_key: str = "code",
    exclude_col: str = "product_type",
    exclude_value: str = "Device",
    prefer_ai: bool = True,
) -> Dict[str, Any]:
    """Read source/target rows from the SQLite DB and validate the steps.

    This is the primary runtime path: data is seeded at startup and fetched
    here, so no file upload is needed at validation time.
    """
    from . import db  # local import to avoid any import cycle at module load

    source_rows = db.fetch_all(conn, source_table)
    target_rows = db.fetch_all(conn, target_table)
    result = validate_test_with_data(
        story_description,
        xray_steps,
        source_rows,
        target_rows,
        test_key,
        source_key=source_key,
        target_key=target_key,
        exclude_col=exclude_col,
        exclude_value=exclude_value,
        prefer_ai=prefer_ai,
    )
    result["dataset"]["source_table"] = db.normalize_table(source_table)
    result["dataset"]["target_table"] = db.normalize_table(target_table)
    return result


# Backward-compatible thin wrapper (LOV-only, no data) --------------------- #
def validate_test(story_description, xray_steps, test_key, prefer_ai=True):
    return validate_test_with_data(
        story_description, xray_steps, [], [], test_key, prefer_ai=prefer_ai
    )
