from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional


def normalize_table(name: str) -> str:
    """'source.product' -> 'source_product' (safe, unquoted SQLite identifier)."""
    return re.sub(r"[^0-9a-zA-Z_]", "_", str(name).strip()).strip("_").lower()


def connect(db_path: str) -> sqlite3.Connection:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)
    )
    return cur.fetchone() is not None


def _row_count(conn: sqlite3.Connection, table: str) -> int:
    try:
        return conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
    except sqlite3.Error:
        return 0


def create_and_fill(
    conn: sqlite3.Connection, table: str, rows: List[Dict[str, Any]], drop: bool = True
) -> int:
    """Create a table from the union of row keys and insert the rows.

    Returns the number of rows inserted. When drop=False and the table already
    has rows, seeding is skipped (idempotent create-if-missing).
    """
    table = normalize_table(table)
    if not rows:
        # still create an empty table if we know nothing about columns? skip.
        return 0

    # union of columns preserves first-seen order
    columns: List[str] = []
    for r in rows:
        for k in r.keys():
            if k not in columns:
                columns.append(str(k))

    if drop:
        conn.execute(f'DROP TABLE IF EXISTS "{table}"')
    elif _table_exists(conn, table) and _row_count(conn, table) > 0:
        return 0  # already seeded

    col_defs = ", ".join(f'"{c}" TEXT' for c in columns)
    conn.execute(f'CREATE TABLE IF NOT EXISTS "{table}" ({col_defs})')

    placeholders = ", ".join("?" for _ in columns)
    col_list = ", ".join(f'"{c}"' for c in columns)
    data = [
        tuple(None if r.get(c) is None else str(r.get(c)) for c in columns)
        for r in rows
    ]
    conn.executemany(
        f'INSERT INTO "{table}" ({col_list}) VALUES ({placeholders})', data
    )
    conn.commit()
    return len(data)


def seed_tables(
    conn: sqlite3.Connection, tables: Dict[str, List[Dict[str, Any]]], drop: bool = True
) -> Dict[str, int]:
    """Seed multiple tables at once. Returns {normalized_table: rows_inserted}."""
    result = {}
    for name, rows in tables.items():
        result[normalize_table(name)] = create_and_fill(conn, name, rows, drop=drop)
    return result


def fetch_all(conn: sqlite3.Connection, table: str) -> List[Dict[str, Any]]:
    """Read every row of a table as a list of dicts. Accepts dotted names."""
    tbl = normalize_table(table)
    if not _table_exists(conn, tbl):
        # try a fuzzy match against existing tables
        tbl = _resolve_table(conn, table) or tbl
    if not _table_exists(conn, tbl):
        return []
    cur = conn.execute(f'SELECT * FROM "{tbl}"')
    return [dict(row) for row in cur.fetchall()]


def list_tables(conn: sqlite3.Connection) -> List[str]:
    cur = conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    )
    return [r[0] for r in cur.fetchall()]


def _resolve_table(conn: sqlite3.Connection, wanted: str) -> Optional[str]:
    target = normalize_table(wanted)
    for t in list_tables(conn):
        if t == target or target in t or t in target:
            return t
    return None
