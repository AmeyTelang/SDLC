from .router import router, seed_on_startup
