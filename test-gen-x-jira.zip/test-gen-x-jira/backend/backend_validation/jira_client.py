from __future__ import annotations

import base64
import json
import os
from typing import Any, Dict, List, Optional

import requests


def _from_secrets_manager(secret_name: str, region: Optional[str]) -> Dict[str, str]:
    try:
        import boto3
    except Exception:
        return {}
    try:
        client = boto3.client(
            "secretsmanager",
            region_name=region or os.getenv("AWS_REGION", "us-east-1"),
        )
        resp = client.get_secret_value(SecretId=secret_name)
        raw = (
            resp.get("SecretString") or base64.b64decode(resp["SecretBinary"]).decode()
        )
        return json.loads(raw)
    except Exception:
        return {}


def resolve_credentials(
    secret_name: Optional[str] = None, region: Optional[str] = None
) -> Dict[str, str]:
    creds = {
        "base_url": os.getenv("JIRA_BASE_URL", ""),
        "email": os.getenv("JIRA_EMAIL", ""),
        "api_token": os.getenv("JIRA_API_TOKEN", ""),
        "xray_client_id": os.getenv("XRAY_CLIENT_ID", ""),
        "xray_client_secret": os.getenv("XRAY_CLIENT_SECRET", ""),
    }
    secret_name = secret_name or os.getenv("TGX_JIRA_SECRET")
    if secret_name:
        for k, v in _from_secrets_manager(secret_name, region).items():
            if v:
                creds[k] = v
    return creds


class JiraXrayClient:
    def __init__(self, creds: Optional[Dict[str, str]] = None, timeout: int = 30):
        self.creds = creds or resolve_credentials()
        self.base_url = (self.creds.get("base_url") or "").rstrip("/")
        self.timeout = timeout

    def _basic_auth(self):
        return (self.creds.get("email", ""), self.creds.get("api_token", ""))

    def _xray_cloud_token(self) -> Optional[str]:
        cid, secret = self.creds.get("xray_client_id"), self.creds.get(
            "xray_client_secret"
        )
        if not (cid and secret):
            return None
        r = requests.post(
            "https://xray.cloud.getxray.app/api/v2/authenticate",
            json={"client_id": cid, "client_secret": secret},
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()

    def get_story_description(self, story_key: str) -> str:
        url = f"{self.base_url}/rest/api/3/issue/{story_key}"
        r = requests.get(
            url,
            params={"fields": "description"},
            auth=self._basic_auth(),
            timeout=self.timeout,
        )
        r.raise_for_status()
        return _adf_to_text((r.json().get("fields") or {}).get("description"))

    def get_test_steps(self, test_key: str) -> List[Dict[str, str]]:
        token = None
        try:
            token = self._xray_cloud_token()
        except Exception:
            token = None
        if token:
            query = (
                "query($jql:String!){getTests(jql:$jql,limit:1)"
                "{results{steps{action data result}}}}"
            )
            r = requests.post(
                "https://xray.cloud.getxray.app/api/v2/graphql",
                headers={"Authorization": f"Bearer {token}"},
                json={"query": query, "variables": {"jql": f'key = "{test_key}"'}},
                timeout=self.timeout,
            )
            r.raise_for_status()
            results = ((r.json().get("data") or {}).get("getTests") or {}).get(
                "results"
            ) or []
            steps = results[0].get("steps", []) if results else []
            return [
                {
                    "action": s.get("action", ""),
                    "data": s.get("data", ""),
                    "expected": s.get("result", ""),
                }
                for s in steps
            ]
        url = f"{self.base_url}/rest/raven/2.0/api/test/{test_key}/step"
        r = requests.get(url, auth=self._basic_auth(), timeout=self.timeout)
        r.raise_for_status()
        return [
            {
                "action": s.get("step", ""),
                "data": s.get("data", ""),
                "expected": s.get("result", ""),
            }
            for s in r.json()
        ]

    def import_execution(self, result_json: Dict[str, Any]) -> Dict[str, Any]:
        token = None
        try:
            token = self._xray_cloud_token()
        except Exception:
            token = None
        if token:
            payload = {"tests": []}
            for test in result_json["tests"]:
                payload["tests"].append(
                    {"testKey": test["testKey"], "status": test["status"]}
                )
            # if result_json.get("testExecutionKey"):
            #     payload["testExecutionKey"] = result_json["testExecutionKey"]
            print(payload)
            try:
                r = requests.post(
                    "https://xray.cloud.getxray.app/api/v2/import/execution",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                    timeout=self.timeout,
                    verify=True,
                )
                print("Status: ", r.status_code)
                print("Body: ", r.text)
            except Exception as ex:
                print(ex)
        else:
            r = requests.post(
                f"{self.base_url}/rest/raven/2.0/import/execution",
                auth=self._basic_auth(),
                json=result_json,
                timeout=self.timeout,
                verify=True,
            )
        r.raise_for_status()
        return r.json()


def _adf_to_text(node: Any) -> str:
    if node is None:
        return ""
    if isinstance(node, str):
        return node
    out: List[str] = []

    def walk(n: Any):
        if isinstance(n, dict):
            if n.get("type") == "text":
                out.append(n.get("text", ""))
            for child in n.get("content", []) or []:
                walk(child)
            if n.get("type") in ("paragraph", "listItem", "heading"):
                out.append("\n")
        elif isinstance(n, list):
            for c in n:
                walk(c)

    walk(node)
    return "\n".join(line.rstrip() for line in "".join(out).splitlines())
