"""
usage_routes.py
---------------
Shared FastAPI routes powering the TestGenX "Token Usage" header page.
Both ETL Validation and Web Studio write into the same store, so usage can
be viewed globally or filtered by `module`.

Mount once in your main app:

    from usage_routes import router as usage_router     # flat import
    # or: from .usage_routes import router as usage_router
    app.include_router(usage_router)

Endpoints:
    GET /api/usage/summary   ?module=&story_key=          -> totals + breakdowns
    GET /api/usage           ?module=&story_key=&limit=   -> recent per-call rows
    GET /api/usage/modules                                 -> module ids + labels
"""

from typing import Optional

from fastapi import APIRouter, Query

try:  # works whether imported as a package or a flat module
    from token_tracker import MODULE_LABELS, get_summary, get_usage, init_db
except ImportError:  # pragma: no cover
    from .token_tracker import MODULE_LABELS, get_summary, get_usage, init_db

router = APIRouter(prefix="/api/usage", tags=["ai-usage"])


@router.get("/summary")
def usage_summary(
    module: Optional[str] = Query(
        default=None, description="etl | web-studio; omit or 'all' for everything"
    ),
    story_key: Optional[str] = Query(default=None),
):
    """Totals + per-module + per-call-type breakdowns."""
    init_db()
    return get_summary(module=module, story_key=story_key)


@router.get("")
@router.get("/")
def usage_list(
    module: Optional[str] = Query(default=None),
    story_key: Optional[str] = Query(default=None),
    limit: int = Query(default=200, ge=1, le=1000),
):
    """Most recent per-call token/cost rows (newest first)."""
    init_db()
    return {"items": get_usage(module=module, story_key=story_key, limit=limit)}


@router.get("/modules")
def usage_modules():
    """Module id -> label map for building the page's filter control."""
    return {"modules": [{"id": k, "label": v} for k, v in MODULE_LABELS.items()]}
