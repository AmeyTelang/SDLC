from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class TargetLanguage(str, Enum):
    PYTHON = "python"
    TYPESCRIPT = "typescript"


class ProjectCreate(BaseModel):
    name: str = Field(..., description="Project / application name")
    aut_url: str = Field(..., description="Application-Under-Test base URL")
    description: Optional[str] = None


class Project(BaseModel):
    id: str
    name: str
    aut_url: str
    description: Optional[str] = None
    created_at: datetime
    run_count: int = 0
    last_run_at: Optional[datetime] = None


class GenerateRequest(BaseModel):
    project_id: Optional[str] = Field(default=None, description="Owning project id")
    title: str = Field(default="Untitled Test")
    natural_language_steps: str = Field(...)
    base_url: Optional[str] = Field(
        default=None, description="Overrides the project AUT URL if set"
    )
    language: TargetLanguage = Field(default=TargetLanguage.PYTHON)
    test_id: Optional[str] = Field(
        default=None, description="Pin an existing record so a revision increments it"
    )
    jira_issue_key: Optional[str] = Field(
        default=None, description="Originating JIRA/Xray test key, when imported"
    )


class TestCaseStep(BaseModel):
    index: int
    action: str
    expectation: Optional[str] = None


class GenerateResponse(BaseModel):
    test_id: str
    title: str
    language: TargetLanguage
    structured_steps: List[TestCaseStep]
    script: str
    file_name: str
    generated_by: str
    created_at: datetime

    # --- generation quality signals -----------------------------------
    confidence: float = Field(
        default=1.0,
        description="0-1 certainty that the script faithfully reflects the steps",
    )
    steps_clarified: int = Field(
        default=0, description="Steps rewritten by step intelligence before compiling"
    )
    unmapped_steps: int = Field(
        default=0, description="Steps that still need a manual locator mapping"
    )
    step_analysis: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Per-step clarity record: original, final, confidence, reason",
    )


class ExecuteRequest(BaseModel):
    test_id: str
    script: Optional[str] = None
    language: TargetLanguage = Field(default=TargetLanguage.PYTHON)
    headless: bool = True
    project_id: Optional[str] = None
    project_name: Optional[str] = None


class EvidenceItem(BaseModel):
    step_index: int
    step_name: str
    file_name: str
    url: str
    status: str = "passed"
    captured_by: str = "playwright"


class StepResult(BaseModel):
    name: str
    status: str
    duration_ms: int = 0
    message: Optional[str] = None
    screenshot: Optional[str] = None


class ExecuteResponse(BaseModel):
    test_id: str
    status: str
    total: int
    passed: int
    failed: int
    duration_ms: int
    step_results: List[StepResult]
    evidence: List[EvidenceItem] = []
    stdout: str
    stderr: str
    analysis: str
    analyzed_by: str
    evidence_mode: str = "simulated"  # "real" | "simulated"
    finished_at: datetime


class RunSummary(BaseModel):
    test_id: str
    project_id: Optional[str]
    project_name: Optional[str] = None
    title: str
    language: TargetLanguage
    status: str
    total: int
    passed: int
    failed: int
    evidence_count: int
    generated_by: str
    analyzed_by: str
    evidence_mode: str = "simulated"
    created_at: datetime
    finished_at: Optional[datetime] = None


class ReportRequest(BaseModel):
    test_id: str
    format: str = Field(default="pdf")


class WorkflowEvent(BaseModel):
    agent: str
    phase: str
    message: str
    progress: int = 0
    data: Optional[dict] = None


# ============================================================================
# ETL VALIDATION SCHEMAS
# ============================================================================
class BusinessRule(BaseModel):
    """Business rule extracted from story description."""

    model_config = ConfigDict(extra="ignore")

    id: str = Field(default="", description="Unique business rule identifier")
    description: str = Field(
        default="", description="Rule description and validation logic"
    )

    @field_validator("id", "description", mode="before")
    @classmethod
    def _none_to_str(cls, v):
        return "" if v is None else str(v)


class LovMapping(BaseModel):
    """List of Values (LOV) mapping for ETL transformation."""

    model_config = ConfigDict(extra="ignore")

    field: str = Field(default="", description="Target field name")
    source_value: str = Field(default="", description="Source value")
    target_value: str = Field(default="", description="Target/transformed value")

    @field_validator("field", "source_value", "target_value", mode="before")
    @classmethod
    def _none_to_str(cls, v):
        # Stringify so numeric coded values (0/1) also pass string validation.
        return "" if v is None else str(v)


class ETLExtractedSpec(BaseModel):
    """Extracted ETL specification from JIRA story."""

    model_config = ConfigDict(extra="ignore")

    story_key: str = Field(default="", description="JIRA story key")
    summary: str = Field(default="", description="Story summary")
    source_table: str = Field(default="", description="Source table name")
    target_table: str = Field(default="", description="Target table name")
    business_rules: List[BusinessRule] = Field(
        default_factory=list, description="List of business rules"
    )
    lovs: List[LovMapping] = Field(default_factory=list, description="LOV mappings")
    raw_description: str = Field(default="", description="Raw story description")
    schema_context: Optional[Dict[str, Any]] = Field(
        default=None, description="Introspected DB schema/values for grounding"
    )

    @field_validator(
        "story_key",
        "summary",
        "source_table",
        "target_table",
        "raw_description",
        mode="before",
    )
    @classmethod
    def _none_to_str(cls, v):
        return "" if v is None else str(v)

    @field_validator("business_rules", "lovs", mode="before")
    @classmethod
    def _none_list_to_empty(cls, v):
        return v or []


class ETLGenerateRequest(BaseModel):
    """Request to generate ETL validation SQL script."""

    spec: ETLExtractedSpec = Field(..., description="Extracted ETL specification")


class ETLTestStep(BaseModel):
    """Single validation step in ETL test."""

    model_config = ConfigDict(extra="ignore")

    index: int = Field(default=0, description="Step sequence number")
    action: str = Field(default="", description="Human-readable step description")
    data: str = Field(default="", description="SQL query to execute")
    expected_result: str = Field(
        default="0 rows returned", description="Expected outcome"
    )

    @field_validator("index", mode="before")
    @classmethod
    def _coerce_index(cls, v):
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0

    @field_validator("action", "data", "expected_result", mode="before")
    @classmethod
    def _none_to_str(cls, v):
        return "" if v is None else str(v)


class ETLGenerateResponse(BaseModel):
    """Generated ETL validation SQL script."""

    model_config = ConfigDict(extra="ignore")

    test_id: str = Field(default="", description="Unique test identifier")
    story_key: str = Field(default="", description="Associated JIRA story key")
    target_table: str = Field(default="", description="Target table being validated")
    sql_script: str = Field(default="", description="Complete SQL validation script")
    test_steps: List[ETLTestStep] = Field(
        default_factory=list, description="Individual validation steps"
    )
    generated_by: str = Field(default="Mistral AI", description="Generation method")
    created_at: datetime = Field(
        default_factory=datetime.utcnow, description="Generation timestamp"
    )

    @field_validator(
        "test_id", "story_key", "target_table", "sql_script", mode="before"
    )
    @classmethod
    def _none_to_str(cls, v):
        return "" if v is None else str(v)


class ETLExecuteRequest(BaseModel):
    """Request to execute ETL validation script."""

    test_id: str = Field(..., description="Test identifier")
    script: ETLGenerateResponse = Field(..., description="Generated script to execute")


class ETLStepResult(BaseModel):
    """Result of a single validation step execution."""

    index: int = Field(..., description="Step number")
    action: str = Field(..., description="Step description")
    expected_result: str = Field(..., description="Expected outcome")
    actual_result: str = Field(..., description="Actual result/output")
    status: str = Field(..., description="PASS | FAIL | ERROR")


class ETLExecuteResponse(BaseModel):
    """Results of ETL validation execution."""

    test_id: str = Field(..., description="Test identifier")
    story_key: str = Field(..., description="JIRA story key")
    target_table: str = Field(..., description="Table validated")
    overall_status: str = Field(..., description="PASS | FAIL")
    passed: int = Field(..., description="Number of passing checks")
    failed: int = Field(..., description="Number of failing checks")
    error_count: int = Field(default=0, description="Number of errors")
    step_results: List[ETLStepResult] = Field(
        default_factory=list, description="Per-step results"
    )
    log: str = Field(default="", description="Execution log")
    analysis: str = Field(default="", description="AI analysis of results")
    analyzed_by: str = Field(default="", description="Analysis method")
    finished_at: datetime = Field(..., description="Execution completion time")


class ETLPushRequest(BaseModel):
    """Request to push ETL validation results to JIRA."""

    story_key: str = Field(..., description="Original story key")
    script: ETLGenerateResponse = Field(..., description="Generated script")
    execution: ETLExecuteResponse = Field(..., description="Execution results")


class ETLPushResult(BaseModel):
    """Result of pushing ETL validation to JIRA."""

    test_key: str = Field(..., description="Created Xray Test key")
    test_execution_key: str = Field(..., description="Created Test Execution key")
    url: str = Field(..., description="URL to Xray Test")
    status: str = Field(default="pushed", description="Push status")


class ETLImportRequest(BaseModel):
    """Request to import ETL specification from JIRA."""

    story_key: str = Field(..., description="JIRA story key to import")


class ETLWorkflowEvent(BaseModel):
    """Streaming event from ETL validation workflow."""

    agent: str = Field(..., description="Agent name")
    phase: str = Field(
        ..., description="START | READ | PROCESS | ARTIFACT | HANDSHAKE | DONE"
    )
    status: str = Field(default="", description="Short status label")
    message: str = Field(..., description="Event message")
    progress: int = Field(default=0, description="Progress percentage (0-100)")
    data: Optional[dict] = Field(default=None, description="Optional event data")
