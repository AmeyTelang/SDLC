"""Schemas for the Story -> Xray Test Case authoring workflow."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class TestCaseStatus(str, Enum):
    DRAFT = "draft"
    PENDING = "pending"
    CHANGES_REQUESTED = "changes_requested"
    APPROVED = "approved"
    PUBLISHED = "published"
    REJECTED = "rejected"


class ConfidenceBand(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


def _band(score: float) -> ConfidenceBand:
    if score >= 0.85:
        return ConfidenceBand.HIGH
    if score >= 0.6:
        return ConfidenceBand.MEDIUM
    return ConfidenceBand.LOW


# ----------------------------------------------------------------------
# Story import
# ----------------------------------------------------------------------
class StoryImportRequest(BaseModel):
    project_key: str = Field(default="", description="JIRA project key, e.g. DP")
    story_key: str = Field(..., description="JIRA story key, e.g. DP-14")


class BddStepModel(BaseModel):
    keyword: str = ""
    raw_keyword: str = ""
    text: str = ""


class BddScenarioModel(BaseModel):
    name: str = ""
    tags: List[str] = Field(default_factory=list)
    outline: bool = False
    example: Optional[Dict[str, str]] = None
    steps: List[BddStepModel] = Field(default_factory=list)


class StoryImportResponse(BaseModel):
    story_key: str
    project_key: str
    summary: str = ""
    issue_type: str = ""
    status: str = ""
    url: str = ""
    raw_description: str = ""
    acceptance_criteria: str = ""
    feature: str = ""
    background: List[BddStepModel] = Field(default_factory=list)
    scenarios: List[BddScenarioModel] = Field(default_factory=list)
    structured: bool = False
    scenario_count: int = 0
    parse_warnings: List[str] = Field(default_factory=list)
    imported_at: datetime = Field(default_factory=datetime.utcnow)


# ----------------------------------------------------------------------
# Generated test case
# ----------------------------------------------------------------------
class XrayStep(BaseModel):
    """One Xray manual-test step: Action / Data / Expected Result."""

    model_config = ConfigDict(extra="ignore")

    index: int = 1
    action: str = ""
    data: str = ""
    expected_result: str = ""
    source_scenario: str = ""
    source_keywords: List[str] = Field(default_factory=list)
    confidence: float = 0.0
    rationale: str = ""

    @field_validator(
        "action",
        "data",
        "expected_result",
        "source_scenario",
        "rationale",
        mode="before",
    )
    @classmethod
    def _to_str(cls, value):
        return "" if value is None else str(value).strip()

    @field_validator("confidence", mode="before")
    @classmethod
    def _to_float(cls, value):
        try:
            score = float(value)
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(1.0, score))

    @field_validator("index", mode="before")
    @classmethod
    def _to_int(cls, value):
        try:
            return int(value)
        except (TypeError, ValueError):
            return 1


class TestCaseQuality(BaseModel):
    """Transparent, auditable scoring of the synthesised test case."""

    model_config = ConfigDict(extra="ignore")

    score: float = 0.0
    band: ConfidenceBand = ConfidenceBand.LOW
    scenario_coverage: float = 0.0
    covered_scenarios: List[str] = Field(default_factory=list)
    missing_scenarios: List[str] = Field(default_factory=list)
    grounding: float = 0.0
    completeness: float = 0.0
    model_self_report: float = 0.0
    warnings: List[str] = Field(default_factory=list)
    repair_attempts: int = 0
    generated_by: str = "deterministic"

    def recompute_band(self) -> "TestCaseQuality":
        self.band = _band(self.score)
        return self


class GeneratedTestCase(BaseModel):
    model_config = ConfigDict(extra="ignore")

    summary: str = ""
    description: str = ""
    precondition: str = ""
    priority: str = "Medium"
    labels: List[str] = Field(default_factory=list)
    steps: List[XrayStep] = Field(default_factory=list)
    quality: TestCaseQuality = Field(default_factory=TestCaseQuality)

    @field_validator(
        "summary", "description", "precondition", "priority", mode="before"
    )
    @classmethod
    def _to_str(cls, value):
        return "" if value is None else str(value).strip()

    @field_validator("labels", mode="before")
    @classmethod
    def _to_list(cls, value):
        if not value:
            return []
        if isinstance(value, str):
            return [value]
        return [str(v).strip() for v in value if str(v).strip()]


class TestCaseGenerateRequest(BaseModel):
    story_key: str
    project_key: str = ""
    summary: str = ""
    acceptance_criteria: str = ""
    raw_description: str = ""
    aut_url: str = ""
    scenario_names: List[str] = Field(default_factory=list)
    draft_id: Optional[str] = Field(
        default=None, description="Pin an existing draft so a rework increments it"
    )
    feedback: str = ""


class TestCaseUpdateRequest(BaseModel):
    summary: Optional[str] = None
    description: Optional[str] = None
    precondition: Optional[str] = None
    priority: Optional[str] = None
    labels: Optional[List[str]] = None
    steps: Optional[List[XrayStep]] = None


class TestCaseSubmitRequest(BaseModel):
    note: str = ""


class TestCaseDecisionRequest(BaseModel):
    comment: str = ""


class TestCaseSendBackRequest(BaseModel):
    feedback: str


class TestCasePublishRequest(BaseModel):
    project_key: str = ""
    link_type: str = Field(
        default="Tests", description="Issue link name back to the story"
    )


class TestCasePublishResult(BaseModel):
    draft_id: str
    story_key: str
    test_key: str
    url: str
    steps_pushed: int = 0
    linked: bool = False
    link_error: str = ""
    published_at: datetime = Field(default_factory=datetime.utcnow)


class TestCaseReviewEvent(BaseModel):
    at: datetime
    actor: str
    action: str
    comment: str = ""
    iteration: int = 1


class TestCaseSummary(BaseModel):
    draft_id: str
    story_key: str
    project_key: str = ""
    summary: str = ""
    status: TestCaseStatus = TestCaseStatus.DRAFT
    iteration: int = 1
    step_count: int = 0
    confidence: float = 0.0
    confidence_band: ConfidenceBand = ConfidenceBand.LOW
    requested_by: str = ""
    approver: str = ""
    comment: str = ""
    feedback: str = ""
    addressed_feedback: str = ""
    test_key: str = ""
    test_url: str = ""
    edited: bool = False
    created_at: Optional[datetime] = None
    submitted_at: Optional[datetime] = None
    decided_at: Optional[datetime] = None
    published_at: Optional[datetime] = None
    history: List[TestCaseReviewEvent] = Field(default_factory=list)


class TestCaseDetail(TestCaseSummary):
    test_case: GeneratedTestCase = Field(default_factory=GeneratedTestCase)
    story: Optional[Dict[str, Any]] = None


class WorkflowEventModel(BaseModel):
    agent: str
    phase: str
    message: str
    progress: int = 0
    data: Optional[dict] = None
