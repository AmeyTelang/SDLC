from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Tuple

_MARKER = "###TESTGENX_RESULT###"

# Bump when capture logic changes. Printed in run stdout so you can CONFIRM the
# new driver is loaded ("capture=settle-v6"). If you don't see it, uvicorn was
# not fully restarted and the OLD driver is still in memory.
_CAP_VERSION = "settle-v6"

_RUN_RETRIES = 3
_RUN_TIMEOUT_S = 240

# settle-v6 adds SCROLL-MATERIALISE for tall / lazy-rendered pages (e.g. docs
# sites): before each full-page screenshot we step-scroll to the bottom (so
# lazy/skeleton content actually renders), scroll back to the top, then wait for
# the DOM to stop changing. This removes the faint "ghost" boxes you saw and
# makes full_page captures complete and crisp. Animations are disabled and
# full_page is forced on every capture.
_DRIVER = r"""
import sys, json, traceback, importlib.util, asyncio
if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except Exception:
        pass

script_path = sys.argv[1]
headless = sys.argv[2] == "1"
CAP_VERSION = sys.argv[3] if len(sys.argv) > 3 else "unknown"

_ANIM_OFF = "*,*::before,*::after{transition:none!important;animation:none!important;scroll-behavior:auto!important;caret-color:transparent!important}"
_INIT_JS = "(()=>{var a=function(){try{var s=document.createElement('style');s.setAttribute('data-tgx','1');s.textContent='" + _ANIM_OFF + "';(document.head||document.documentElement).appendChild(s);}catch(e){}};if(document.readyState!=='loading'){a();}else{document.addEventListener('DOMContentLoaded',a);}})();"

# JS: step-scroll from top to bottom to trigger lazy/skeleton rendering.
_MATERIALISE = (
    "async () => {"
    "  const sleep = (ms) => new Promise(r => setTimeout(r, ms));"
    "  const h = () => Math.max(document.body ? document.body.scrollHeight : 0,"
    "                           document.documentElement ? document.documentElement.scrollHeight : 0);"
    "  let y = 0; const vp = window.innerHeight || 800; const max = h();"
    "  while (y < max) { window.scrollTo(0, y); await sleep(60); y += Math.floor(vp * 0.8); if (h() > max) break; }"
    "  window.scrollTo(0, h()); await sleep(120);"  # ensure very bottom
    "  window.scrollTo(0, 0); await sleep(120);"     # back to top for the shot
    "  return true;"
    "}"
)


def _settle(pg):
    # 1) load states (guarded, 30s)
    for st in ("domcontentloaded", "load"):
        try:
            pg.wait_for_load_state(st, timeout=30000)
        except Exception:
            pass
    try:
        pg.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass
    # 2) web fonts ready
    try:
        pg.evaluate("async () => { try { if (document.fonts && document.fonts.ready) { await document.fonts.ready; } } catch(e){} return true; }")
    except Exception:
        pass
    # 3) SCROLL-MATERIALISE (render lazy content, then return to top)
    try:
        pg.evaluate(_MATERIALISE)
    except Exception:
        pass
    # 4) POLL DOM signature until stable for 3 consecutive reads (SPA-safe)
    try:
        prev = None
        stable = 0
        for _ in range(40):  # up to ~6s
            try:
                sig = pg.evaluate(
                    "() => { const b=document.body; return b ? (b.innerHTML.length + 'x' + b.scrollHeight) : ''; }"
                )
            except Exception:
                break
            if sig and sig == prev:
                stable += 1
                if stable >= 3:
                    break
            else:
                stable = 0
                prev = sig
            pg.wait_for_timeout(150)
    except Exception:
        pass
    # 5) two rAFs => a real paint has happened
    try:
        pg.evaluate("() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(() => r(true))))")
    except Exception:
        pass
    # 6) short final settle
    try:
        pg.wait_for_timeout(400)
    except Exception:
        pass


def _patch_screenshot(page_cls):
    if getattr(page_cls, "_tgx_patched", False):
        return
    _orig = page_cls.screenshot

    def _shot(self, *args, **kwargs):
        try:
            _settle(self)
        except Exception:
            pass
        kwargs.setdefault("animations", "disabled")
        kwargs.setdefault("full_page", True)  # ALWAYS full page
        return _orig(self, *args, **kwargs)

    try:
        page_cls.screenshot = _shot
        page_cls._tgx_patched = True
    except Exception:
        pass


status, err, out = "error", "", ""
try:
    spec = importlib.util.spec_from_file_location("gen_mod", script_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    test_fn = None
    for name in dir(mod):
        if name.startswith("test_") and callable(getattr(mod, name)):
            test_fn = getattr(mod, name); break
    if test_fn is None:
        raise RuntimeError("No test_* function found in generated script.")
    from playwright.sync_api import sync_playwright, Page
    _patch_screenshot(Page)
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        # A larger viewport reduces lazy-load surprises for full-page shots.
        context = browser.new_context(viewport={"width": 1366, "height": 900})
        try:
            context.add_init_script(_INIT_JS)
        except Exception:
            pass
        try:
            context.set_default_timeout(30000)
            context.set_default_navigation_timeout(30000)
        except Exception:
            pass
        page = context.new_page()
        try:
            test_fn(page); status = "passed"
        except Exception:
            status = "failed"; err = traceback.format_exc()
        finally:
            context.close(); browser.close()
    out = "capture=" + CAP_VERSION
except Exception:
    status = "error"; err = traceback.format_exc()
print("MARKER" + json.dumps({"status": status, "err": err, "out": out}))
""".replace("MARKER", _MARKER)


def _has_module(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None


def _chromium_installed() -> bool:
    for base in (
        Path.home() / ".cache" / "ms-playwright",
        Path.home() / "AppData" / "Local" / "ms-playwright",
    ):
        if base.exists() and any(base.glob("chromium-*")):
            return True
    return False


def can_capture() -> bool:
    return _has_module("playwright") and _chromium_installed()


def _run_once(script_path: Path, workdir: Path, headless: bool, timeout: int):
    cmd = [
        sys.executable,
        "-c",
        _DRIVER,
        str(script_path),
        "1" if headless else "0",
        _CAP_VERSION,
    ]
    proc = subprocess.run(
        cmd, cwd=str(workdir), capture_output=True, text=True, timeout=timeout
    )
    raw_out, raw_err = proc.stdout or "", proc.stderr or ""
    status, err, cap = None, "", ""
    for line in raw_out.splitlines():
        if line.startswith(_MARKER):
            try:
                data = json.loads(line[len(_MARKER) :])
                status = data.get("status")
                err = data.get("err", "")
                cap = data.get("out", "")
            except Exception:
                pass
            break
    return status, err, cap, raw_err


def run_python_direct(
    script_path: Path,
    workdir: Path,
    headless: bool = True,
    timeout: int = _RUN_TIMEOUT_S,
) -> Tuple[str, str, str]:
    last_err = ""
    for attempt in range(1, _RUN_RETRIES + 1):
        try:
            status, err, cap, raw_err = _run_once(
                script_path, workdir, headless, timeout
            )
        except subprocess.TimeoutExpired:
            status, err, cap, raw_err = (
                "error",
                f"Run timed out after {timeout}s.",
                "",
                "",
            )
        except Exception as exc:  # pragma: no cover
            status, err, cap, raw_err = (
                "error",
                f"Failed to launch capture process: {exc}",
                "",
                "",
            )

        if status in ("passed", "failed"):
            stdout = (
                f"[REAL BROWSER RUN | {_CAP_VERSION}] Executed in an isolated process "
                f"(headless={headless}, attempt {attempt}/{_RUN_RETRIES}).\n"
                f"Status: {status}. Screenshots captured from the live application. {cap}\n"
            )
            stderr = "\n".join(s for s in (err, (raw_err or "").strip()) if s).strip()
            return status, stdout, stderr

        last_err = "\n".join(s for s in (err, (raw_err or "").strip()) if s).strip()
        if attempt < _RUN_RETRIES:
            time.sleep(1.0 * attempt)

    stdout = (
        f"[REAL BROWSER RUN | {_CAP_VERSION}] All {_RUN_RETRIES} attempts errored "
        f"(headless={headless}). Falling back.\n"
    )
    return "error", stdout, (last_err or "Capture process produced no result.")
