"""Immutable, tamper-evident audit trail for TestGenX.

Design intent
-------------
This is the control referenced in the AI Council brief as satisfying
21 CFR Part 11 s11.10(e) - "secure, computer-generated, time-stamped audit
trails". To make that claim defensible the log is:

* **Append-only**    - there is no update or delete API. Corrections are
                       recorded as new events, never as edits.
* **Attributable**   - every entry carries the authenticated actor and the
                       role they held at the time.
* **Tamper-evident** - each entry embeds the SHA-256 of the previous entry,
                       forming a chain. Altering or removing any historical
                       row breaks verification at that point and every point
                       after it, and ``verify()`` reports exactly where.
* **Complete**       - the whole workflow is covered, not just approvals:
                       sign-in, story import, test-case authoring, script
                       generation, submission, review decisions, execution,
                       publication and guardrail refusals.

Storage is JSONL so the file is greppable and survives a process restart;
swap ``_persist()`` for a table write if you move to Postgres.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import threading
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

# ----------------------------------------------------------------------
# Action vocabulary - the full workflow, grouped by stage.
# ----------------------------------------------------------------------
AUTH_LOGIN = "auth.login"
AUTH_LOGOUT = "auth.logout"
AUTH_DENIED = "auth.denied"

# --- Story -> Xray test case authoring --------------------------------
STORY_IMPORTED = "story.imported"
TESTCASE_GENERATED = "testcase.generated"
TESTCASE_REVISED = "testcase.revised"
TESTCASE_EDITED = "testcase.edited"
TESTCASE_SUBMITTED = "testcase.submitted"
TESTCASE_WITHDRAWN = "testcase.withdrawn"
TESTCASE_DISCARDED = "testcase.discarded"
TESTCASE_REVIEW_OPENED = "testcase.review_opened"
TESTCASE_APPROVED = "testcase.approved"
TESTCASE_SENT_BACK = "testcase.sent_back"
TESTCASE_REJECTED = "testcase.rejected"
TESTCASE_PUBLISHED = "testcase.published"
TESTCASE_PUBLISH_BLOCKED = "testcase.publish_blocked"
TESTCASE_PUBLISH_FAILED = "testcase.publish_failed"

# --- Script generation / execution ------------------------------------
TEST_IMPORTED = "test.imported"
SCRIPT_GENERATED = "script.generated"
SCRIPT_REVISED = "script.revised"
SCRIPT_SUBMITTED = "script.submitted"
SCRIPT_WITHDRAWN = "script.withdrawn"
SCRIPT_DISCARDED = "script.discarded"
SCRIPT_SUPERSEDED = "script.superseded"
REVIEW_OPENED = "review.opened"
REVIEW_APPROVED = "review.approved"
REVIEW_SENT_BACK = "review.sent_back"
REVIEW_REJECTED = "review.rejected"
EXEC_STARTED = "execution.started"
EXEC_COMPLETED = "execution.completed"
EXEC_BLOCKED = "execution.blocked"
JIRA_PUSHED = "jira.pushed"
GUARDRAIL_BLOCKED = "guardrail.blocked"


def _meta(label: str, stage: str, severity: str) -> Dict[str, str]:
    return {"label": label, "stage": stage, "severity": severity}


# Human-readable labels + severity, surfaced by the UI.
ACTION_META: Dict[str, Dict[str, str]] = {
    AUTH_LOGIN: _meta("Signed in", "Access", "info"),
    AUTH_LOGOUT: _meta("Signed out", "Access", "info"),
    AUTH_DENIED: _meta("Access denied", "Access", "alert"),
    STORY_IMPORTED: _meta("Story imported", "Authoring", "info"),
    TESTCASE_GENERATED: _meta("Test case generated", "Authoring", "info"),
    TESTCASE_REVISED: _meta("Test case regenerated", "Authoring", "info"),
    TESTCASE_EDITED: _meta("Test case edited", "Authoring", "warn"),
    TESTCASE_SUBMITTED: _meta("Test case submitted", "Test Case Review", "info"),
    TESTCASE_WITHDRAWN: _meta("Test case withdrawn", "Test Case Review", "warn"),
    TESTCASE_DISCARDED: _meta("Test case discarded", "Authoring", "warn"),
    TESTCASE_REVIEW_OPENED: _meta(
        "Test case opened for review", "Test Case Review", "info"
    ),
    TESTCASE_APPROVED: _meta("Test case approved", "Test Case Review", "success"),
    TESTCASE_SENT_BACK: _meta("Test case sent back", "Test Case Review", "warn"),
    TESTCASE_REJECTED: _meta("Test case rejected", "Test Case Review", "alert"),
    TESTCASE_PUBLISHED: _meta("Xray test created in JIRA", "Publication", "success"),
    TESTCASE_PUBLISH_BLOCKED: _meta("Test creation blocked", "Publication", "alert"),
    TESTCASE_PUBLISH_FAILED: _meta("Test creation failed", "Publication", "alert"),
    TEST_IMPORTED: _meta("Test case imported", "Authoring", "info"),
    SCRIPT_GENERATED: _meta("Script generated", "Generation", "info"),
    SCRIPT_REVISED: _meta("Script regenerated", "Generation", "info"),
    SCRIPT_SUBMITTED: _meta("Submitted for review", "Review", "info"),
    SCRIPT_WITHDRAWN: _meta("Submission withdrawn", "Review", "warn"),
    SCRIPT_DISCARDED: _meta("Draft discarded", "Authoring", "warn"),
    SCRIPT_SUPERSEDED: _meta("Record superseded", "Generation", "warn"),
    REVIEW_OPENED: _meta("Opened for review", "Review", "info"),
    REVIEW_APPROVED: _meta("Approved", "Review", "success"),
    REVIEW_SENT_BACK: _meta("Sent back for rework", "Review", "warn"),
    REVIEW_REJECTED: _meta("Rejected", "Review", "alert"),
    EXEC_STARTED: _meta("Execution started", "Execution", "info"),
    EXEC_COMPLETED: _meta("Execution completed", "Execution", "success"),
    EXEC_BLOCKED: _meta("Execution blocked", "Execution", "alert"),
    JIRA_PUSHED: _meta("Results published to JIRA", "Publication", "success"),
    GUARDRAIL_BLOCKED: _meta("Guardrail triggered", "Governance", "alert"),
}

GENESIS_HASH = "0" * 64

AUDIT_PATH = os.environ.get(
    "TESTGENX_AUDIT_LOG",
    os.path.join(os.environ.get("TESTGENX_DATA_DIR", "data"), "audit_log.jsonl"),
)


def _canonical(payload: Dict[str, Any]) -> str:
    """Stable serialisation - key order must not vary or hashes won't match."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def _digest(entry_core: Dict[str, Any], prev_hash: str) -> str:
    return hashlib.sha256(
        (_canonical(entry_core) + prev_hash).encode("utf-8")
    ).hexdigest()


class AuditLog:
    def __init__(self, path: str = AUDIT_PATH) -> None:
        self._lock = threading.RLock()
        self._path = path
        self._entries: List[Dict[str, Any]] = []
        self._loaded = False

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        directory = os.path.dirname(self._path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        if not os.path.exists(self._path):
            return
        with open(self._path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    self._entries.append(json.loads(line))
                except json.JSONDecodeError:
                    # A corrupt line is itself an integrity finding; keep a
                    # marker so verify() reports it rather than skipping.
                    self._entries.append({"__corrupt__": True, "raw": line})

    def _persist(self, entry: Dict[str, Any]) -> None:
        with open(self._path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, default=str) + "\n")

    # ------------------------------------------------------------------
    # Write - the ONLY mutation path
    # ------------------------------------------------------------------
    def record(
        self,
        action: str,
        *,
        actor: Optional[str] = None,
        actor_role: Optional[str] = None,
        entity_type: str = "test",
        entity_id: Optional[str] = None,
        entity_title: Optional[str] = None,
        project_id: Optional[str] = None,
        project_name: Optional[str] = None,
        iteration: Optional[int] = None,
        summary: str = "",
        details: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Append one event and return the stored entry."""
        with self._lock:
            self._ensure_loaded()
            prev_hash = (
                self._entries[-1].get("hash", GENESIS_HASH)
                if self._entries
                else GENESIS_HASH
            )
            meta = ACTION_META.get(action, {})
            core = {
                "seq": len(self._entries) + 1,
                "at": datetime.utcnow().isoformat() + "Z",
                "action": action,
                "label": meta.get("label", action),
                "stage": meta.get("stage", "Other"),
                "severity": meta.get("severity", "info"),
                "actor": actor or "system",
                "actor_role": actor_role or "system",
                "entity_type": entity_type,
                "entity_id": entity_id,
                "entity_title": entity_title,
                "project_id": project_id,
                "project_name": project_name,
                "iteration": iteration,
                "summary": summary,
                "details": details or {},
            }
            entry = {**core, "prev_hash": prev_hash, "hash": _digest(core, prev_hash)}
            self._entries.append(entry)
            try:
                self._persist(entry)
            except OSError:
                # Never let a disk problem break the workflow; the in-memory
                # chain still holds and verify() will flag the divergence.
                pass
            return entry

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------
    def query(
        self,
        *,
        actor: Optional[str] = None,
        action: Optional[str] = None,
        stage: Optional[str] = None,
        severity: Optional[str] = None,
        entity_id: Optional[str] = None,
        project_id: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 200,
        offset: int = 0,
    ) -> Dict[str, Any]:
        with self._lock:
            self._ensure_loaded()
            rows = [e for e in self._entries if not e.get("__corrupt__")]

        def keep(e: Dict[str, Any]) -> bool:
            if actor and e.get("actor") != actor:
                return False
            if action and e.get("action") != action:
                return False
            if stage and e.get("stage") != stage:
                return False
            if severity and e.get("severity") != severity:
                return False
            if entity_id and e.get("entity_id") != entity_id:
                return False
            if project_id and e.get("project_id") != project_id:
                return False
            if since and (e.get("at") or "") < since:
                return False
            if until and (e.get("at") or "") > until:
                return False
            if search:
                needle = search.lower()
                blob = " ".join(
                    str(e.get(key) or "")
                    for key in (
                        "actor",
                        "label",
                        "summary",
                        "entity_title",
                        "entity_id",
                        "project_name",
                    )
                ).lower()
                if (
                    needle not in blob
                    and needle not in _canonical(e.get("details", {})).lower()
                ):
                    return False
            return True

        filtered = [e for e in rows if keep(e)]
        filtered.sort(key=lambda e: e.get("seq", 0), reverse=True)  # newest first
        page = filtered[offset : offset + limit]
        return {
            "total": len(filtered),
            "offset": offset,
            "limit": limit,
            "returned": len(page),
            "entries": page,
        }

    def for_entity(self, entity_id: str) -> List[Dict[str, Any]]:
        """Chronological trail for one artefact - the per-record story."""
        with self._lock:
            self._ensure_loaded()
            rows = [
                e
                for e in self._entries
                if not e.get("__corrupt__") and e.get("entity_id") == entity_id
            ]
        return sorted(rows, key=lambda e: e.get("seq", 0))

    # ------------------------------------------------------------------
    # Integrity
    # ------------------------------------------------------------------
    def verify(self) -> Dict[str, Any]:
        """Walk the hash chain. Reports the FIRST break and its sequence."""
        with self._lock:
            self._ensure_loaded()
            entries = list(self._entries)

        prev = GENESIS_HASH
        for idx, entry in enumerate(entries):
            if entry.get("__corrupt__"):
                return self._broken(
                    idx,
                    len(entries),
                    idx + 1,
                    "Unreadable entry - the log file was edited outside the application.",
                )
            core = {k: entry[k] for k in entry if k not in ("prev_hash", "hash")}
            if entry.get("prev_hash") != prev:
                return self._broken(
                    idx,
                    len(entries),
                    entry.get("seq"),
                    "Chain link mismatch - an entry was inserted or removed.",
                )
            if _digest(core, prev) != entry.get("hash"):
                return self._broken(
                    idx,
                    len(entries),
                    entry.get("seq"),
                    "Content hash mismatch - an entry was altered after it was written.",
                )
            prev = entry["hash"]

        return {
            "valid": True,
            "checked": len(entries),
            "total": len(entries),
            "broken_at_seq": None,
            "reason": "All entries verified; the chain is intact.",
            "head_hash": prev,
        }

    @staticmethod
    def _broken(checked: int, total: int, seq, reason: str) -> Dict[str, Any]:
        return {
            "valid": False,
            "checked": checked,
            "total": total,
            "broken_at_seq": seq,
            "reason": reason,
        }

    # ------------------------------------------------------------------
    # Statistics for the screen header
    # ------------------------------------------------------------------
    def stats(self, days: int = 30) -> Dict[str, Any]:
        with self._lock:
            self._ensure_loaded()
            rows = [e for e in self._entries if not e.get("__corrupt__")]

        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat() + "Z"
        recent = [e for e in rows if (e.get("at") or "") >= cutoff]

        by_action: Dict[str, int] = {}
        by_actor: Dict[str, int] = {}
        for entry in recent:
            by_action[entry["action"]] = by_action.get(entry["action"], 0) + 1
            by_actor[entry["actor"]] = by_actor.get(entry["actor"], 0) + 1

        approvals = by_action.get(REVIEW_APPROVED, 0) + by_action.get(
            TESTCASE_APPROVED, 0
        )
        sent_back = by_action.get(REVIEW_SENT_BACK, 0) + by_action.get(
            TESTCASE_SENT_BACK, 0
        )
        decided = approvals + sent_back

        return {
            "total_events": len(rows),
            "window_days": days,
            "events_in_window": len(recent),
            "approvals": approvals,
            "sent_back": sent_back,
            "first_pass_rate": round(approvals / decided * 100, 1) if decided else None,
            "executions": by_action.get(EXEC_COMPLETED, 0),
            "tests_created": by_action.get(TESTCASE_PUBLISHED, 0),
            "stories_imported": by_action.get(STORY_IMPORTED, 0),
            "blocked": (
                by_action.get(EXEC_BLOCKED, 0)
                + by_action.get(GUARDRAIL_BLOCKED, 0)
                + by_action.get(TESTCASE_PUBLISH_BLOCKED, 0)
            ),
            "distinct_actors": len(by_actor),
            "by_action": by_action,
            "by_actor": by_actor,
        }

    # ------------------------------------------------------------------
    # Export - the inspector's artefact
    # ------------------------------------------------------------------
    _EXPORT_COLUMNS = (
        "seq",
        "timestamp_utc",
        "actor",
        "role",
        "action",
        "label",
        "stage",
        "severity",
        "entity_id",
        "entity_title",
        "project",
        "iteration",
        "summary",
        "details",
        "prev_hash",
        "hash",
    )

    def export_csv(self, **filters) -> str:
        filters.pop("limit", None)
        filters.pop("offset", None)
        rows = self.query(limit=10_000_000, offset=0, **filters)["entries"]
        rows = sorted(rows, key=lambda e: e.get("seq", 0))

        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(self._EXPORT_COLUMNS)
        for entry in rows:
            writer.writerow(
                [
                    entry.get("seq"),
                    entry.get("at"),
                    entry.get("actor"),
                    entry.get("actor_role"),
                    entry.get("action"),
                    entry.get("label"),
                    entry.get("stage"),
                    entry.get("severity"),
                    entry.get("entity_id"),
                    entry.get("entity_title"),
                    entry.get("project_name"),
                    entry.get("iteration"),
                    entry.get("summary"),
                    _canonical(entry.get("details", {})),
                    entry.get("prev_hash"),
                    entry.get("hash"),
                ]
            )
        return buf.getvalue()

    def export_json(self, **filters) -> Dict[str, Any]:
        filters.pop("limit", None)
        filters.pop("offset", None)
        rows = self.query(limit=10_000_000, offset=0, **filters)["entries"]
        return {
            "exported_at": datetime.utcnow().isoformat() + "Z",
            "integrity": self.verify(),
            "count": len(rows),
            "entries": sorted(rows, key=lambda e: e.get("seq", 0)),
        }

    # ------------------------------------------------------------------
    def distinct(self, field: str) -> List[str]:
        with self._lock:
            self._ensure_loaded()
            values = {
                e.get(field)
                for e in self._entries
                if not e.get("__corrupt__") and e.get(field)
            }
        return sorted(v for v in values if isinstance(v, str))


audit_log = AuditLog()
