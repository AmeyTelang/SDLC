from __future__ import annotations

import json
import time
from typing import Dict, Generator, Optional

from agents.approval_gate import (
    APPROVED,
    CHANGES_REQUESTED,
    DRAFT,
    EXECUTED,
    PENDING,
    REJECTED,
    approval_gate,
)
from agents.execution_agent import execution_agent
from agents.generation_agent import generation_agent
from agents.llm_client import llm_client
from models.schemas import ExecuteRequest, GenerateRequest, WorkflowEvent
from services import store
from services import audit_hooks

ARTIFACTS: Dict[str, dict] = {}
PARKED: Dict[str, dict] = {}
APPROVAL_TIMEOUT_S = 60 * 30


def _event(agent, phase, message, progress, data=None) -> str:
    ev = WorkflowEvent(
        agent=agent, phase=phase, message=message, progress=progress, data=data
    )
    return f"data: {ev.model_dump_json()}\n\n"


def _source_of(req: GenerateRequest) -> dict:
    return {
        "title": getattr(req, "title", "") or "",
        "natural_language_steps": getattr(req, "natural_language_steps", "") or "",
        "language": getattr(req, "language", "python") or "python",
        "base_url": getattr(req, "base_url", None),
        "project_id": getattr(req, "project_id", None),
        "jira_issue_key": getattr(req, "jira_issue_key", None),
    }


def _persist(
    gen_dict, exec_dict, req: GenerateRequest, approval: Optional[dict] = None
):
    project = store.get_project(req.project_id) if req.project_id else None
    approval = approval or {}
    run = {
        "test_id": gen_dict["test_id"],
        "project_id": req.project_id,
        "project_name": project["name"] if project else None,
        "aut_url": (project["aut_url"] if project else None) or req.base_url,
        "title": gen_dict["title"],
        "language": gen_dict["language"],
        "file_name": gen_dict["file_name"],
        "script": gen_dict["script"],
        "structured_steps": gen_dict["structured_steps"],
        "generated_by": gen_dict["generated_by"],
        "created_at": gen_dict["created_at"],
        "status": exec_dict["status"],
        "total": exec_dict["total"],
        "passed": exec_dict["passed"],
        "failed": exec_dict["failed"],
        "duration_ms": exec_dict["duration_ms"],
        "evidence_count": len(exec_dict["evidence"]),
        "step_results": exec_dict["step_results"],
        "evidence": exec_dict["evidence"],
        "analysis": exec_dict["analysis"],
        "analyzed_by": exec_dict["analyzed_by"],
        "evidence_mode": exec_dict.get("evidence_mode", "simulated"),
        "finished_at": exec_dict["finished_at"],
        "approval_status": approval.get("status"),
        "submitted_by": approval.get("requested_by"),
        "submitted_at": approval.get("submitted_at"),
        "approved_by": approval.get("approver"),
        "approved_at": approval.get("decided_at"),
        "approval_comment": approval.get("comment"),
        "approval_iteration": approval.get("iteration"),
        "review_history": approval.get("history", []),
    }
    ARTIFACTS[run["test_id"]] = run
    store.save_run(run)
    return run


# ======================================================================
# TEST ENGINEER: generate -> DRAFT
# ======================================================================
def run_generation_stream(
    req: GenerateRequest,
    headless: bool = True,
    requested_by: Optional[str] = None,
) -> Generator[str, None, None]:
    engine = "Mistral LLM" if llm_client.available else "deterministic fallback engine"
    project = store.get_project(req.project_id) if req.project_id else None
    if project and not req.base_url:
        req.base_url = project["aut_url"]
    project_name = project["name"] if project else None
    ctx = f" · project: {project_name}" if project_name else ""

    # ------------------------------------------------------------------
    # THE FIX — pin the target record.
    #
    # `generation_agent.generate()` mints a FRESH test_id on every call. On a
    # revision that produced a brand-new record while the original sat
    # untouched at `changes_requested`, so the old card never cleared and the
    # new one restarted at iteration 1.
    #
    # When the caller supplies a test_id we treat it as authoritative and
    # re-bind the generated artifact to it, so `approval_gate.request()`
    # updates the SAME record (iteration + 1, change request resolved).
    # ------------------------------------------------------------------
    target_id = getattr(req, "test_id", None) or None
    prior = approval_gate.get(target_id) if target_id else None
    rework = prior.feedback if prior and prior.status == CHANGES_REQUESTED else None
    prior_steps = (prior.source or {}).get("natural_language_steps") if prior else None
    steps_changed = bool(
        prior_steps
        and prior_steps.strip() != (req.natural_language_steps or "").strip()
    )

    yield _event(
        "orchestrator", "start", f"Workflow started · engine: {engine}{ctx}", 4
    )
    time.sleep(0.12)

    if rework:
        yield _event(
            "generation",
            "rework",
            (
                "Generation Agent: regenerating with edited steps to address — "
                if steps_changed
                else "Generation Agent: regenerating to address — "
            )
            + f"“{rework[:130]}”",
            10,
        )
        time.sleep(0.12)

    yield _event(
        "generation", "read", "Generation Agent: parsing natural-language steps…", 18
    )
    time.sleep(0.12)
    yield _event(
        "generation",
        "process",
        "Generation Agent: distilling structured test steps…",
        34,
    )

    gen = generation_agent.generate(req)
    generated_id = gen.test_id

    # Re-bind the artifact to the record being revised.
    if target_id and generated_id != target_id:
        try:
            gen.test_id = target_id
        except Exception:
            # Frozen/immutable model — rebuild it with the pinned id.
            gen = gen.model_copy(update={"test_id": target_id})
        # Anything the agent already wrote under the throwaway id is dead.
        PARKED.pop(generated_id, None)
        ARTIFACTS.pop(generated_id, None)
        approval_gate.discard(generated_id)

    gen_dict = json.loads(gen.model_dump_json())
    gen_dict["test_id"] = gen.test_id  # belt-and-braces for the SSE payload

    yield _event(
        "generation",
        "artifact",
        f"Generation Agent: produced {len(gen.structured_steps)} steps + Playwright script "
        f"({gen.generated_by}).",
        52,
        data=gen_dict,
    )
    time.sleep(0.16)

    rec = approval_gate.request(
        gen.test_id,
        title=gen.title,
        file_name=gen.file_name,
        project_id=req.project_id,
        project_name=project_name,
        language=gen.language,
        step_count=len(gen.structured_steps),
        artifact=gen_dict,
        source=_source_of(req),
        requested_by=requested_by,
    )
    audit_hooks.generated(
        rec,
        actor=requested_by,
        role="test_engineer",
        engine=gen.generated_by,
        model=getattr(llm_client, "model", None),
        feedback_addressed=rec.addressed_feedback,
    )
    # Safety net: retire any older record for the same test that an earlier
    # build may have orphaned (pre-fix data, or a divergent id).
    superseded = approval_gate.supersede_duplicates(
        keep_test_id=gen.test_id,
        owner=requested_by,
        title=gen.title,
        project_id=req.project_id,
    )
    for old_id in superseded:
        audit_hooks.superseded(old_id, gen.test_id, title=gen.title)
    PARKED[gen.test_id] = {
        "req": req,
        "gen": gen,
        "gen_dict": gen_dict,
        "project_name": project_name,
        "headless": headless,
        "requested_by": requested_by,
    }

    yield _event(
        "generation",
        "handshake",
        "Generation Agent: complete. Draft is ready for your review.",
        58,
    )
    yield _event(
        "approval",
        "draft",
        f"Draft ready · iteration {rec.iteration}. Review the script, then submit it "
        "to the Test Lead when you're satisfied.",
        60,
        data={
            "draft": rec.summary(),
            "test_id": gen.test_id,
            "iteration": rec.iteration,
            # Ids the client should drop from "My Scripts" immediately.
            "superseded": ([generated_id] if generated_id != gen.test_id else [])
            + superseded,
        },
    )


# ======================================================================
# TEST LEAD: approved -> Execution Agent
# ======================================================================
def run_execution_stream(test_id: str) -> Generator[str, None, None]:
    parked = PARKED.get(test_id)
    if not parked:
        yield _event(
            "orchestrator",
            "error",
            f"No generated script is parked for '{test_id}'. Ask the Test Engineer to "
            "re-run generation.",
            100,
        )
        return

    rec = approval_gate.get(test_id)
    if rec is None:
        yield _event(
            "orchestrator", "error", "Approval record missing — execution blocked.", 100
        )
        return

    if rec.status == DRAFT:
        audit_hooks.execution_blocked(
            test_id,
            actor=rec.approver,
            role="test_lead",
            reason="draft not submitted",
            status=rec.status,
        )
        yield _event(
            "approval",
            "error",
            "Execution blocked: this script is still a draft and has not been submitted.",
            100,
            data={"approval": rec.summary()},
        )
        return

    if rec.status == PENDING:
        yield _event(
            "approval", "await", "Approval Gate: waiting for Test Lead decision…", 62
        )
        rec = approval_gate.wait(test_id, timeout=APPROVAL_TIMEOUT_S)

    if rec.status == CHANGES_REQUESTED:
        audit_hooks.execution_blocked(
            test_id,
            actor=rec.approver,
            role="test_lead",
            reason="draft not submitted",
            status=rec.status,
        )
        yield _event(
            "approval",
            "sent_back",
            f"Approval Gate: {rec.approver} returned this script for regeneration. "
            "Execution Agent not invoked.",
            100,
            data={"approval": rec.summary()},
        )
        return

    if rec.status == REJECTED:
        audit_hooks.execution_blocked(
            test_id,
            actor=rec.approver,
            role="test_lead",
            reason="draft not submitted",
            status=rec.status,
        )
        yield _event(
            "approval",
            "rejected",
            f"Approval Gate: script rejected by {rec.approver}. Execution Agent not invoked.",
            100,
            data={"approval": rec.summary()},
        )
        return

    if rec.status not in (APPROVED, EXECUTED):
        yield _event(
            "approval",
            "error",
            "Approval Gate: timed out waiting for Test Lead approval. Execution cancelled.",
            100,
            data={"approval": rec.summary()},
        )
        return

    yield _event(
        "approval",
        "approved",
        f"Approval Gate: approved by {rec.approver} · releasing control to the Execution Agent.",
        66,
        data={"approval": rec.summary()},
    )

    req: GenerateRequest = parked["req"]
    gen = parked["gen"]
    gen_dict = parked["gen_dict"]
    project_name = parked["project_name"]
    headless = parked["headless"]

    yield _event(
        "execution",
        "start",
        "Execution Agent: writing script & launching Playwright…",
        74,
    )
    time.sleep(0.16)
    yield _event(
        "execution",
        "process",
        "Execution Agent: running the test & capturing screenshots…",
        84,
    )

    exec_req = ExecuteRequest(
        test_id=gen.test_id, script=gen.script, language=gen.language, headless=headless
    )
    audit_hooks.execution_started(rec, actor=rec.approver, role="test_lead")
    result = execution_agent.execute(
        exec_req,
        gen.file_name,
        gen.script,
        project_id=req.project_id,
        project_name=project_name,
    )
    exec_dict = json.loads(result.model_dump_json())
    audit_hooks.execution_completed(
        rec, actor=rec.approver, role="test_lead", result=exec_dict
    )
    _persist(gen_dict, exec_dict, req, approval=rec.summary())
    approval_gate.mark_executed(test_id)

    mode = exec_dict.get("evidence_mode", "simulated")
    yield _event(
        "execution",
        "artifact",
        f"Execution Agent: {result.status.upper()} — {result.passed}/{result.total} checks passed · "
        f"{len(result.evidence)} screenshots ({mode}).",
        93,
        data=exec_dict,
    )
    time.sleep(0.12)
    yield _event(
        "execution",
        "done",
        "Execution Agent: analysis complete & run saved to history.",
        98,
    )
    yield _event(
        "orchestrator",
        "end",
        f"Workflow finished · verdict: {result.status.upper()} · approved by {rec.approver} · "
        "saved to project history.",
        100,
        data={
            "test_id": gen.test_id,
            "status": result.status,
            "approval": rec.summary(),
        },
    )
    PARKED.pop(test_id, None)
