from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

import config
from models.schemas import EvidenceItem, StepResult, TargetLanguage


@dataclass
class RunResult:
    status: str = "error"
    total: int = 0
    passed: int = 0
    failed: int = 0
    duration_ms: int = 0
    step_results: List[StepResult] = field(default_factory=list)
    evidence: List[EvidenceItem] = field(default_factory=list)
    stdout: str = ""
    stderr: str = ""
    evidence_mode: str = "simulated"


class PlaywrightRunner:
    def write_script(self, out_dir: Path, file_name: str, script: str) -> Path:
        print(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / file_name
        path.write_text(script, encoding="utf-8")
        return path

    def run(
        self, out_dir: Path, file_name, language, test_id, headless=True
    ) -> RunResult:
        path = out_dir / file_name
        if not path.exists():
            return RunResult(
                status="error", stderr=f"Script file not found: {file_name}"
            )
        evidence_dir = out_dir / "evidence" / test_id
        evidence_dir.mkdir(parents=True, exist_ok=True)
        # from core.feature_registry import runner_for_script, load_features

        # load_features()
        # feature_runner = runner_for_script(path.stem)
        # if feature_runner is not None:
        #     return feature_runner(
        #         path,
        #         out_dir,
        #         test_id,
        #         project=getattr(self, "_project", None),
        #         jira_issue_key=getattr(self, "_jira_key", None),
        #     )
        if language == TargetLanguage.PYTHON:
            result = self._run_python(path, out_dir, headless)
        else:
            result = self._run_typescript(path, out_dir, headless)
        self._attach_evidence(result, path, test_id, evidence_dir)
        return result

    # ------------------------------------------------------------------
    def _run_python(self, path: Path, out_dir: Path, headless: bool) -> RunResult:
        try:
            from services import live_capture

            if live_capture.can_capture():
                status, stdout, stderr = live_capture.run_python_direct(
                    path, out_dir, headless=headless
                )
                passed = 1 if status == "passed" else 0
                failed = 1 if status in ("failed", "error") else 0
                step = StepResult(
                    name=path.stem,
                    status="passed" if status == "passed" else "failed",
                    message=(
                        None if status == "passed" else "See logs / STDERR for details."
                    ),
                )
                rr = RunResult(
                    "passed" if status == "passed" else "failed",
                    1,
                    passed,
                    failed,
                    0,
                    [step],
                    [],
                    stdout or "[REAL BROWSER RUN]\n",
                    stderr,
                )
                rr.evidence_mode = "real"
                return rr
        except Exception as exc:
            return self._simulate(
                path,
                f"Real browser path unavailable ({exc}). Ran a simulated pass instead.",
            )
        return self._simulate(
            path,
            "No local browser runtime detected — ran a clean simulated pass. "
            "For real captures: pip install playwright && playwright install chromium.",
        )

    def _run_typescript(self, path: Path, out_dir: Path, headless: bool) -> RunResult:
        return self._simulate(
            path,
            "TypeScript target simulated. For real TS runs set up @playwright/test "
            "in the project output folder (npm i -D @playwright/test && npx playwright install).",
        )

    # ------------------------------------------------------------------
    def _step_names_from_script(self, src: str) -> List[str]:
        names = re.findall(r"Step \d+:\s*(.+)", src)
        if names:
            return [n.strip() for n in names]
        slugs = re.findall(r"step_\d+_([a-z0-9_]+)\.png", src)
        if slugs:
            return [s.replace("_", " ").strip().capitalize() for s in slugs]
        shots = len(re.findall(r"screenshot\(", src))
        return [f"Step {i}" for i in range(1, max(shots, 1) + 1)]

    def _simulate(self, path: Path, reason: str) -> RunResult:
        src = path.read_text(encoding="utf-8")
        todos = len(re.findall(r"TODO manual mapping needed", src))
        names = self._step_names_from_script(src)
        steps = [StepResult(name=n, status="passed", duration_ms=120) for n in names]
        if todos:
            steps.append(
                StepResult(
                    name=f"{todos} unmapped step(s)",
                    status="failed",
                    message="Some steps need manual locator mapping.",
                )
            )
        passed = sum(1 for s in steps if s.status == "passed")
        failed = sum(1 for s in steps if s.status == "failed")
        status = "passed" if failed == 0 else "failed"
        stdout = (
            "[SIMULATED RUN]\n"
            f"{reason}\n"
            f"Parsed {len(names)} step(s) from the generated script.\n"
            f"Result: {passed} passed, {failed} failed.\n"
            "Screenshots were synthesised as evidence placeholders.\n"
        )
        rr = RunResult(
            status,
            max(len(steps), 1),
            passed,
            failed,
            len(steps) * 120,
            steps,
            [],
            stdout,
            "",
        )
        rr.evidence_mode = "simulated"
        return rr

    # ------------------------------------------------------------------
    def _attach_evidence(
        self, result: RunResult, path: Path, test_id: str, evidence_dir: Path
    ):
        found = sorted(evidence_dir.glob("step_*.png"))
        names = self._step_names_from_script(path.read_text(encoding="utf-8"))
        if not found:
            found = self._synthesise(result, names, test_id, evidence_dir)
            captured_by = "simulated"
            result.evidence_mode = "simulated"
        else:
            captured_by = "playwright"
            result.evidence_mode = "real"
        evidence: List[EvidenceItem] = []
        for i, img in enumerate(found, start=1):
            name = names[i - 1] if i - 1 < len(names) else img.stem
            st = (
                "failed"
                if (result.status == "failed" and i == len(found))
                else "passed"
            )
            evidence.append(
                EvidenceItem(
                    step_index=i,
                    step_name=name.strip(),
                    file_name=img.name,
                    url=f"/api/evidence/{test_id}/{img.name}",
                    status=st,
                    captured_by=captured_by,
                )
            )
        result.evidence = evidence
        for idx, sr in enumerate(result.step_results):
            if idx < len(evidence):
                sr.screenshot = evidence[idx].url

    def _synthesise(self, result, names, test_id, evidence_dir) -> List[Path]:
        try:
            from PIL import Image, ImageDraw
        except Exception:
            return []
        names = names or ["Generated test"]
        paths, W, H = [], 1000, 640
        for i, name in enumerate(names, start=1):
            failed = result.status == "failed" and i == len(names)
            img = Image.new("RGB", (W, H), (13, 18, 34))
            d = ImageDraw.Draw(img)
            d.rectangle([0, 0, W, 64], fill=(19, 26, 44))
            d.line([0, 64, W, 64], fill=(35, 44, 68), width=2)
            for cx, col in (
                (28, (255, 95, 86)),
                (52, (255, 189, 46)),
                (76, (39, 201, 63)),
            ):
                d.ellipse([cx - 7, 25, cx + 7, 39], fill=col)
            d.rounded_rectangle([104, 20, W - 24, 44], radius=12, fill=(15, 22, 38))
            d.text((116, 27), "https://application-under-test", fill=(152, 163, 189))
            d.rectangle([0, 64, W, 120], fill=(106, 92, 255))
            d.text((28, 86), "TestGenX  ·  Test Evidence", fill=(255, 255, 255))
            d.text((36, 156), f"Step {i:02d}", fill=(234, 238, 247))
            d.text((36, 190), name.strip()[:80], fill=(234, 238, 247))
            badge = (255, 107, 129) if failed else (52, 211, 153)
            d.rounded_rectangle([36, 250, 320, 306], radius=12, fill=badge)
            d.text((56, 268), "FAIL" if failed else "PASS", fill=(10, 14, 26))
            for r in range(6):
                y = 350 + r * 40
                d.rounded_rectangle(
                    [36, y, 36 + (620 - r * 60), y + 20], radius=8, fill=(23, 31, 52)
                )
            d.text(
                (36, H - 42),
                f"test_id={test_id}  ·  captured by TestGenX (simulated)",
                fill=(92, 104, 131),
            )
            slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")[:40] or "step"
            p = evidence_dir / f"step_{i:02d}_{slug}.png"
            img.save(p)
            paths.append(p)
        return paths


playwright_runner = PlaywrightRunner()
