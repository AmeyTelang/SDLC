"""Audit trail routes — read-only by design.

Mount in main.py:

    from routes.audit_routes import router as audit_router
    app.include_router(audit_router)

There is deliberately **no write endpoint**. Entries are created only as a
side effect of workflow actions, which is what makes the trail trustworthy:
nothing can post a fabricated event, and nothing can amend a real one.

Both roles may read the trail (`audit.view`). That is intentional — an audit
log that only the approver can see is weaker evidence, because the reviewed
party cannot verify what was recorded about their own work.
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Query
from fastapi.responses import PlainTextResponse

from auth.dependencies import require
from auth.roles import User
from services.audit_log import ACTION_META, audit_log

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("/events")
def events(
    actor: Optional[str] = None,
    action: Optional[str] = None,
    stage: Optional[str] = None,
    severity: Optional[str] = None,
    entity_id: Optional[str] = None,
    project_id: Optional[str] = None,
    since: Optional[str] = None,
    until: Optional[str] = None,
    search: Optional[str] = None,
    limit: int = Query(default=200, le=2000),
    offset: int = 0,
    user: User = Depends(require("audit.view")),
):
    """Filtered, paginated event feed (newest first)."""
    return audit_log.query(
        actor=actor,
        action=action,
        stage=stage,
        severity=severity,
        entity_id=entity_id,
        project_id=project_id,
        since=since,
        until=until,
        search=search,
        limit=limit,
        offset=offset,
    )


@router.get("/events/{entity_id}")
def entity_trail(entity_id: str, user: User = Depends(require("audit.view"))):
    """Chronological trail for a single test — the per-record story."""
    return {"entity_id": entity_id, "entries": audit_log.for_entity(entity_id)}


@router.get("/stats")
def stats(days: int = 30, user: User = Depends(require("audit.view"))):
    return audit_log.stats(days=days)


@router.get("/verify")
def verify(user: User = Depends(require("audit.view"))):
    """Walk the hash chain and report the first break, if any."""
    return audit_log.verify()


@router.get("/filters")
def filters(user: User = Depends(require("audit.view"))):
    """Populate the filter dropdowns from what is actually in the log."""
    return {
        "actors": audit_log.distinct("actor"),
        "projects": audit_log.distinct("project_name"),
        "stages": sorted({m["stage"] for m in ACTION_META.values()}),
        "severities": ["info", "success", "warn", "alert"],
        "actions": [
            {"value": a, "label": m["label"], "stage": m["stage"]}
            for a, m in sorted(ACTION_META.items(), key=lambda kv: kv[1]["label"])
        ],
    }


@router.get("/export.csv", response_class=PlainTextResponse)
def export_csv(
    actor: Optional[str] = None,
    action: Optional[str] = None,
    stage: Optional[str] = None,
    severity: Optional[str] = None,
    entity_id: Optional[str] = None,
    project_id: Optional[str] = None,
    since: Optional[str] = None,
    until: Optional[str] = None,
    search: Optional[str] = None,
    user: User = Depends(require("audit.view")),
):
    csv_text = audit_log.export_csv(
        actor=actor,
        action=action,
        stage=stage,
        severity=severity,
        entity_id=entity_id,
        project_id=project_id,
        since=since,
        until=until,
        search=search,
    )
    return PlainTextResponse(
        csv_text,
        media_type="text/csv",
        headers={
            "Content-Disposition": 'attachment; filename="testgenx_audit_trail.csv"'
        },
    )


@router.get("/export.json")
def export_json(
    actor: Optional[str] = None,
    action: Optional[str] = None,
    stage: Optional[str] = None,
    severity: Optional[str] = None,
    entity_id: Optional[str] = None,
    project_id: Optional[str] = None,
    since: Optional[str] = None,
    until: Optional[str] = None,
    search: Optional[str] = None,
    user: User = Depends(require("audit.view")),
):
    """JSON export carries the integrity verdict alongside the entries."""
    return audit_log.export_json(
        actor=actor,
        action=action,
        stage=stage,
        severity=severity,
        entity_id=entity_id,
        project_id=project_id,
        since=since,
        until=until,
        search=search,
    )
