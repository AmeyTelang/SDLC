"""HITL review/approval routes — engineer self-review + Lead send-back.

Mount in main.py:

    from routes.hitl_workflow import router as hitl_router
    app.include_router(hitl_router)

Role matrix
-----------
Test Engineer : generate -> review own DRAFT -> submit -> (withdraw) ->
                regenerate after a send-back
Test Lead     : see SUBMITTED queue -> pull -> approve | send back | reject
                -> execute
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from services import orchestrator
from agents.approval_gate import CHANGES_REQUESTED, DRAFT, approval_gate
from auth.dependencies import current_user, require
from auth.roles import TEST_LEAD, User
from models.schemas import GenerateRequest
from services import audit_hooks

router = APIRouter(prefix="/api/workflow", tags=["workflow-hitl"])

SSE_HEADERS = {
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "X-Accel-Buffering": "no",
}


class SubmitRequest(BaseModel):
    note: Optional[str] = ""


class DecisionRequest(BaseModel):
    comment: Optional[str] = ""


class SendBackRequest(BaseModel):
    feedback: str


# ======================================================================
# TEST ENGINEER — generate (result is a DRAFT, not queued)
# ======================================================================
@router.post("/generate")
def generate(
    req: GenerateRequest,
    headless: bool = True,
    user: User = Depends(require("test.generate")),
):
    return StreamingResponse(
        orchestrator.run_generation_stream(
            req, headless=headless, requested_by=user.email
        ),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


# ======================================================================
# TEST ENGINEER — my scripts (drafts, submitted, returned)
# ======================================================================
@router.get("/my-scripts")
def my_scripts(user: User = Depends(current_user)):
    return approval_gate.my_scripts(user.email)


@router.get("/draft/{test_id}")
def draft(test_id: str, user: User = Depends(current_user)):
    """Re-open one of your own scripts (draft or returned) for review."""
    item = approval_gate.artifact(test_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Script not found.")
    if user.role != TEST_LEAD and item.get("requested_by") != user.email:
        raise HTTPException(status_code=403, detail="This is not your script.")
    return item


@router.post("/submit/{test_id}")
def submit(
    test_id: str,
    body: SubmitRequest | None = None,
    user: User = Depends(require("test.generate")),
):
    """Engineer has reviewed the draft and sends it to the Test Lead."""
    body = body or SubmitRequest()
    rec = approval_gate.get(test_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Script not found.")
    if rec.requested_by and rec.requested_by != user.email:
        raise HTTPException(
            status_code=403, detail="You can only submit your own scripts."
        )
    try:
        rec = approval_gate.submit(test_id, submitted_by=user.email, note=body.note)
        audit_hooks.submitted(rec, actor=user.email, role=user.role, note=body.note)
        return rec.summary()
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.post("/withdraw/{test_id}")
def withdraw(test_id: str, user: User = Depends(require("test.generate"))):
    """Pull a submission back before the Lead decides."""
    rec = approval_gate.get(test_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Script not found.")
    if rec.requested_by and rec.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your script.")
    try:
        rec = approval_gate.withdraw(test_id, actor=user.email)
        audit_hooks.withdrawn(rec, actor=user.email, role=user.role)
        return rec.summary()
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@router.delete("/draft/{test_id}")
def discard_draft(test_id: str, user: User = Depends(require("test.generate"))):
    rec = approval_gate.get(test_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Script not found.")
    if rec.requested_by and rec.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your script.")
    if rec.status not in (DRAFT, CHANGES_REQUESTED):
        raise HTTPException(
            status_code=409,
            detail="Only a draft or a returned script can be discarded.",
        )
    audit_hooks.discarded(approval_gate.get(test_id), actor=user.email, role=user.role)
    approval_gate.discard(test_id)
    orchestrator.PARKED.pop(test_id, None)
    return {"discarded": test_id}


# ======================================================================
# TEST LEAD — queue of SUBMITTED scripts only
# ======================================================================
@router.get("/queue")
def queue(project_id: Optional[str] = None, user: User = Depends(current_user)):
    items = approval_gate.queue(project_id)
    if user.role != TEST_LEAD:
        items = [i for i in items if i.get("requested_by") == user.email]
    return items


@router.get("/queue/{test_id}")
def queue_item(test_id: str, user: User = Depends(require("queue.pull"))):
    item = approval_gate.artifact(test_id)
    audit_hooks.review_opened(item, actor=user.email, role=user.role)
    if item is None:
        raise HTTPException(status_code=404, detail="Not in the approval queue.")
    return item


# ======================================================================
# TEST LEAD — approve | send back for regeneration | reject
# ======================================================================
@router.post("/approve/{test_id}")
def approve(
    test_id: str,
    body: DecisionRequest | None = None,
    user: User = Depends(require("review.approve")),
):
    body = body or DecisionRequest()
    try:
        rec = approval_gate.approve(test_id, user.name or user.email, body.comment)
        audit_hooks.approved(
            rec, actor=user.email, role=user.role, comment=body.comment
        )
        return rec.summary()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/send-back/{test_id}")
def send_back(
    test_id: str,
    body: SendBackRequest,
    user: User = Depends(require("review.approve")),
):
    """Return the script to the engineer for regeneration, with feedback."""
    if not (body.feedback or "").strip():
        raise HTTPException(
            status_code=422,
            detail="Please tell the engineer what needs to change.",
        )
    try:
        rec = approval_gate.send_back(
            test_id, user.name or user.email, body.feedback.strip()
        )
        audit_hooks.sent_back(
            rec,
            actor=user.name or user.email,
            role=user.role,
            feedback=body.feedback.strip(),
        )
        return rec.summary()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/reject/{test_id}")
def reject(
    test_id: str,
    body: DecisionRequest | None = None,
    user: User = Depends(require("review.approve")),
):
    body = body or DecisionRequest()
    try:
        rec = approval_gate.reject(test_id, user.name or user.email, body.comment)
        audit_hooks.rejected(
            rec, actor=user.email, role=user.role, comment=body.comment
        )
        return rec.summary()
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ======================================================================
# TEST LEAD — execute
# ======================================================================
@router.get("/execute/{test_id}")
def execute(test_id: str, user: User = Depends(require("test.execute"))):
    return StreamingResponse(
        orchestrator.run_execution_stream(test_id),
        media_type="text/event-stream",
        headers=SSE_HEADERS,
    )


@router.get("/approvals/{test_id}")
def approval(test_id: str, user: User = Depends(current_user)):
    rec = approval_gate.get(test_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="No approval request found.")
    return rec.summary()
