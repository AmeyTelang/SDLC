"""HITL registry for Story -> Xray test-case drafts.

Mirrors the lifecycle guarantees of ``agents.approval_gate`` but for authoring
artefacts rather than Playwright scripts:

    DRAFT -> PENDING -> APPROVED -> PUBLISHED
                    \\
                     -> CHANGES_REQUESTED -> (regenerate) -> DRAFT (iter + 1)

Key behaviours
--------------
* ``request()`` reuses the SAME record when a ``draft_id`` is pinned, so a
  rework increments ``iteration`` and resolves the open change request rather
  than creating a parallel card.
* Manual edits are first-class: ``apply_edit`` records that a human changed
  the generated content, which the audit trail needs in order to show that a
  published test is part machine, part human.
* Publication is idempotent - a record that already carries a ``test_key`` is
  never pushed to JIRA twice.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional

from models.testcase_schemas import (
    ConfidenceBand,
    GeneratedTestCase,
    TestCaseDetail,
    TestCaseReviewEvent,
    TestCaseStatus,
    TestCaseSummary,
)

DRAFT = TestCaseStatus.DRAFT
PENDING = TestCaseStatus.PENDING
CHANGES_REQUESTED = TestCaseStatus.CHANGES_REQUESTED
APPROVED = TestCaseStatus.APPROVED
PUBLISHED = TestCaseStatus.PUBLISHED
REJECTED = TestCaseStatus.REJECTED

LEAD_QUEUE_STATUSES = (PENDING, APPROVED)
ENGINEER_STATUSES = (DRAFT, PENDING, CHANGES_REQUESTED, APPROVED, PUBLISHED)


@dataclass
class TestCaseRecord:
    draft_id: str
    story_key: str
    project_key: str
    test_case: GeneratedTestCase
    story: dict = field(default_factory=dict, repr=False)
    status: TestCaseStatus = DRAFT
    iteration: int = 1
    requested_by: str = ""
    approver: str = ""
    comment: str = ""
    feedback: str = ""
    addressed_feedback: str = ""
    test_key: str = ""
    test_url: str = ""
    edited: bool = False
    history: List[TestCaseReviewEvent] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.utcnow)
    submitted_at: Optional[datetime] = None
    decided_at: Optional[datetime] = None
    published_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    def log(self, actor: str, action: str, comment: str = "") -> None:
        self.history.append(
            TestCaseReviewEvent(
                at=datetime.utcnow(),
                actor=actor or "system",
                action=action,
                comment=comment or "",
                iteration=self.iteration,
            )
        )

    @property
    def confidence(self) -> float:
        return self.test_case.quality.score if self.test_case else 0.0

    @property
    def confidence_band(self) -> ConfidenceBand:
        return self.test_case.quality.band if self.test_case else ConfidenceBand.LOW

    def summary_model(self) -> TestCaseSummary:
        return TestCaseSummary(
            draft_id=self.draft_id,
            story_key=self.story_key,
            project_key=self.project_key,
            summary=self.test_case.summary if self.test_case else "",
            status=self.status,
            iteration=self.iteration,
            step_count=len(self.test_case.steps) if self.test_case else 0,
            confidence=self.confidence,
            confidence_band=self.confidence_band,
            requested_by=self.requested_by,
            approver=self.approver,
            comment=self.comment,
            feedback=self.feedback,
            addressed_feedback=self.addressed_feedback,
            test_key=self.test_key,
            test_url=self.test_url,
            edited=self.edited,
            created_at=self.created_at,
            submitted_at=self.submitted_at,
            decided_at=self.decided_at,
            published_at=self.published_at,
            history=list(self.history),
        )

    def detail_model(self) -> TestCaseDetail:
        return TestCaseDetail(
            **self.summary_model().model_dump(),
            test_case=self.test_case,
            story=self.story or None,
        )


class TestCaseGate:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._records: Dict[str, TestCaseRecord] = {}
        self._iterations: Dict[str, int] = {}

    # ------------------------------------------------------------------
    # 1. Generation
    # ------------------------------------------------------------------
    def request(
        self,
        *,
        story_key: str,
        project_key: str,
        test_case: GeneratedTestCase,
        story: Optional[dict] = None,
        requested_by: str = "",
        draft_id: Optional[str] = None,
    ) -> TestCaseRecord:
        with self._lock:
            previous = self._records.get(draft_id) if draft_id else None
            record_id = draft_id if previous else uuid.uuid4().hex[:12]

            iteration = self._iterations.get(record_id, 0) + 1
            self._iterations[record_id] = iteration

            was_returned = bool(previous and previous.status == CHANGES_REQUESTED)
            resolved = previous.feedback if was_returned else ""

            record = TestCaseRecord(
                draft_id=record_id,
                story_key=story_key,
                project_key=project_key,
                test_case=test_case,
                story=story or (previous.story if previous else {}),
                status=DRAFT,
                iteration=iteration,
                requested_by=requested_by
                or (previous.requested_by if previous else ""),
                history=list(previous.history) if previous else [],
                created_at=previous.created_at if previous else datetime.utcnow(),
            )
            record.addressed_feedback = resolved
            record.feedback = ""
            record.comment = ""
            record.log(
                record.requested_by or "engineer",
                "revised" if was_returned else "generated",
                resolved,
            )
            self._records[record_id] = record
            return record

    # ------------------------------------------------------------------
    # 2. Manual edit
    # ------------------------------------------------------------------
    def apply_edit(
        self, draft_id: str, test_case: GeneratedTestCase, actor: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status not in (DRAFT, CHANGES_REQUESTED):
                raise ValueError(
                    f"A test case in state '{record.status.value}' can no longer be edited."
                )
            record.test_case = test_case
            record.edited = True
            record.log(actor or "engineer", "edited")
            return record

    # ------------------------------------------------------------------
    # 3. Engineer submits
    # ------------------------------------------------------------------
    def submit(
        self, draft_id: str, submitted_by: str = "", note: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status not in (DRAFT, CHANGES_REQUESTED):
                raise ValueError(
                    f"Test case '{draft_id}' is '{record.status.value}' and cannot be submitted."
                )
            if not record.test_case.steps:
                raise ValueError(
                    "A test case with no steps cannot be submitted for review."
                )
            record.status = PENDING
            record.submitted_at = datetime.utcnow()
            record.comment = note or ""
            record.feedback = ""
            record.log(submitted_by or "engineer", "submitted", note)
            return record

    def withdraw(self, draft_id: str, actor: str = "") -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status != PENDING:
                raise ValueError("Only a test case awaiting review can be withdrawn.")
            record.status = DRAFT
            record.submitted_at = None
            record.log(actor or "engineer", "withdrawn")
            return record

    # ------------------------------------------------------------------
    # 4. Lead decision
    # ------------------------------------------------------------------
    def approve(
        self, draft_id: str, approver: str = "Test Lead", comment: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status != PENDING:
                raise ValueError(
                    f"Only a submitted test case can be approved (current: '{record.status.value}')."
                )
            record.status = APPROVED
            record.approver = approver or "Test Lead"
            record.comment = comment or ""
            record.decided_at = datetime.utcnow()
            record.log(record.approver, "approved", comment)
            return record

    def send_back(
        self, draft_id: str, approver: str = "Test Lead", feedback: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status != PENDING:
                raise ValueError(
                    f"Only a submitted test case can be sent back (current: '{record.status.value}')."
                )
            record.status = CHANGES_REQUESTED
            record.approver = approver or "Test Lead"
            record.feedback = feedback or ""
            record.addressed_feedback = ""
            record.comment = feedback or ""
            record.decided_at = datetime.utcnow()
            record.log(record.approver, "sent_back", feedback)
            return record

    def reject(
        self, draft_id: str, approver: str = "Test Lead", comment: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            if record.status != PENDING:
                raise ValueError(
                    f"Only a submitted test case can be rejected (current: '{record.status.value}')."
                )
            record.status = REJECTED
            record.approver = approver or "Test Lead"
            record.comment = comment or ""
            record.decided_at = datetime.utcnow()
            record.log(record.approver, "rejected", comment)
            return record

    # ------------------------------------------------------------------
    # 5. Publication
    # ------------------------------------------------------------------
    def assert_publishable(self, draft_id: str) -> TestCaseRecord:
        record = self.get(draft_id)
        if record is None:
            raise PermissionError(f"No test case draft exists for '{draft_id}'.")
        if record.status == PUBLISHED:
            raise PermissionError(
                f"'{draft_id}' was already published to JIRA as {record.test_key}."
            )
        if record.status != APPROVED:
            raise PermissionError(
                "Publication blocked: a test case must be approved by the Test Lead "
                f"before it is created in JIRA (current state: '{record.status.value}')."
            )
        if not record.test_case.steps:
            raise PermissionError("Publication blocked: the test case has no steps.")
        return record

    def mark_published(
        self, draft_id: str, test_key: str, url: str, actor: str = ""
    ) -> TestCaseRecord:
        with self._lock:
            record = self._require(draft_id)
            record.status = PUBLISHED
            record.test_key = test_key
            record.test_url = url
            record.published_at = datetime.utcnow()
            record.log(actor or record.approver or "system", "published", test_key)
            return record

    # ------------------------------------------------------------------
    # 6. Queries
    # ------------------------------------------------------------------
    def _require(self, draft_id: str) -> TestCaseRecord:
        record = self._records.get(draft_id)
        if record is None:
            raise KeyError(f"No test case draft found for '{draft_id}'.")
        return record

    def get(self, draft_id: str) -> Optional[TestCaseRecord]:
        if not draft_id:
            return None
        with self._lock:
            return self._records.get(draft_id)

    def queue(self, project_key: Optional[str] = None) -> List[TestCaseSummary]:
        with self._lock:
            items = [
                r
                for r in self._records.values()
                if r.status in LEAD_QUEUE_STATUSES
                and (not project_key or r.project_key == project_key)
            ]
        items.sort(key=lambda r: r.submitted_at or r.created_at, reverse=True)
        return [r.summary_model() for r in items]

    def mine(self, email: str) -> List[TestCaseSummary]:
        with self._lock:
            items = [
                r
                for r in self._records.values()
                if r.requested_by == email and r.status in ENGINEER_STATUSES
            ]
        items.sort(key=lambda r: r.created_at, reverse=True)
        return [r.summary_model() for r in items]

    def for_story(self, story_key: str) -> List[TestCaseSummary]:
        with self._lock:
            items = [r for r in self._records.values() if r.story_key == story_key]
        items.sort(key=lambda r: r.created_at, reverse=True)
        return [r.summary_model() for r in items]

    def discard(self, draft_id: str) -> None:
        with self._lock:
            self._records.pop(draft_id, None)


testcase_gate = TestCaseGate()
