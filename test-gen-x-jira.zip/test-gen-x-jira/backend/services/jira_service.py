from __future__ import annotations

import io
import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import requests
from services import audit_hooks


class JiraError(Exception):
    pass


@dataclass
class JiraConfig:
    base_url: str = ""
    deployment: str = "cloud"  # "cloud" | "server"
    email: str = ""
    api_token: str = ""  # cloud
    pat: str = ""  # server/DC bearer (optional)
    test_issuetype: str = "Test"
    verify_ssl: bool = True
    xray_client_id: str = ""
    xray_client_secret: str = ""

    @classmethod
    def from_env(cls) -> "JiraConfig":
        return cls(
            base_url=os.getenv("JIRA_BASE_URL", "").rstrip("/"),
            deployment=os.getenv("JIRA_DEPLOYMENT", "cloud").lower(),
            email=os.getenv("JIRA_EMAIL", ""),
            api_token=os.getenv("JIRA_API_TOKEN", ""),
            pat=os.getenv("JIRA_PAT", ""),
            test_issuetype=os.getenv("JIRA_TEST_ISSUETYPE", "Test"),
            verify_ssl=os.getenv("JIRA_VERIFY_SSL", "true").lower()
            in {"1", "true", "yes"},
            xray_client_id=os.getenv("XRAY_CLIENT_ID", ""),
            xray_client_secret=os.getenv("XRAY_CLIENT_SECRET", ""),
        )

    @property
    def api_root(self) -> str:
        # Cloud = REST v3; Server/DC = REST v2.
        return "/rest/api/3" if self.deployment == "cloud" else "/rest/api/2"

    @property
    def search_path(self) -> str:
        # CHANGE-2046: Jira Cloud REMOVED POST /rest/api/3/search -> use /search/jql.
        return (
            f"{self.api_root}/search/jql"
            if self.deployment == "cloud"
            else f"{self.api_root}/search"
        )

    @property
    def xray_configured(self) -> bool:
        return bool(self.xray_client_id and self.xray_client_secret)

    def configured(self) -> bool:
        if not self.base_url:
            return False
        if self.deployment == "cloud":
            return bool(self.email and self.api_token)
        return bool(self.pat or (self.email and self.api_token))


@dataclass
class JiraTest:
    key: str  # e.g. "PROJ-123"
    summary: str
    status: str = ""
    issue_type: str = "Test"
    url: str = ""
    steps: List[str] = field(default_factory=list)  # best-effort plain steps

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "summary": self.summary,
            "status": self.status,
            "issue_type": self.issue_type,
            "url": self.url,
            "steps": self.steps,
        }


class JiraService:
    def __init__(
        self,
        cfg: Optional[JiraConfig] = None,
        session: Optional[requests.Session] = None,
    ):
        self.cfg = cfg or JiraConfig.from_env()
        self._session = session or requests.Session()

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------
    def _auth_kwargs(self) -> Dict[str, Any]:
        """Return requests kwargs for auth (Basic or Bearer)."""
        if self.cfg.deployment == "server" and self.cfg.pat:
            return {"headers": {"Authorization": f"Bearer {self.cfg.pat}"}}
        # Basic auth: email/user + api token/password
        return {"auth": (self.cfg.email, self.cfg.api_token)}

    def _url(self, path: str) -> str:
        return f"{self.cfg.base_url}{path}"

    def _request(self, method: str, path: str, *, expect_json=True, timeout=30, **kw):
        if not self.cfg.configured():
            raise JiraError(
                "JIRA is not configured (set JIRA_BASE_URL and credentials)."
            )
        auth = self._auth_kwargs()
        headers = {"Accept": "application/json"}
        headers.update(auth.get("headers", {}))
        headers.update(kw.pop("headers", {}))
        try:
            resp = self._session.request(
                method,
                self._url(path),
                headers=headers,
                auth=auth.get("auth"),
                verify=self.cfg.verify_ssl,
                timeout=timeout,
                **kw,
            )
        except requests.RequestException as exc:
            raise JiraError(f"JIRA request failed: {exc}") from exc
        if resp.status_code == 401:
            raise JiraError("JIRA auth failed (401) — check email/API token or PAT.")
        if resp.status_code == 403:
            raise JiraError(
                "JIRA permission denied (403) — user lacks project/attachment rights."
            )
        if resp.status_code >= 400:
            raise JiraError(f"JIRA error {resp.status_code}: {resp.text[:300]}")
        if not expect_json:
            return resp
        try:
            return resp.json()
        except Exception:
            return {}

    # ------------------------------------------------------------------
    # 1) List tests from a project  (native JQL; Xray tests are Jira issues)
    # ------------------------------------------------------------------
    def _story_related_keys(self, story_key: str) -> set:
        """Deployment-agnostic: return the set of issue keys related to a story via
        native Jira issue LINKS and SUB-TASKS. Works on Cloud and Server/DC without
        Xray-specific JQL functions."""
        try:
            data = self._request(
                "GET",
                f"{self.cfg.api_root}/issue/{story_key}?fields=issuelinks,subtasks",
            )
        except JiraError:
            return set()
        f = data.get("fields", {}) or {}
        keys = set()
        for st in f.get("subtasks", []) or []:
            k = st.get("key")
            if k:
                keys.add(k)
        for lk in f.get("issuelinks", []) or []:
            for side in ("inwardIssue", "outwardIssue"):
                iss = lk.get(side) or {}
                k = iss.get("key")
                if k:
                    keys.add(k)
        return keys

    def list_tests(
        self,
        project_key: str = "",
        max_results: int = 100,
        extra_jql: str = "",
        story_key: str = "",
    ) -> List[JiraTest]:
        """List Xray Test issues. Two-level selection:
        * project_key only         -> all Tests in the project.
        * project_key + story_key  -> Tests in the project that are LINKED to /
                                      SUB-TASKS of that story (native links).
        * story_key only           -> all Tests linked to / under that story.
        """
        related = self._story_related_keys(story_key) if story_key else None

        clauses = []
        if project_key:
            clauses.append(f'project = "{project_key}"')
        clauses.append(f'issuetype = "{self.cfg.test_issuetype}"')
        if related is not None:
            if not related:
                return []  # story has no linked/sub-task issues at all
            key_list = ", ".join(f'"{k}"' for k in sorted(related))
            clauses.append(f"key in ({key_list})")
        jql = " AND ".join(clauses)
        if extra_jql:
            jql += f" AND ({extra_jql})"
        jql += " ORDER BY key ASC"
        body = {
            "jql": jql,
            "maxResults": max_results,
            "fields": ["summary", "status", "issuetype"],
        }
        data = self._request(
            "POST", self.cfg.search_path, json=body
        )  # CHANGE-2046 endpoint
        out: List[JiraTest] = []
        for it in data.get("issues", []):
            f = it.get("fields", {}) or {}
            out.append(
                JiraTest(
                    key=it.get("key", ""),
                    summary=(f.get("summary") or "").strip(),
                    status=((f.get("status") or {}).get("name") or ""),
                    issue_type=(
                        (f.get("issuetype") or {}).get("name")
                        or self.cfg.test_issuetype
                    ),
                    url=f"{self.cfg.base_url}/browse/{it.get('key','')}",
                )
            )

        # Enrich with Xray Manual Test steps (Action/Data/Expected live in Xray,
        # NOT the Jira description). Best-effort: never breaks the list.
        keys = [t.key for t in out if t.key]
        if keys and self.cfg.xray_configured:
            try:
                steps_by_key = self.get_xray_test_steps(keys)
                for t in out:
                    s = steps_by_key.get((t.key or "").upper())
                    if s:
                        t.steps = s

            except JiraError:
                pass
        return out

    # ------------------------------------------------------------------
    # Xray manual test steps (Action/Data/Expected -> plain-English steps)
    # ------------------------------------------------------------------
    @staticmethod
    def _xray_step_to_nl(action: str, data: str = "") -> str:
        """One Xray step -> one imperative line. Uses Action; appends Data only
        when it adds info the Action doesn't already contain."""
        act = (action or "").strip()
        d = (data or "").strip()
        if d and d.lower() not in ("none", "n/a", "-", "") and d not in act:
            return f'{act} "{d}"' if act else d
        return act

    def _xray_steps_to_nl(self, steps: List[Dict[str, Any]]) -> List[str]:
        out: List[str] = []
        for s in steps or []:
            line = self._xray_step_to_nl(s.get("action", ""), s.get("data", ""))
            if line:
                out.append(line)
        return out

    def _xray_graphql(self, query: str, timeout: int = 40) -> Dict[str, Any]:
        """POST a GraphQL query to Xray Cloud (bearer token) or DC raven GraphQL."""
        if self.cfg.deployment == "cloud":
            token = self._xray_cloud_token()
            url = "https://xray.cloud.getxray.app/api/v2/graphql"
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            }
            auth = None
        else:
            url = self._url("/rest/raven/2.0/api/graphql")
            akw = self._auth_kwargs()
            headers = {"Content-Type": "application/json", **akw.get("headers", {})}
            auth = akw.get("auth")
        try:
            r = self._session.post(
                url,
                headers=headers,
                auth=auth,
                json={"query": query},
                timeout=timeout,
                verify=self.cfg.verify_ssl,
            )
        except requests.RequestException as exc:
            raise JiraError(f"Xray GraphQL request failed: {exc}") from exc
        if r.status_code >= 400:
            raise JiraError(f"Xray GraphQL error {r.status_code}: {r.text[:300]}")
        try:
            payload = r.json()
        except Exception:
            raise JiraError("Xray GraphQL returned non-JSON response.")
        if isinstance(payload, dict) and payload.get("errors"):
            msgs = "; ".join(str(e.get("message", e)) for e in payload["errors"][:3])
            raise JiraError("Xray GraphQL query error: " + msgs)
        return payload

    def get_xray_test_steps(self, test_keys):
        """Fetch manual test steps for the given keys. Normalizes keys to
        UPPERCASE and uses issuekey filter (reliable in Xray Cloud)."""
        if not test_keys:
            return {}
        norm = [str(k).strip().upper() for k in test_keys if str(k).strip()]
        if not norm:
            return {}
        # OR together issuekey filters; robust across a small batch.
        jql = " OR ".join(f"issuekey = '{k}'" for k in norm)
        query = (
            '{ getTests(jql: "' + jql + '", limit: ' + str(len(norm)) + ") "
            '{ results { jira(fields: ["key"]) steps { action data result } } } }'
        )
        data = self._xray_graphql(query)
        results = (((data or {}).get("data") or {}).get("getTests") or {}).get(
            "results"
        ) or []
        out = {}
        for r in results:
            key = (((r or {}).get("jira") or {}).get("key")) or ""
            if key:
                out[key.upper()] = self._xray_steps_to_nl(r.get("steps") or [])

        return out

    def get_issue(self, issue_key: str) -> Dict[str, Any]:
        return self._request("GET", f"{self.cfg.api_root}/issue/{issue_key}")

    # ------------------------------------------------------------------
    # 2) Attach result documents to an individual test issue
    # ------------------------------------------------------------------
    def attach_files(
        self, issue_key: str, files: List[Tuple[str, bytes, str]]
    ) -> List[Dict[str, Any]]:
        """files = list of (filename, content_bytes, content_type). Uploads all in
        one multipart request. Returns the attachment metadata list from Jira."""
        if not files:
            return []
        path = f"{self.cfg.api_root}/issue/{issue_key}/attachments"
        # Jira REQUIRES this header to bypass XSRF check on attachment upload.
        headers = {"X-Atlassian-Token": "no-check"}
        multipart = [
            ("file", (name, io.BytesIO(content), ctype))
            for (name, content, ctype) in files
        ]
        data = self._request(
            "POST", path, headers=headers, files=multipart, timeout=120
        )
        return data if isinstance(data, list) else [data]

    def attach_run_results(
        self,
        issue_key: str,
        *,
        report_bytes: Optional[bytes] = None,
        report_name: str = "TestGenX_Report.pdf",
        report_type: str = "application/pdf",
        evidence_zip: Optional[bytes] = None,
        evidence_name: str = "evidence.zip",
        result_json: Optional[bytes] = None,
    ) -> List[Dict[str, Any]]:
        """Convenience: attach the PDF/HTML report, the evidence zip, and result.json."""
        files: List[Tuple[str, bytes, str]] = []
        if report_bytes:
            files.append((report_name, report_bytes, report_type))
        if evidence_zip:
            files.append((evidence_name, evidence_zip, "application/zip"))
        if result_json:
            files.append(("result.json", result_json, "application/json"))
        if not files:
            raise JiraError("No result documents provided to attach.")
        return self.attach_files(issue_key, files)

    def add_comment(self, issue_key: str, text: str) -> Dict[str, Any]:
        """Post a short summary comment (verdict + link) on the test."""
        if self.cfg.deployment == "cloud":
            # v3 requires Atlassian Document Format
            body = {
                "body": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [{"type": "text", "text": text}],
                        }
                    ],
                }
            }
        else:
            body = {"body": text}
        return self._request(
            "POST", f"{self.cfg.api_root}/issue/{issue_key}/comment", json=body
        )

    # ------------------------------------------------------------------
    # 3) (Optional) Push pass/fail into Xray so the Test flips PASS/FAIL
    # ------------------------------------------------------------------
    def _xray_cloud_token(self) -> str:
        if not (self.cfg.xray_client_id and self.cfg.xray_client_secret):
            raise JiraError("Xray Cloud client_id/secret not configured.")
        r = self._session.post(
            "https://xray.cloud.getxray.app/api/v2/authenticate",
            json={
                "client_id": self.cfg.xray_client_id,
                "client_secret": self.cfg.xray_client_secret,
            },
            timeout=30,
            verify=self.cfg.verify_ssl,
        )
        if r.status_code >= 400:
            raise JiraError(f"Xray auth failed {r.status_code}: {r.text[:200]}")
        return r.text.strip().strip('"')

    @staticmethod
    def _xray_status(status: str) -> str:
        """Map a TestGenX run status to a canonical Xray status."""
        s = (status or "").strip().lower()
        if s in ("passed", "pass", "ok", "success"):
            return "PASSED"
        if s in ("failed", "fail", "error"):
            return "FAILED"
        if s in ("todo", "to do", "pending"):
            return "TODO"
        return "FAILED"

    def import_xray_execution(
        self,
        *,
        project_key: str,
        test_key: str,
        status: str,
        summary: str = "TestGenX automated run",
        comment: str = "",
    ) -> Dict[str, Any]:
        """Create a Xray Test Execution marking `test_key` PASSED/FAILED so the
        result shows on the Xray Test itself. `status` accepts TestGenX values
        (passed/failed/error) or Xray values (PASSED/FAILED)."""
        payload = {
            "info": {"summary": summary, "project": project_key},
            "tests": [
                {
                    "testKey": test_key,
                    "status": self._xray_status(status),
                    "comment": comment or summary,
                }
            ],
        }
        if self.cfg.deployment == "cloud":
            token = self._xray_cloud_token()
            r = self._session.post(
                "https://xray.cloud.getxray.app/api/v2/import/execution",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=60,
                verify=self.cfg.verify_ssl,
            )
        else:
            # Server/DC: same Jira auth, raven endpoint
            auth = self._auth_kwargs()
            r = self._session.post(
                self._url("/rest/raven/1.0/import/execution"),
                headers={"Content-Type": "application/json", **auth.get("headers", {})},
                auth=auth.get("auth"),
                json=payload,
                timeout=60,
                verify=self.cfg.verify_ssl,
            )
        if r.status_code >= 400:
            raise JiraError(f"Xray import failed {r.status_code}: {r.text[:300]}")
        try:
            return r.json()
        except Exception:
            return {"raw": r.text[:500]}


# module-level singleton (configured from env); API layer can also build per-project
jira_service = JiraService()
