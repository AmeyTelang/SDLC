from __future__ import annotations

import base64
import html
from datetime import datetime
from pathlib import Path
from typing import Optional
from services import workspace

import config

BRAND_HEX = "#6a5cff"
OK_HEX = "#167c45"
FAIL_HEX = "#c8102e"
INK = "#1a1d21"
INK_SOFT = "#5b6672"
LINE = "#e7e9ee"


def _evidence_path(test_id: str, file_name: str) -> Path:
    p = workspace.find_evidence(test_id, file_name)
    return p if p else config.EVIDENCE_DIR / test_id / file_name


def _b64_img(path: Path) -> Optional[str]:
    if not path.exists():
        return None
    return base64.b64encode(path.read_bytes()).decode("ascii")


def _sc(status: str) -> str:
    return OK_HEX if status == "passed" else FAIL_HEX


def build_html(run: dict) -> str:
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    status = run["status"]
    vc = _sc(status)
    steps_html = ""
    for s in run.get("structured_steps", []):
        exp = (
            f'<div class="exp">Assertion: {html.escape(str(s["expectation"]))}</div>'
            if s.get("expectation")
            else ""
        )
        steps_html += f'<tr><td class="num">{s["index"]}</td><td>{html.escape(s["action"])}{exp}</td></tr>'
    ev_html = ""
    for e in run.get("evidence", []):
        b64 = _b64_img(_evidence_path(run["test_id"], e["file_name"]))
        img = (
            f'<img src="data:image/png;base64,{b64}" alt="{html.escape(e["step_name"])}"/>'
            if b64
            else '<div class="noimg">Screenshot unavailable</div>'
        )
        color = _sc(e["status"])
        ev_html += f"""<figure class="shot"><figcaption>
          <span class="badge" style="background:{color}">{e["status"].upper()}</span>
          <b>Step {e["step_index"]}</b> · {html.escape(e["step_name"])}</figcaption>
          {img}<div class="cap-src">Captured by: {html.escape(e.get("captured_by","playwright"))}</div></figure>"""
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"/>
<title>Test Evidence Report · {html.escape(run["title"])}</title><style>
*{{box-sizing:border-box}} body{{font-family:"Segoe UI",system-ui,sans-serif;color:{INK};margin:0;background:#f6f7f9}}
.page{{max-width:900px;margin:0 auto;background:#fff}}
.cover{{background:{BRAND_HEX};color:#fff;padding:40px}} .cover .cls{{font-size:12px;letter-spacing:.5px;opacity:.9;text-transform:uppercase}}
.cover h1{{margin:10px 0 4px;font-size:28px}} .cover p{{margin:2px 0;opacity:.95;font-size:14px}}
.content{{padding:32px 40px}}
.verdict{{display:flex;gap:16px;padding:18px 20px;border-radius:12px;background:{vc}12;border:1px solid {vc}44;margin-bottom:24px}}
.verdict .big{{font-size:22px;font-weight:800;color:{vc};text-transform:capitalize}} .verdict .sub{{color:{INK_SOFT};font-size:13px}}
.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:26px}}
.metric{{border:1px solid {LINE};border-radius:10px;padding:14px;text-align:center}} .metric .n{{font-size:24px;font-weight:800}} .metric .l{{font-size:11px;color:{INK_SOFT};text-transform:uppercase;letter-spacing:.4px}}
h2{{font-size:15px;border-bottom:2px solid {BRAND_HEX};padding-bottom:6px;margin:28px 0 14px}}
table{{width:100%;border-collapse:collapse;font-size:13px}} td{{border-bottom:1px solid {LINE};padding:9px 10px;vertical-align:top}} td.num{{width:34px;font-weight:700;color:{BRAND_HEX}}}
.exp{{color:{OK_HEX};font-size:11.5px;margin-top:3px}}
.analysis{{background:#fbfbfd;border:1px dashed {LINE};border-radius:10px;padding:16px;font-size:13px;line-height:1.6}}
.meta{{font-size:12.5px;color:{INK_SOFT};line-height:1.9}} .meta b{{color:{INK}}}
.shot{{margin:0 0 22px;border:1px solid {LINE};border-radius:12px;overflow:hidden}}
.shot figcaption{{padding:10px 14px;font-size:13px;background:#fbfbfd;border-bottom:1px solid {LINE}}} .shot img{{width:100%;display:block}}
.badge{{color:#fff;font-size:10.5px;font-weight:700;padding:3px 9px;border-radius:999px;margin-right:8px}}
.cap-src{{font-size:11px;color:{INK_SOFT};padding:6px 14px}} .noimg{{padding:40px;text-align:center;color:{INK_SOFT}}}
.footer{{padding:20px 40px;font-size:11px;color:{INK_SOFT};border-top:1px solid {LINE}}} code{{font-family:Consolas,monospace;background:#f0f1f4;padding:1px 5px;border-radius:4px;font-size:12px}}
</style></head><body><div class="page">
<div class="cover"><div class="cls">{html.escape(config.REPORT_CLASSIFICATION)}</div>
<h1>Test Evidence Report</h1><p>{html.escape(run["title"])}</p>
<p>Project: {html.escape(str(run.get("project_name") or "—"))} &nbsp;·&nbsp; AUT: {html.escape(str(run.get("aut_url") or "—"))}</p>
<p>{html.escape(config.ORG_NAME)} · Generated {ts}</p></div>
<div class="content">
<div class="verdict"><div><div class="big">{status}</div>
<div class="sub">{run["passed"]}/{run["total"]} checks passed · {run.get("duration_ms",0)} ms · evidence: {run.get("evidence_mode","simulated")}</div></div></div>
<div class="metrics">
<div class="metric"><div class="n">{run["total"]}</div><div class="l">Total</div></div>
<div class="metric"><div class="n" style="color:{OK_HEX}">{run["passed"]}</div><div class="l">Passed</div></div>
<div class="metric"><div class="n" style="color:{FAIL_HEX}">{run["failed"]}</div><div class="l">Failed</div></div>
<div class="metric"><div class="n">{len(run.get("evidence", []))}</div><div class="l">Evidence</div></div></div>
<h2>Run Metadata</h2><div class="meta">
<b>Test ID:</b> <code>{run["test_id"]}</code><br/><b>Language:</b> {run["language"]}<br/>
<b>Script file:</b> <code>{html.escape(run.get("file_name",""))}</code><br/>
<b>Generated by:</b> {run.get("generated_by","")} engine &nbsp;·&nbsp; <b>Verdict by:</b> {run.get("analyzed_by","")} engine<br/>
<b>Finished at:</b> {html.escape(str(run.get("finished_at","")))}</div>
<h2>AI Verdict & Root-Cause Analysis</h2><div class="analysis">{html.escape(run.get("analysis",""))}</div>
<h2>Test Steps</h2><table><tbody>{steps_html}</tbody></table>
<h2>Captured Screenshots ({len(run.get("evidence", []))})</h2>{ev_html or '<p class="meta">No screenshots captured.</p>'}
</div><div class="footer">Generated by <b>TestGenX</b> — Agentic NL → Playwright Test Automation (POC).
AI-generated tests & evidence must be reviewed before use in a validated / GxP environment.</div>
</div></body></html>"""


def build_pdf(run: dict, out_path: Path) -> Path:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        HRFlowable,
        Image,
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )

    brand = colors.HexColor(BRAND_HEX)
    ok = colors.HexColor(OK_HEX)
    fail = colors.HexColor(FAIL_HEX)
    ink_soft = colors.HexColor(INK_SOFT)
    status = run["status"]
    vcolor = ok if status == "passed" else fail
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            "Cls",
            parent=styles["Normal"],
            textColor=colors.white,
            fontSize=9,
            leading=12,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            "CoverTitle",
            parent=styles["Title"],
            textColor=colors.white,
            fontSize=26,
            leading=30,
            alignment=TA_LEFT,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            "CoverSub",
            parent=styles["Normal"],
            textColor=colors.white,
            fontSize=12,
            leading=16,
        )
    )
    styles.add(
        ParagraphStyle(
            "H2b",
            parent=styles["Heading2"],
            textColor=brand,
            fontSize=13,
            spaceBefore=14,
            spaceAfter=6,
        )
    )
    styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=15))
    styles.add(
        ParagraphStyle(
            "Small",
            parent=styles["Normal"],
            fontSize=8.5,
            textColor=ink_soft,
            leading=12,
        )
    )
    styles.add(ParagraphStyle("Cap", parent=styles["Normal"], fontSize=9.5, leading=13))
    story = []
    cover = Table(
        [
            [Paragraph(config.REPORT_CLASSIFICATION.upper(), styles["Cls"])],
            [Paragraph("Test Evidence Report", styles["CoverTitle"])],
            [Paragraph(html.escape(run["title"]), styles["CoverSub"])],
            [
                Paragraph(
                    f'Project: {html.escape(str(run.get("project_name") or "—"))} · '
                    f'AUT: {html.escape(str(run.get("aut_url") or "—"))}',
                    styles["CoverSub"],
                )
            ],
            [
                Paragraph(
                    f"{html.escape(config.ORG_NAME)} · Generated "
                    f'{datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")}',
                    styles["CoverSub"],
                )
            ],
        ],
        colWidths=[17 * cm],
    )
    cover.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), brand),
                ("LEFTPADDING", (0, 0), (-1, -1), 18),
                ("RIGHTPADDING", (0, 0), (-1, -1), 18),
                ("TOPPADDING", (0, 0), (0, 0), 18),
                ("BOTTOMPADDING", (0, -1), (-1, -1), 18),
            ]
        )
    )
    story += [cover, Spacer(1, 16)]
    verdict = Table(
        [
            [
                Paragraph(
                    f'<b><font size=16 color="#{vcolor.hexval()[4:]}">{status.upper()}</font></b><br/>'
                    f'<font size=9 color="#5b6672">{run["passed"]}/{run["total"]} checks passed · '
                    f'{run.get("duration_ms",0)} ms · evidence: {run.get("evidence_mode","simulated")}</font>',
                    styles["Body"],
                )
            ]
        ],
        colWidths=[17 * cm],
    )
    verdict.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fbfbfd")),
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor(LINE)),
                ("LEFTPADDING", (0, 0), (-1, -1), 14),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
            ]
        )
    )
    story += [verdict, Spacer(1, 10)]
    metrics = Table(
        [
            [
                _cell(str(run["total"]), "Total", colors.black, styles),
                _cell(str(run["passed"]), "Passed", ok, styles),
                _cell(str(run["failed"]), "Failed", fail, styles),
                _cell(str(len(run.get("evidence", []))), "Evidence", brand, styles),
            ]
        ],
        colWidths=[4.25 * cm] * 4,
    )
    metrics.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor(LINE)),
                ("INNERGRID", (0, 0), (-1, -1), 0.6, colors.HexColor(LINE)),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
            ]
        )
    )
    story.append(metrics)
    story.append(Paragraph("Run Metadata", styles["H2b"]))
    story.append(
        Paragraph(
            f'<b>Test ID:</b> {run["test_id"]}<br/><b>Language:</b> {run["language"]} · '
            f'<b>Script:</b> {html.escape(run.get("file_name",""))}<br/>'
            f'<b>Generated by:</b> {run.get("generated_by","")} engine · '
            f'<b>Verdict by:</b> {run.get("analyzed_by","")} engine<br/>'
            f'<b>Finished at:</b> {html.escape(str(run.get("finished_at","")))}',
            styles["Body"],
        )
    )
    story.append(Paragraph("AI Verdict & Root-Cause Analysis", styles["H2b"]))
    story.append(Paragraph(html.escape(run.get("analysis", "")), styles["Body"]))
    story.append(Paragraph("Test Steps", styles["H2b"]))
    rows = [
        [
            Paragraph("<b>#</b>", styles["Body"]),
            Paragraph("<b>Step</b>", styles["Body"]),
        ]
    ]
    for s in run.get("structured_steps", []):
        txt = html.escape(s["action"])
        if s.get("expectation"):
            txt += f'<br/><font size=8 color="#167c45">Assertion: {html.escape(str(s["expectation"]))}</font>'
        rows.append(
            [Paragraph(str(s["index"]), styles["Body"]), Paragraph(txt, styles["Body"])]
        )
    steps_tbl = Table(rows, colWidths=[1.2 * cm, 15.8 * cm])
    steps_tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#fbfbfd")),
                ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.HexColor(LINE)),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    story.append(steps_tbl)
    story.append(PageBreak())
    story.append(
        Paragraph(
            f'Captured Screenshots ({len(run.get("evidence", []))})', styles["H2b"]
        )
    )
    for e in run.get("evidence", []):
        color = ok if e["status"] == "passed" else fail
        story.append(
            Paragraph(
                f'<font color="#{color.hexval()[4:]}"><b>[{e["status"].upper()}]</b></font> '
                f'<b>Step {e["step_index"]}</b> · {html.escape(e["step_name"])}',
                styles["Cap"],
            )
        )
        story.append(Spacer(1, 4))
        p = _evidence_path(run["test_id"], e["file_name"])
        if p.exists():
            try:
                img = Image(str(p))
                scale = min(17 * cm / img.imageWidth, 1.0)
                img.drawWidth = img.imageWidth * scale
                img.drawHeight = img.imageHeight * scale
                story.append(img)
            except Exception:
                story.append(
                    Paragraph("(screenshot could not be embedded)", styles["Small"])
                )
        else:
            story.append(Paragraph("(screenshot unavailable)", styles["Small"]))
        story += [
            Paragraph(
                f'Captured by: {e.get("captured_by","playwright")}', styles["Small"]
            ),
            Spacer(1, 8),
            HRFlowable(width="100%", thickness=0.5, color=colors.HexColor(LINE)),
            Spacer(1, 10),
        ]
    story.append(Spacer(1, 10))
    story.append(
        Paragraph(
            "Generated by TestGenX — Agentic NL → Playwright Test Automation (POC). "
            "AI-generated tests & evidence must be reviewed before use in a validated / GxP environment.",
            styles["Small"],
        )
    )
    SimpleDocTemplate(
        str(out_path),
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=1.6 * cm,
        bottomMargin=1.6 * cm,
        title=f'Test Evidence Report - {run["title"]}',
        author="TestGenX",
    ).build(story)
    return out_path


def _cell(n, label, color, styles):
    from reportlab.platypus import Paragraph, Table, TableStyle

    hexcol = "#" + color.hexval()[4:]
    t = Table(
        [
            [
                Paragraph(
                    f'<b><font size=17 color="{hexcol}">{n}</font></b>', styles["Body"]
                )
            ],
            [
                Paragraph(
                    f'<font size=8 color="#5b6672">{label.upper()}</font>',
                    styles["Body"],
                )
            ],
        ]
    )
    t.setStyle(
        TableStyle(
            [
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("TOPPADDING", (0, 0), (-1, -1), 0),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
            ]
        )
    )
    return t


def generate_report(run: dict, fmt: str) -> Path:
    test_id = run["test_id"]
    fmt = (fmt or "pdf").lower()
    if fmt == "html":
        out = config.REPORTS_DIR / f"evidence_report_{test_id}.html"
        out.write_text(build_html(run), encoding="utf-8")
        return out
    out = config.REPORTS_DIR / f"evidence_report_{test_id}.pdf"
    return build_pdf(run, out)
