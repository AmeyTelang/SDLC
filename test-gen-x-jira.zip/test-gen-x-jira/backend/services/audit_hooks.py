"""Workflow -> audit trail emitters.

One function per workflow event, so call sites stay one line and the payload
shape for each action is defined in exactly one place. Import these rather
than calling ``audit_log.record()`` directly - it keeps the action vocabulary
consistent and makes coverage checkable.

Every emitter is failure-isolated: an audit write must never break the
workflow it is observing. A logging failure is itself recorded by the
integrity check, which will show a gap in the sequence.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence

from services.audit_log import (
    AUTH_DENIED,
    AUTH_LOGIN,
    AUTH_LOGOUT,
    EXEC_BLOCKED,
    EXEC_COMPLETED,
    EXEC_STARTED,
    GUARDRAIL_BLOCKED,
    JIRA_PUSHED,
    REVIEW_APPROVED,
    REVIEW_OPENED,
    REVIEW_REJECTED,
    REVIEW_SENT_BACK,
    SCRIPT_DISCARDED,
    SCRIPT_GENERATED,
    SCRIPT_REVISED,
    SCRIPT_SUBMITTED,
    SCRIPT_SUPERSEDED,
    SCRIPT_WITHDRAWN,
    STORY_IMPORTED,
    TEST_IMPORTED,
    TESTCASE_APPROVED,
    TESTCASE_DISCARDED,
    TESTCASE_EDITED,
    TESTCASE_GENERATED,
    TESTCASE_PUBLISH_BLOCKED,
    TESTCASE_PUBLISH_FAILED,
    TESTCASE_PUBLISHED,
    TESTCASE_REJECTED,
    TESTCASE_REVIEW_OPENED,
    TESTCASE_REVISED,
    TESTCASE_SENT_BACK,
    TESTCASE_SUBMITTED,
    TESTCASE_WITHDRAWN,
    audit_log,
)


def _safe(fn):
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None

    wrapper.__name__ = getattr(fn, "__name__", "audit_hook")
    return wrapper


def _rec(rec) -> Dict[str, Any]:
    """Pull the common identity fields off an ApprovalRecord."""
    if rec is None:
        return {}
    get = (
        (lambda k: rec.get(k))
        if isinstance(rec, dict)
        else (lambda k: getattr(rec, k, None))
    )
    return {
        "entity_id": get("test_id"),
        "entity_title": get("title"),
        "project_id": get("project_id"),
        "project_name": get("project_name"),
        "iteration": get("iteration"),
    }


def _tc(rec) -> Dict[str, Any]:
    """Identity fields for a test-case draft record."""
    if rec is None:
        return {}
    get = (
        (lambda k: rec.get(k))
        if isinstance(rec, dict)
        else (lambda k: getattr(rec, k, None))
    )
    case = get("test_case")
    title = getattr(case, "summary", "") if case is not None else ""
    return {
        "entity_type": "testcase",
        "entity_id": get("draft_id"),
        "entity_title": title or get("story_key"),
        "project_name": get("project_key"),
        "iteration": get("iteration"),
    }


def _confidence(rec) -> Optional[float]:
    case = getattr(rec, "test_case", None)
    quality = getattr(case, "quality", None)
    return getattr(quality, "score", None) if quality else None


# ---------------------------------------------------------------- access
@_safe
def login(user):
    return audit_log.record(
        AUTH_LOGIN,
        actor=user.email,
        actor_role=user.role,
        entity_type="session",
        entity_id=user.email,
        summary=f"{user.name} signed in",
        details={
            "provider": getattr(user, "auth_provider", "local"),
            "role": user.role_label,
        },
    )


@_safe
def logout(email, role=None):
    return audit_log.record(
        AUTH_LOGOUT,
        actor=email,
        actor_role=role,
        entity_type="session",
        entity_id=email,
        summary="Signed out",
    )


@_safe
def access_denied(email, role, capability, path=None):
    """A refused request is a governance event - record it, don't swallow it."""
    return audit_log.record(
        AUTH_DENIED,
        actor=email or "anonymous",
        actor_role=role,
        entity_type="session",
        entity_id=email,
        summary=f"Denied '{capability}'",
        details={"capability": capability, "path": path, "role": role},
    )


# ================================================================
# Story -> Xray test case authoring
# ================================================================
@_safe
def story_imported(user, *, story_key, summary_text, scenario_count, project_key=None):
    return audit_log.record(
        STORY_IMPORTED,
        actor=user.email,
        actor_role=user.role,
        entity_type="story",
        entity_id=story_key,
        entity_title=summary_text,
        project_name=project_key,
        summary=(
            f"Imported {story_key} from JIRA - "
            f"{scenario_count} acceptance scenario(s) parsed"
        ),
        details={
            "story_key": story_key,
            "scenario_count": scenario_count,
            "project_key": project_key,
        },
    )


@_safe
def testcase_generated(
    rec,
    *,
    actor,
    role,
    model=None,
    engine=None,
    confidence=None,
    coverage=None,
    repair_attempts=0,
    feedback_addressed=None,
):
    identity = _tc(rec)
    is_revision = bool(feedback_addressed or (identity.get("iteration") or 1) > 1)
    score = confidence if confidence is not None else _confidence(rec)
    return audit_log.record(
        TESTCASE_REVISED if is_revision else TESTCASE_GENERATED,
        actor=actor,
        actor_role=role,
        **identity,
        summary=(
            (
                f"Regenerated test case as iteration {identity.get('iteration')} "
                f"(confidence {score:.2f})"
                if is_revision
                else f"Synthesised an Xray test case from acceptance criteria (confidence {score:.2f})"
            )
            if score is not None
            else "Synthesised an Xray test case from acceptance criteria"
        ),
        details={
            "story_key": getattr(rec, "story_key", None),
            "engine": engine,
            "model": model,
            "temperature": 0,
            "confidence": score,
            "scenario_coverage": coverage,
            "repair_attempts": repair_attempts,
            "step_count": len(
                getattr(getattr(rec, "test_case", None), "steps", []) or []
            ),
            "addressed_feedback": feedback_addressed or None,
        },
    )


@_safe
def testcase_edited(rec, *, actor, role, fields: Sequence[str] = ()):
    return audit_log.record(
        TESTCASE_EDITED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="Generated test case was manually edited before review",
        details={
            "fields_changed": list(fields),
            "story_key": getattr(rec, "story_key", None),
            "confidence_after_edit": _confidence(rec),
        },
    )


@_safe
def testcase_submitted(rec, *, actor, role, note=None):
    return audit_log.record(
        TESTCASE_SUBMITTED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="Test case submitted to the Test Lead for approval",
        details={"note": note, "story_key": getattr(rec, "story_key", None)},
    )


@_safe
def testcase_withdrawn(rec, *, actor, role):
    return audit_log.record(
        TESTCASE_WITHDRAWN,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="Submission withdrawn before a decision was made",
    )


@_safe
def testcase_discarded(rec, *, actor, role):
    return audit_log.record(
        TESTCASE_DISCARDED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="Test case draft discarded by the author",
    )


@_safe
def testcase_review_opened(rec, *, actor, role):
    return audit_log.record(
        TESTCASE_REVIEW_OPENED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="Pulled into the test case review workspace",
    )


@_safe
def testcase_approved(rec, *, actor, role, comment=None):
    return audit_log.record(
        TESTCASE_APPROVED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary=f"Approved by {actor} - cleared for creation in JIRA",
        details={
            "comment": comment,
            "decision": "approved",
            "confidence": _confidence(rec),
            "edited_before_approval": getattr(rec, "edited", False),
        },
    )


@_safe
def testcase_sent_back(rec, *, actor, role, feedback):
    return audit_log.record(
        TESTCASE_SENT_BACK,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary=f"Returned for rework by {actor}",
        details={"feedback": feedback, "decision": "changes_requested"},
    )


@_safe
def testcase_rejected(rec, *, actor, role, comment=None):
    return audit_log.record(
        TESTCASE_REJECTED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary=f"Rejected by {actor}",
        details={"comment": comment, "decision": "rejected"},
    )


@_safe
def testcase_published(
    rec,
    *,
    actor,
    role,
    test_key,
    steps_pushed=0,
    linked=False,
    link_error="",
    step_error="",
):
    return audit_log.record(
        TESTCASE_PUBLISHED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary=f"Created Xray test {test_key} under {getattr(rec, 'story_key', '')}",
        details={
            "test_key": test_key,
            "story_key": getattr(rec, "story_key", None),
            "steps_pushed": steps_pushed,
            "linked_to_story": linked,
            "link_error": link_error or None,
            "step_error": step_error or None,
            "confidence": _confidence(rec),
            "approved_by": getattr(rec, "approver", None),
        },
    )


@_safe
def testcase_publish_blocked(draft_id, *, actor, role, reason):
    """The gate refusing a JIRA write is a governance event worth keeping."""
    return audit_log.record(
        TESTCASE_PUBLISH_BLOCKED,
        actor=actor,
        actor_role=role,
        entity_type="testcase",
        entity_id=draft_id,
        summary="Test creation blocked by the approval gate",
        details={"reason": reason},
    )


@_safe
def testcase_publish_failed(rec, *, actor, role, reason):
    return audit_log.record(
        TESTCASE_PUBLISH_FAILED,
        actor=actor,
        actor_role=role,
        **_tc(rec),
        summary="JIRA rejected the test creation request",
        details={"reason": reason, "story_key": getattr(rec, "story_key", None)},
    )


# ---------------------------------------------------------------- authoring
@_safe
def test_imported(user, key, summary_text, step_count, project_name=None):
    return audit_log.record(
        TEST_IMPORTED,
        actor=user.email,
        actor_role=user.role,
        entity_type="jira",
        entity_id=key,
        entity_title=summary_text,
        project_name=project_name,
        summary=f"Imported {key} from JIRA/Xray ({step_count} steps)",
        details={"jira_key": key, "step_count": step_count},
    )


# ---------------------------------------------------------------- generation
@_safe
def generated(
    rec,
    *,
    actor,
    role,
    model=None,
    engine=None,
    tokens=None,
    revision_of=None,
    feedback_addressed=None,
    step_confidence=None,
    steps_clarified=None,
):
    identity = _rec(rec)
    is_revision = bool(
        revision_of or feedback_addressed or (identity.get("iteration") or 1) > 1
    )
    return audit_log.record(
        SCRIPT_REVISED if is_revision else SCRIPT_GENERATED,
        actor=actor,
        actor_role=role,
        **identity,
        summary=(
            f"Regenerated as iteration {identity.get('iteration')}"
            if is_revision
            else "Agent X generated the draft script"
        ),
        details={
            "engine": engine,
            "model": model,
            "tokens": tokens,
            "temperature": 0,
            "deterministic": True,
            "step_count": getattr(rec, "step_count", None),
            "step_confidence": step_confidence,
            "steps_clarified": steps_clarified,
            "addressed_feedback": feedback_addressed,
        },
    )


@_safe
def superseded(old_id, new_id, actor=None, title=None):
    return audit_log.record(
        SCRIPT_SUPERSEDED,
        actor=actor or "system",
        actor_role="system",
        entity_id=old_id,
        entity_title=title,
        summary=f"Retired - replaced by {new_id}",
        details={"superseded_by": new_id},
    )


# ---------------------------------------------------------------- review
@_safe
def submitted(rec, *, actor, role, note=None):
    return audit_log.record(
        SCRIPT_SUBMITTED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary="Submitted to the Test Lead for approval",
        details={"note": note},
    )


@_safe
def withdrawn(rec, *, actor, role):
    return audit_log.record(
        SCRIPT_WITHDRAWN,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary="Submission withdrawn before a decision was made",
    )


@_safe
def discarded(rec, *, actor, role):
    return audit_log.record(
        SCRIPT_DISCARDED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary="Draft discarded by the author",
    )


@_safe
def review_opened(rec, *, actor, role):
    return audit_log.record(
        REVIEW_OPENED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary="Pulled into the review workspace",
    )


@_safe
def approved(rec, *, actor, role, comment=None):
    return audit_log.record(
        REVIEW_APPROVED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary=f"Approved by {actor} - released to the Execution Agent",
        details={"comment": comment, "decision": "approved"},
    )


@_safe
def sent_back(rec, *, actor, role, feedback):
    return audit_log.record(
        REVIEW_SENT_BACK,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary=f"Returned for rework by {actor}",
        details={"feedback": feedback, "decision": "changes_requested"},
    )


@_safe
def rejected(rec, *, actor, role, comment=None):
    return audit_log.record(
        REVIEW_REJECTED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary=f"Rejected by {actor}",
        details={"comment": comment, "decision": "rejected"},
    )


# ---------------------------------------------------------------- execution
@_safe
def execution_started(rec, *, actor, role):
    return audit_log.record(
        EXEC_STARTED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary="Execution Agent started the run",
    )


@_safe
def execution_completed(rec, *, actor, role, result):
    get = (
        (lambda k: result.get(k))
        if isinstance(result, dict)
        else (lambda k: getattr(result, k, None))
    )
    status = str(get("status") or "unknown").upper()
    return audit_log.record(
        EXEC_COMPLETED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary=f"{status} - {get('passed')}/{get('total')} checks passed",
        details={
            "status": get("status"),
            "passed": get("passed"),
            "total": get("total"),
            "failed": get("failed"),
            "duration_ms": get("duration_ms"),
            "evidence_count": len(get("evidence") or []),
            "evidence_mode": get("evidence_mode"),
            "analyzed_by": get("analyzed_by"),
        },
    )


@_safe
def execution_blocked(test_id, *, actor, role, reason, status=None):
    """The gate refusing a run is the single most important event to keep."""
    return audit_log.record(
        EXEC_BLOCKED,
        actor=actor,
        actor_role=role,
        entity_id=test_id,
        summary="Execution blocked by the approval gate",
        details={"reason": reason, "record_status": status},
    )


# ---------------------------------------------------------------- publication
@_safe
def jira_pushed(rec, *, actor, role, issue_key, status=None):
    return audit_log.record(
        JIRA_PUSHED,
        actor=actor,
        actor_role=role,
        **_rec(rec),
        summary=f"Results published to {issue_key}",
        details={"jira_key": issue_key, "run_status": status},
    )


# ---------------------------------------------------------------- governance
@_safe
def guardrail(kind, *, actor=None, role=None, test_id=None, detail=None):
    return audit_log.record(
        GUARDRAIL_BLOCKED,
        actor=actor or "system",
        actor_role=role,
        entity_id=test_id,
        summary=f"Guardrail triggered: {kind}",
        details={"guardrail": kind, **(detail or {})},
    )
