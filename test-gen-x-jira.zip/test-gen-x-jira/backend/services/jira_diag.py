from __future__ import annotations

from typing import Any, Dict, List

import requests
from fastapi import APIRouter, HTTPException

from services.jira_service import JiraService, JiraError

router = APIRouter(prefix="/api/jira/xray", tags=["jira-xray"])


def _svc() -> JiraService:
    return JiraService()


def _norm_key(key: str) -> str:
    # Jira keys are UPPERCASE (e.g. DP-2); users/urls may pass dp-2.
    return (key or "").strip().upper()


def _step_query(key: str, limit: int = 1) -> str:
    k = _norm_key(key)
    # issuekey = 'DP-2' is the reliable Xray Cloud filter (key in (...) is flaky).
    return (
        "{ getTests(jql: \"issuekey = '%s'\", limit: %d) "
        '{ total results { jira(fields: ["key"]) steps { action data result } } } }'
    ) % (k, limit)


def _step_to_nl(action: str, data: str = "") -> str:
    act = (action or "").strip()
    d = (data or "").strip()
    if d and d.lower() not in ("none", "n/a", "-", "") and d not in act:
        return f'{act} "{d}"' if act else d
    return act


def _post_graphql(svc: JiraService, query: str, timeout: int = 40):
    cfg = svc.cfg
    if cfg.deployment == "cloud":
        token = svc._xray_cloud_token()
        url = "https://xray.cloud.getxray.app/api/v2/graphql"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        auth = None
    else:
        url = f"{cfg.base_url}/rest/raven/2.0/api/graphql"
        akw = svc._auth_kwargs()
        headers = {"Content-Type": "application/json", **akw.get("headers", {})}
        auth = akw.get("auth")
    return requests.post(
        url,
        headers=headers,
        auth=auth,
        json={"query": query},
        timeout=timeout,
        verify=cfg.verify_ssl,
    )


@router.get("/health")
def xray_health():
    svc = _svc()
    cfg = svc.cfg
    info: Dict[str, Any] = {
        "deployment": cfg.deployment,
        "xray_configured": cfg.xray_configured,
    }
    if not cfg.xray_configured and cfg.deployment == "cloud":
        info["auth_ok"] = False
        info["hint"] = (
            "Set XRAY_CLIENT_ID and XRAY_CLIENT_SECRET in .env, then restart."
        )
        return info
    try:
        info["auth_ok"] = (
            bool(svc._xray_cloud_token()) if cfg.deployment == "cloud" else True
        )
    except JiraError as e:
        info["auth_ok"] = False
        info["error"] = str(e)
    return info


@router.get("/steps/{key}")
def xray_steps(key: str):
    svc = _svc()
    cfg = svc.cfg
    norm = _norm_key(key)
    if not cfg.xray_configured and cfg.deployment == "cloud":
        raise HTTPException(
            400,
            "Xray not configured — set XRAY_CLIENT_ID/XRAY_CLIENT_SECRET and restart.",
        )
    try:
        r = _post_graphql(svc, _step_query(norm, 1))
    except JiraError as e:
        raise HTTPException(400, f"Xray auth/setup error: {e}")
    except requests.RequestException as e:
        raise HTTPException(400, f"Xray network error (proxy/SSL?): {e}")

    if r.status_code >= 400:
        raise HTTPException(400, f"Xray GraphQL HTTP {r.status_code}: {r.text[:1200]}")
    try:
        data = r.json()
    except Exception:
        raise HTTPException(400, f"Xray GraphQL non-JSON: {r.text[:1200]}")
    if isinstance(data, dict) and data.get("errors"):
        return {"key": norm, "steps": [], "graphql_errors": data["errors"]}

    results = (((data or {}).get("data") or {}).get("getTests") or {}).get(
        "results"
    ) or []
    total = (((data or {}).get("data") or {}).get("getTests") or {}).get("total")
    steps: List[str] = []
    matched = False
    for res in results:
        rk = (((res or {}).get("jira") or {}).get("key")) or ""
        if not rk or rk.upper() == norm:
            matched = True
            for s in res.get("steps") or []:
                line = _step_to_nl(s.get("action", ""), s.get("data", ""))
                if line:
                    steps.append(line)
    return {
        "key": norm,
        "requested": key,
        "total_from_xray": total,
        "matched_test": matched,
        "step_count": len(steps),
        "steps": steps,
        "note": (
            "If matched_test is false: the key isn't an Xray Test, the "
            "Xray user can't see it, or it's not a Manual Test. If total "
            "is 0, Xray found no test for that issuekey."
        ),
    }
