from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

import config


def slug(project_name: Optional[str], project_id: Optional[str]) -> str:
    base = re.sub(r"[^a-zA-Z0-9]+", "_", (project_name or "").strip().lower()).strip(
        "_"
    )
    if project_id:
        return f"{base or 'project'}_{project_id}"
    return base or "default"


def project_root(
    project_id: Optional[str] = None, project_name: Optional[str] = None
) -> Path:
    root = config.GENERATED_DIR / slug(project_name, project_id)
    (root / "input").mkdir(parents=True, exist_ok=True)  # stays empty
    (root / "output" / "evidence").mkdir(parents=True, exist_ok=True)
    return root


def output_dir(
    project_id: Optional[str] = None, project_name: Optional[str] = None
) -> Path:
    return project_root(project_id, project_name) / "output"


def evidence_dir(
    test_id: str, project_id: Optional[str] = None, project_name: Optional[str] = None
) -> Path:
    d = output_dir(project_id, project_name) / "evidence" / test_id
    d.mkdir(parents=True, exist_ok=True)
    return d


def find_evidence(test_id: str, file_name: str):
    # security guard
    if "/" in file_name or "\\" in file_name or ".." in file_name or ".." in test_id:
        return None
    gen = config.GENERATED_DIR  # = hydra-backup/generated_tests
    # 1) per-project layout: generated_tests/<slug>/output/evidence/<id>/<file>
    for p in gen.glob(f"*/output/evidence/{test_id}/{file_name}"):
        if p.is_file():
            return p
    # 2) any nested evidence/<id>/<file> (defensive)
    for p in gen.glob(f"**/evidence/{test_id}/{file_name}"):
        if p.is_file():
            return p
    # 3) legacy flat: generated_tests/evidence/<id>/<file>
    legacy = config.EVIDENCE_DIR / test_id / file_name
    return legacy if legacy.exists() else None
