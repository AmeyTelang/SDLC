"""
ETL Validation Orchestrator
- Coordinates ETL validation workflow
- Manages communication between agents
- Handles JIRA import/export
- Provides streaming event support
"""

from __future__ import annotations

import logging
from typing import Generator, Optional

from agents.etl_generation_agent import get_etl_generation_agent
from agents.etl_execution_agent import get_etl_execution_agent
from models.schemas import (
    ETLExtractedSpec,
    ETLExecuteResponse,
    ETLGenerateRequest,
    ETLGenerateResponse,
    ETLImportRequest,
    ETLPushRequest,
    ETLPushResult,
    ETLWorkflowEvent,
)

logger = logging.getLogger("testgenx.etl_orchestrator")


class ETLOrchestrator:
    """
    Orchestrates ETL validation workflow:
    1. Import specification from JIRA
    2. Generate SQL validation script
    3. Execute validation
    4. Push results back to JIRA
    """

    def __init__(
        self,
        mistral_api_key: str = "",
        mistral_model: str = "mistral-large-latest",
        db_url: str = "sqlite:///./etl_target.db",
        jira_client=None,
        xray_client=None,
    ):
        """Initialize orchestrator with agent dependencies."""
        self.generation_agent = get_etl_generation_agent(
            api_key=mistral_api_key, model=mistral_model
        )
        self.execution_agent = get_etl_execution_agent(
            db_url=db_url, api_key=mistral_api_key
        )
        self.jira_client = jira_client
        self.xray_client = xray_client

    # ========================================================================
    # Workflow Orchestration
    # ========================================================================

    def import_spec(self, req: ETLImportRequest) -> ETLExtractedSpec:
        """
        Import ETL specification from JIRA story.

        Args:
            req: Import request with story key

        Returns:
            Extracted specification with business rules and LOVs
        """
        if not self.jira_client:
            raise RuntimeError("JIRA client not configured")

        logger.info(f"Importing spec from {req.story_key}")
        description = self.jira_client.get_story_description(req.story_key)
        summary = self.jira_client.get_story_summary(req.story_key)

        return self.generation_agent.extract_spec(
            story_key=req.story_key,
            description=description,
            summary=summary,
        )

    def generate_script(self, req: ETLGenerateRequest) -> ETLGenerateResponse:
        """
        Generate SQL validation script from specification.

        Args:
            req: Generation request with ETL spec

        Returns:
            Generated script with test steps
        """
        logger.info(f"Generating script for {req.spec.story_key}")
        return self.generation_agent.generate(req)

    def execute_validation(
        self, test_id: str, script: ETLGenerateResponse
    ) -> ETLExecuteResponse:
        """
        Execute SQL validation against target database.

        Args:
            test_id: Test identifier
            script: Generated validation script

        Returns:
            Execution results with pass/fail status
        """
        from models.schemas import ETLExecuteRequest

        logger.info(f"Executing validation {test_id}")
        req = ETLExecuteRequest(test_id=test_id, script=script)
        return self.execution_agent.execute(req)

    def push_results(self, req: ETLPushRequest) -> ETLPushResult:
        """
        Push validation results to JIRA Xray.
        Creates an Xray Test issue, adds test steps, and imports execution results.
        """
        if req.execution.overall_status != "PASS":
            raise RuntimeError(
                f"Validation {req.execution.overall_status}. "
                "Only successful validations can be pushed."
            )

        if not self.jira_client or not self.xray_client:
            raise RuntimeError("JIRA and Xray clients not configured")

        logger.info(f"Pushing results for {req.story_key}")

        # Extract project key from story key (e.g., "PROJ-123" -> "PROJ")
        project_key = req.story_key.split("-")[0]

        # Create Xray Test issue
        summary = f"ETL Validation - {req.story_key} - {req.script.target_table}"
        desc = (
            f"Automated ETL validation for {req.story_key}. "
            f"Target table: {req.script.target_table}."
        )
        test_key = self.xray_client.create_test(
            project_key=project_key,
            summary=summary,
            description=desc,
            issue_type="Test",  # Ensure this matches your Xray issue type
        )
        print(test_key)
        # Link the Xray Test to the Jira story
        self.jira_client.link_issues(req.story_key, test_key, "Test")

        # Add test steps to the Xray Test
        steps = [
            {
                "action": s.action,
                "data": s.data,
                "expected_result": s.expected_result,
            }
            for s in req.script.test_steps
        ]
        self.xray_client.add_test_steps(test_key, steps)

        # Import execution results
        step_payload = [
            {
                "status": s.status,
                "actual_result": s.actual_result,
                "action": s.action,
            }
            for s in req.execution.step_results
        ]
        exec_key = self.xray_client.import_execution(
            test_key, req.story_key, step_payload, req.execution.overall_status
        )

        url = f"{self.jira_client.base}/browse/{test_key}"
        return ETLPushResult(
            test_key=test_key,
            test_execution_key=exec_key,
            url=url,
            status="pushed",
        )

    # ========================================================================
    # Streaming Workflow
    # ========================================================================

    def run_workflow_streaming(
        self, story_key: str, project_id: Optional[str] = None
    ) -> Generator[ETLWorkflowEvent, None, None]:
        """
        Run complete ETL validation workflow with streaming events.

        Yields:
            ETLWorkflowEvent with progress and status updates
        """
        try:
            # Phase 1: Import
            yield ETLWorkflowEvent(
                agent="orchestrator",
                phase="START",
                message=f"Workflow started · story: {story_key}",
                progress=5,
            )

            yield ETLWorkflowEvent(
                agent="generation",
                phase="READ",
                message="Reading JIRA story description…",
                progress=10,
            )

            import_req = ETLImportRequest(story_key=story_key)
            spec = self.import_spec(import_req)

            yield ETLWorkflowEvent(
                agent="generation",
                phase="PROCESS",
                message="Extracting business rules and LOV mappings…",
                progress=25,
            )

            # Phase 2: Generate
            yield ETLWorkflowEvent(
                agent="generation",
                phase="PROCESS",
                message="Synthesizing SQL validation script…",
                progress=40,
            )

            gen_req = ETLGenerateRequest(spec=spec)
            script = self.generate_script(gen_req)

            yield ETLWorkflowEvent(
                agent="generation",
                phase="ARTIFACT",
                message=f"Generated {len(script.test_steps)} validation step(s)",
                progress=55,
            )

            yield ETLWorkflowEvent(
                agent="generation",
                phase="HANDSHAKE",
                message="Complete. Handing off to Execution Agent.",
                progress=60,
            )

            # Phase 3: Execute
            yield ETLWorkflowEvent(
                agent="execution",
                phase="START",
                message="Running SQL validation against target table…",
                progress=65,
            )

            execution = self.execute_validation(script.test_id, script)

            yield ETLWorkflowEvent(
                agent="execution",
                phase="ARTIFACT",
                message=f"{execution.overall_status} — {execution.passed}/{execution.passed + execution.failed} checks passed",
                progress=85,
            )

            yield ETLWorkflowEvent(
                agent="execution",
                phase="DONE",
                message="Validation complete. Ready to push results.",
                progress=95,
            )

            yield ETLWorkflowEvent(
                agent="orchestrator",
                phase="END",
                message=f"Workflow finished · verdict: {execution.overall_status}",
                progress=100,
                data={
                    "story_key": story_key,
                    "target_table": script.target_table,
                    "test_id": script.test_id,
                    "status": execution.overall_status,
                    "passed": execution.passed,
                    "failed": execution.failed,
                },
            )

        except Exception as e:
            logger.exception(f"Workflow error: {e}")
            yield ETLWorkflowEvent(
                agent="orchestrator",
                phase="ERROR",
                message=f"Workflow failed: {str(e)}",
                progress=-1,
            )
            raise


# Singleton instance
_orchestrator: Optional[ETLOrchestrator] = None


def get_etl_orchestrator(
    mistral_api_key: str = "",
    mistral_model: str = "mistral-large-latest",
    db_url: str = "sqlite:///../data/validation.db",
    jira_client=None,
    xray_client=None,
) -> ETLOrchestrator:
    """Get or create the ETL orchestrator singleton.

    Rebuild the singleton whenever the client dependencies are passed in,
    because the first request may have created an instance without Jira/Xray
    clients and later requests would otherwise reuse stale state.
    """
    global _orchestrator

    needs_refresh = (
        _orchestrator is None
        or _orchestrator.jira_client is not jira_client
        or _orchestrator.xray_client is not xray_client
        or _orchestrator.execution_agent is None
    )

    if needs_refresh:
        _orchestrator = ETLOrchestrator(
            mistral_api_key=mistral_api_key,
            mistral_model=mistral_model,
            db_url=db_url,
            jira_client=jira_client,
            xray_client=xray_client,
        )

    return _orchestrator
