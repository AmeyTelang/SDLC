"""Login / session routes.

Mount in main.py:

    from routes.auth_routes import router as auth_router
    app.include_router(auth_router)
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from auth.dependencies import current_user
from auth.roles import User, authenticate
from services import audit_hooks

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginRequest(BaseModel):
    email: str


@router.post("/login")
def login(body: LoginRequest):
    """Resolve an email address to a user + role + capability set."""
    user = authenticate(body.email)
    if user is None:
        raise HTTPException(status_code=401, detail="Enter a valid work email address.")
    audit_hooks.login(user)
    return user.to_dict()


@router.get("/me")
def me(user: User = Depends(current_user)):
    return user.to_dict()


@router.post("/logout")
def logout(user: User = Depends(current_user)):
    audit_hooks.logout(user.email, user.role)
    # Stateless prototype: the client clears its stored session.
    return {"ok": True}
