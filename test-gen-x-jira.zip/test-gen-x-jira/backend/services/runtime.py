from __future__ import annotations

import importlib.util
import shutil
from functools import lru_cache
from pathlib import Path


def _has_module(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None


def _chromium_installed() -> bool:
    for base in (
        Path.home() / ".cache" / "ms-playwright",
        Path.home() / "AppData" / "Local" / "ms-playwright",
    ):
        if base.exists() and any(base.glob("chromium-*")):
            return True
    return False


@lru_cache(maxsize=1)
def browser_available() -> bool:
    return _has_module("playwright") and _chromium_installed()


@lru_cache(maxsize=1)
def python_ready() -> bool:
    return browser_available()


@lru_cache(maxsize=1)
def typescript_ready() -> bool:
    return shutil.which("npx") is not None and browser_available()


def status() -> dict:
    py = python_ready()
    reasons = []
    if not _has_module("playwright"):
        reasons.append("playwright package not installed (pip install playwright)")
    if not _chromium_installed():
        reasons.append("no Chromium binary (run: playwright install chromium)")
    return {
        "python_ready": py,
        "typescript_ready": typescript_ready(),
        "browser_available": browser_available(),
        "evidence_mode": "real" if py else "simulated",
        "reasons": reasons,
    }


def missing_message(language: str) -> str:
    if str(language).startswith("py"):
        return (
            "Real browser run unavailable — install it with:  "
            "pip install playwright  &&  playwright install chromium. "
            "Screenshots for this run were synthesised as placeholders."
        )
    return (
        "TypeScript target simulated — set up @playwright/test in "
        "backend/generated_tests (npm i -D @playwright/test && npx playwright install)."
    )
