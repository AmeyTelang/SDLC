from __future__ import annotations

import io
import json
import zipfile
from typing import List

from services import workspace
import config
from services import report_service, store


def _safe(name: str) -> str:
    keep = "-_. ()"
    return (
        "".join(c for c in (name or "") if c.isalnum() or c in keep)
        .strip()
        .replace(" ", "_")
        or "item"
    )


def _result_json(run: dict) -> str:
    payload = {
        k: run.get(k)
        for k in (
            "test_id",
            "project_id",
            "project_name",
            "title",
            "aut_url",
            "language",
            "status",
            "total",
            "passed",
            "failed",
            "duration_ms",
            "evidence_mode",
            "generated_by",
            "analyzed_by",
            "analysis",
            "created_at",
            "finished_at",
            "structured_steps",
            "step_results",
            "evidence",
        )
    }
    return json.dumps(payload, indent=2, default=str)


def _results_csv(runs: List[dict]) -> str:
    cols = [
        "test_id",
        "title",
        "language",
        "status",
        "total",
        "passed",
        "failed",
        "duration_ms",
        "evidence_mode",
        "generated_by",
        "analyzed_by",
        "created_at",
        "finished_at",
    ]
    lines = [",".join(cols)]
    for r in runs:
        row = []
        for c in cols:
            v = str(r.get(c, "")).replace('"', '""')
            row.append(f'"{v}"' if ("," in v or '"' in v) else v)
        lines.append(",".join(row))
    return "\n".join(lines)


def project_scripts_zip(project_id: str) -> bytes:
    runs = store.list_runs(project_id)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for r in runs:
            fn = r.get("file_name") or f'{r["test_id"]}.txt'
            z.writestr(f"scripts/{fn}", r.get("script", ""))
        z.writestr(
            "MANIFEST.txt",
            f"Scripts for project {project_id}\nTotal runs: {len(runs)}\n"
            + "\n".join(f'- {r.get("file_name")} [{r["status"]}]' for r in runs),
        )
    return buf.getvalue()


def project_evidence_zip(project_id: str) -> bytes:
    runs = store.list_runs(project_id)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for r in runs:
            folder = _safe(f'{r["title"]}_{r["test_id"]}')
            # ev_dir = config.EVIDENCE_DIR / r["test_id"]
            for e in r.get("evidence", []):
                p = workspace.find_evidence(r["test_id"], e["file_name"])
                if p and p.exists():
                    z.writestr(f"{folder}/{e['file_name']}", p.read_bytes())
    return buf.getvalue()


def project_results_zip(project_id: str) -> bytes:
    runs = store.list_runs(project_id)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("results_summary.csv", _results_csv(runs))
        for r in runs:
            z.writestr(
                f'results/{_safe(r["title"])}_{r["test_id"]}.json', _result_json(r)
            )
    return buf.getvalue()


def project_reports_zip(project_id: str, fmt: str = "pdf") -> bytes:
    runs = store.list_runs(project_id)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for r in runs:
            try:
                path = report_service.generate_report(r, fmt)
                z.writestr(
                    f'reports/{_safe(r["title"])}_{r["test_id"]}.{fmt}',
                    path.read_bytes(),
                )
            except Exception:
                continue
    return buf.getvalue()


def run_evidence_zip(run: dict) -> bytes:
    buf = io.BytesIO()
    ev_dir = config.EVIDENCE_DIR / run["test_id"]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for e in run.get("evidence", []):
            p = workspace.find_evidence(run["test_id"], e["file_name"])
            if p and p.exists():
                z.writestr(e["file_name"], p.read_bytes())
        z.writestr("result.json", _result_json(run))
    return buf.getvalue()


def run_bundle_zip(run: dict) -> bytes:
    buf = io.BytesIO()
    ev_dir = config.EVIDENCE_DIR / run["test_id"]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(run.get("file_name", "script.txt"), run.get("script", ""))
        z.writestr("result.json", _result_json(run))
        for e in run.get("evidence", []):
            p = workspace.find_evidence(run["test_id"], e["file_name"])
            if p and p.exists():
                z.writestr(f"evidence/{e['file_name']}", p.read_bytes())
        try:
            pdf = report_service.generate_report(run, "pdf")
            z.writestr("evidence_report.pdf", pdf.read_bytes())
        except Exception:
            pass
    return buf.getvalue()
