from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime
from typing import List, Optional

import config

_LOCK = threading.RLock()


def _now() -> str:
    return datetime.utcnow().isoformat()


def _empty() -> dict:
    return {"projects": {}, "runs": {}}


def _load() -> dict:
    if not config.DB_FILE.exists():
        return _empty()
    try:
        return json.loads(config.DB_FILE.read_text(encoding="utf-8"))
    except Exception:
        return _empty()


def _save(db: dict) -> None:
    tmp = config.DB_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(db, indent=2, default=str), encoding="utf-8")
    tmp.replace(config.DB_FILE)


def seed_default_projects() -> None:
    with _LOCK:
        db = _load()
        if db["projects"]:
            return
        defaults = [
            (
                "SauceDemo Web",
                "https://www.saucedemo.com",
                "Demo e-commerce app used for UI automation walkthroughs.",
            ),
            (
                "Playwright Docs",
                "https://playwright.dev",
                "Public documentation site — good for search & navigation flows.",
            ),
        ]
        for name, url, desc in defaults:
            pid = uuid.uuid4().hex[:8]
            db["projects"][pid] = {
                "id": pid,
                "name": name,
                "aut_url": url,
                "description": desc,
                "created_at": _now(),
                "run_count": 0,
                "last_run_at": None,
            }
        _save(db)


def list_projects() -> List[dict]:
    with _LOCK:
        projs = list(_load()["projects"].values())
    projs.sort(key=lambda p: p.get("created_at", ""))
    return projs


def get_project(project_id: str) -> Optional[dict]:
    with _LOCK:
        return _load()["projects"].get(project_id)


def create_project(name: str, aut_url: str, description: Optional[str] = None) -> dict:
    with _LOCK:
        db = _load()
        pid = uuid.uuid4().hex[:8]
        proj = {
            "id": pid,
            "name": name,
            "aut_url": aut_url,
            "description": description,
            "created_at": _now(),
            "run_count": 0,
            "last_run_at": None,
        }
        db["projects"][pid] = proj
        _save(db)
        return proj


def save_run(run: dict) -> None:
    with _LOCK:
        db = _load()
        db["runs"][run["test_id"]] = run
        pid = run.get("project_id")
        if pid and pid in db["projects"]:
            proj = db["projects"][pid]
            proj["run_count"] = proj.get("run_count", 0) + 1
            proj["last_run_at"] = run.get("finished_at") or _now()
        _save(db)


def get_run(test_id: str) -> Optional[dict]:
    with _LOCK:
        return _load()["runs"].get(test_id)


def list_runs(project_id: Optional[str] = None) -> List[dict]:
    with _LOCK:
        db = _load()
        runs = list(db["runs"].values())
        projects = db["projects"]
    if project_id:
        runs = [r for r in runs if r.get("project_id") == project_id]
    for r in runs:
        pid = r.get("project_id")
        r["project_name"] = projects.get(pid, {}).get("name") if pid else None
    runs.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return runs


def summary(run: dict) -> dict:
    keys = [
        "test_id",
        "project_id",
        "project_name",
        "title",
        "language",
        "status",
        "total",
        "passed",
        "failed",
        "evidence_count",
        "generated_by",
        "analyzed_by",
        "evidence_mode",
        "created_at",
        "finished_at",
    ]
    return {k: run.get(k) for k in keys}
