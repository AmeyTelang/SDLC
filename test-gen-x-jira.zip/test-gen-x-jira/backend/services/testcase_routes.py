"""Story -> Xray test case authoring routes.

Mount in main.py::

    from services.testcase_routes import router as testcase_router
    app.include_router(testcase_router)

Role matrix
-----------
Test Engineer : import story -> generate -> edit -> submit -> (withdraw) ->
                regenerate after a send-back
Test Lead     : see submitted queue -> pull -> approve | send back | reject
                -> publish the Xray test into JIRA

Every transition is written to the tamper-evident audit trail. Publication is
gated server-side: the capability check and ``assert_publishable`` both have to
pass, so a tampered client cannot create a JIRA issue from an unapproved draft.
"""

from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status

from auth.dependencies import current_user, require
from auth.roles import TEST_LEAD, User
from models.testcase_schemas import (
    GeneratedTestCase,
    StoryImportRequest,
    StoryImportResponse,
    TestCaseDecisionRequest,
    TestCaseGenerateRequest,
    TestCasePublishRequest,
    TestCasePublishResult,
    TestCaseSendBackRequest,
    TestCaseSubmitRequest,
    TestCaseUpdateRequest,
)
from services import audit_hooks
from services.jira_service import JiraError
from services.testcase_gate import testcase_gate
from services.xray_authoring import xray_authoring

logger = logging.getLogger("testgenx.testcase_routes")

router = APIRouter(prefix="/api/testcase", tags=["testcase-authoring"])


# ======================================================================
# Health
# ======================================================================
@router.get("/health")
def health(user: User = Depends(current_user)):
    return xray_authoring.health()


# ======================================================================
# TEST ENGINEER / TEST LEAD - import the story
# ======================================================================
@router.post("/import", response_model=StoryImportResponse)
def import_story(
    body: StoryImportRequest,
    user: User = Depends(require("story.import")),
):
    """Fetch the story and parse its BDD acceptance criteria."""
    from agents.story_agent import story_agent

    try:
        story = xray_authoring.fetch_story(body.story_key)
    except JiraError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    criteria, feature, warnings = story_agent.parse(story.get("description"))

    project_key = (
        story.get("project_key")
        or body.project_key
        or (body.story_key.split("-", 1)[0] if "-" in body.story_key else "")
    ).upper()

    audit_hooks.story_imported(
        user,
        story_key=story["story_key"],
        summary_text=story.get("summary", ""),
        scenario_count=len(feature.scenarios),
        project_key=project_key,
    )

    raw_text = ""
    try:
        from agents.bdd_parser import normalise_description

        raw_text = normalise_description(story.get("description"))
    except Exception:  # pragma: no cover
        raw_text = ""

    payload = feature.to_dict()
    return StoryImportResponse(
        story_key=story["story_key"],
        project_key=project_key,
        summary=story.get("summary", ""),
        issue_type=story.get("issue_type", ""),
        status=story.get("status", ""),
        url=story.get("url", ""),
        raw_description=raw_text,
        acceptance_criteria=criteria,
        feature=payload.get("feature", ""),
        background=payload.get("background", []),
        scenarios=payload.get("scenarios", []),
        structured=payload.get("structured", False),
        scenario_count=payload.get("scenario_count", 0),
        parse_warnings=warnings,
    )


# ======================================================================
# TEST ENGINEER - generate / regenerate
# ======================================================================
@router.post("/generate")
def generate(
    body: TestCaseGenerateRequest,
    user: User = Depends(require("testcase.generate")),
):
    """Synthesise an Xray test case from the acceptance criteria."""
    from agents.llm_client import llm_client
    from agents.story_agent import story_agent

    if (
        not (body.acceptance_criteria or "").strip()
        and not (body.raw_description or "").strip()
    ):
        raise HTTPException(
            status_code=422,
            detail="This story has no acceptance criteria to derive a test case from.",
        )

    previous = testcase_gate.get(body.draft_id) if body.draft_id else None
    if previous and previous.requested_by and previous.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")

    request = body.model_copy()
    if previous and previous.feedback and not request.feedback:
        request.feedback = previous.feedback

    try:
        case = story_agent.generate(request)
    except Exception as exc:  # pragma: no cover - defensive
        logger.exception("Test case synthesis failed for %s", body.story_key)
        raise HTTPException(
            status_code=500, detail=f"Test case synthesis failed: {exc}"
        )

    record = testcase_gate.request(
        story_key=body.story_key,
        project_key=(body.project_key or "").upper(),
        test_case=case,
        story={
            "summary": body.summary,
            "acceptance_criteria": body.acceptance_criteria,
        },
        requested_by=user.email,
        draft_id=body.draft_id,
    )

    audit_hooks.testcase_generated(
        record,
        actor=user.email,
        role=user.role,
        model=getattr(llm_client, "model", None),
        engine=case.quality.generated_by,
        confidence=case.quality.score,
        coverage=case.quality.scenario_coverage,
        repair_attempts=case.quality.repair_attempts,
        feedback_addressed=record.addressed_feedback,
    )

    return record.detail_model()


# ======================================================================
# TEST ENGINEER - my drafts
# ======================================================================
@router.get("/mine")
def mine(user: User = Depends(current_user)):
    return testcase_gate.mine(user.email)


@router.get("/drafts/{draft_id}")
def draft(draft_id: str, user: User = Depends(current_user)):
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Test case draft not found.")
    if user.role != TEST_LEAD and record.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")
    return record.detail_model()


@router.put("/drafts/{draft_id}")
def edit_draft(
    draft_id: str,
    body: TestCaseUpdateRequest,
    user: User = Depends(require("testcase.generate")),
):
    """Persist the reviewer's manual edits to the generated content."""
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Test case draft not found.")
    if record.requested_by and record.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")

    updated = record.test_case.model_copy(deep=True)
    patch = body.model_dump(exclude_none=True)

    if "steps" in patch:
        steps = [s for s in body.steps or [] if (s.action or "").strip()]
        for position, step in enumerate(steps, start=1):
            step.index = position
        updated.steps = steps
    for field in ("summary", "description", "precondition", "priority", "labels"):
        if field in patch:
            setattr(updated, field, patch[field])

    if not updated.steps:
        raise HTTPException(
            status_code=422, detail="A test case must retain at least one step."
        )

    # A human edit invalidates the machine's self-report but not the coverage
    # oracle, so the case is re-scored against the original criteria.
    try:
        from agents import bdd_parser
        from agents.story_agent import score_test_case

        criteria = (record.story or {}).get("acceptance_criteria") or ""
        feature = bdd_parser.parse_bdd(criteria)
        updated.quality = score_test_case(
            updated,
            feature,
            criteria,
            record.test_case.quality.model_self_report,
            record.test_case.quality.generated_by,
            record.test_case.quality.repair_attempts,
        )
        updated.quality.warnings.append("Manually edited after generation.")
    except Exception as exc:  # pragma: no cover
        logger.info("Could not re-score edited test case %s (%s).", draft_id, exc)

    try:
        record = testcase_gate.apply_edit(draft_id, updated, actor=user.email)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_edited(
        record, actor=user.email, role=user.role, fields=sorted(patch.keys())
    )
    return record.detail_model()


@router.post("/drafts/{draft_id}/submit")
def submit(
    draft_id: str,
    body: Optional[TestCaseSubmitRequest] = None,
    user: User = Depends(require("testcase.generate")),
):
    body = body or TestCaseSubmitRequest()
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Test case draft not found.")
    if record.requested_by and record.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")

    try:
        record = testcase_gate.submit(draft_id, submitted_by=user.email, note=body.note)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_submitted(
        record, actor=user.email, role=user.role, note=body.note
    )
    return record.summary_model()


@router.post("/drafts/{draft_id}/withdraw")
def withdraw(draft_id: str, user: User = Depends(require("testcase.generate"))):
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Test case draft not found.")
    if record.requested_by and record.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")

    try:
        record = testcase_gate.withdraw(draft_id, actor=user.email)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_withdrawn(record, actor=user.email, role=user.role)
    return record.summary_model()


@router.delete("/drafts/{draft_id}")
def discard(draft_id: str, user: User = Depends(require("testcase.generate"))):
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Test case draft not found.")
    if record.requested_by and record.requested_by != user.email:
        raise HTTPException(status_code=403, detail="This is not your test case.")
    if record.status.value not in ("draft", "changes_requested"):
        raise HTTPException(
            status_code=409,
            detail="Only a draft or a returned test case can be discarded.",
        )

    audit_hooks.testcase_discarded(record, actor=user.email, role=user.role)
    testcase_gate.discard(draft_id)
    return {"discarded": draft_id}


# ======================================================================
# TEST LEAD - review queue
# ======================================================================
@router.get("/queue")
def queue(project_key: Optional[str] = None, user: User = Depends(current_user)):
    items = testcase_gate.queue(project_key)
    if user.role != TEST_LEAD:
        items = [i for i in items if i.requested_by == user.email]
    return items


@router.get("/queue/{draft_id}")
def queue_item(draft_id: str, user: User = Depends(require("testcase.review"))):
    record = testcase_gate.get(draft_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Not in the review queue.")
    audit_hooks.testcase_review_opened(record, actor=user.email, role=user.role)
    return record.detail_model()


@router.post("/queue/{draft_id}/approve")
def approve(
    draft_id: str,
    body: Optional[TestCaseDecisionRequest] = None,
    user: User = Depends(require("testcase.review")),
):
    body = body or TestCaseDecisionRequest()
    try:
        record = testcase_gate.approve(draft_id, user.name or user.email, body.comment)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_approved(
        record, actor=user.email, role=user.role, comment=body.comment
    )
    return record.summary_model()


@router.post("/queue/{draft_id}/send-back")
def send_back(
    draft_id: str,
    body: TestCaseSendBackRequest,
    user: User = Depends(require("testcase.review")),
):
    if not (body.feedback or "").strip():
        raise HTTPException(
            status_code=422,
            detail="Tell the engineer what needs to change before sending it back.",
        )
    try:
        record = testcase_gate.send_back(
            draft_id, user.name or user.email, body.feedback.strip()
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_sent_back(
        record, actor=user.email, role=user.role, feedback=body.feedback.strip()
    )
    return record.summary_model()


@router.post("/queue/{draft_id}/reject")
def reject(
    draft_id: str,
    body: Optional[TestCaseDecisionRequest] = None,
    user: User = Depends(require("testcase.review")),
):
    body = body or TestCaseDecisionRequest()
    try:
        record = testcase_gate.reject(draft_id, user.name or user.email, body.comment)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))

    audit_hooks.testcase_rejected(
        record, actor=user.email, role=user.role, comment=body.comment
    )
    return record.summary_model()


# ======================================================================
# TEST LEAD - publish to JIRA / Xray
# ======================================================================
@router.post("/queue/{draft_id}/publish", response_model=TestCasePublishResult)
def publish(
    draft_id: str,
    body: Optional[TestCasePublishRequest] = None,
    user: User = Depends(require("testcase.publish")),
):
    """Create the Xray Test under the story. Approval is enforced server-side."""
    body = body or TestCasePublishRequest()

    try:
        record = testcase_gate.assert_publishable(draft_id)
    except PermissionError as exc:
        audit_hooks.testcase_publish_blocked(
            draft_id, actor=user.email, role=user.role, reason=str(exc)
        )
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))

    project_key = (body.project_key or record.project_key or "").upper()

    try:
        result = xray_authoring.publish(
            case=record.test_case,
            story_key=record.story_key,
            project_key=project_key,
            link_type=body.link_type,
        )
    except JiraError as exc:
        audit_hooks.testcase_publish_failed(
            record, actor=user.email, role=user.role, reason=str(exc)
        )
        raise HTTPException(status_code=400, detail=str(exc))

    record = testcase_gate.mark_published(
        draft_id, result["test_key"], result["url"], actor=user.email
    )

    audit_hooks.testcase_published(
        record,
        actor=user.email,
        role=user.role,
        test_key=result["test_key"],
        steps_pushed=result["steps_pushed"],
        linked=result["linked"],
        link_error=result.get("link_error", ""),
        step_error=result.get("step_error", ""),
    )

    return TestCasePublishResult(
        draft_id=draft_id,
        story_key=record.story_key,
        test_key=result["test_key"],
        url=result["url"],
        steps_pushed=result["steps_pushed"],
        linked=result["linked"],
        link_error=result.get("link_error", ""),
    )


@router.get("/story/{story_key}")
def for_story(story_key: str, user: User = Depends(current_user)):
    """Every draft raised against one story - the per-story provenance view."""
    return testcase_gate.for_story(story_key.strip().upper())
