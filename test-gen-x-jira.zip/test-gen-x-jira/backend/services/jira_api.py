from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from services.jira_service import JiraService, JiraError

try:
    from services import store, report_service, archive_service
except Exception:  # pragma: no cover
    store = report_service = archive_service = None

router = APIRouter(prefix="/api/jira", tags=["jira"])


def _svc() -> JiraService:
    return JiraService()


@router.get("/health")
def jira_health():
    cfg = _svc().cfg
    return {
        "configured": cfg.configured(),
        "deployment": cfg.deployment,
        "base_url": cfg.base_url,
        "test_issuetype": cfg.test_issuetype,
        "xray_configured": cfg.xray_configured,
    }


@router.get("/tests")
def jira_list_tests(
    project_key: str = "", story_key: str = "", max_results: int = 100, jql: str = ""
):
    """Two-level lookup:
    * project_key only        -> all Tests in the project.
    * project_key + story_key -> Tests linked to / under that story.
    * story_key only          -> Tests linked to / under that story.
    """
    if not project_key and not story_key:
        raise HTTPException(400, "Provide project_key and/or story_key.")
    try:
        tests = _svc().list_tests(
            project_key=project_key,
            story_key=story_key,
            max_results=max_results,
            extra_jql=jql,
        )
    except JiraError as e:
        raise HTTPException(400, str(e))
    return {
        "project_key": project_key,
        "story_key": story_key,
        "count": len(tests),
        "tests": [t.to_dict() for t in tests],
    }


def _build_result_files(
    run: dict, as_pdf: bool, include_evidence: bool, include_json: bool
):
    fmt = "pdf" if as_pdf else "html"
    report_path = report_service.generate_report(run, fmt)
    report_bytes = (
        report_path.read_bytes()
        if hasattr(report_path, "read_bytes")
        else open(str(report_path), "rb").read()
    )
    report_name = f"TestGenX_{run.get('title','report').replace(' ', '_')}.{fmt}"
    report_type = "application/pdf" if fmt == "pdf" else "text/html"
    evidence_zip = None
    if include_evidence and archive_service is not None:
        try:
            evidence_zip = archive_service.run_evidence_zip(run)
        except Exception:
            evidence_zip = None
    result_json = None
    if include_json:
        try:
            import json as _json

            result_json = _json.dumps(run, default=str).encode("utf-8")
        except Exception:
            result_json = None
    return report_bytes, report_name, report_type, evidence_zip, result_json


class AttachBody(BaseModel):
    test_id: str
    as_pdf: bool = True
    include_evidence: bool = True
    include_result_json: bool = True
    comment: Optional[str] = None


@router.post("/tests/{issue_key}/attach")
def jira_attach_results(issue_key: str, body: AttachBody):
    if store is None:
        raise HTTPException(500, "TestGenX services not available on server.")
    run = store.get_run(body.test_id)
    if not run:
        raise HTTPException(404, f"Run '{body.test_id}' not found.")
    try:
        rb, rn, rt, ez, rj = _build_result_files(
            run, body.as_pdf, body.include_evidence, body.include_result_json
        )
    except Exception as exc:
        raise HTTPException(500, f"Report generation failed: {exc}")
    try:
        svc = _svc()
        attached = svc.attach_run_results(
            issue_key,
            report_bytes=rb,
            report_name=rn,
            report_type=rt,
            evidence_zip=ez,
            evidence_name=f"evidence_{body.test_id}.zip",
            result_json=rj,
        )
        verdict = (run.get("status") or "").upper()
        note = body.comment or (
            f"TestGenX automated run: {verdict}. "
            f"{run.get('passed',0)}/{run.get('total',0)} checks passed. Report and evidence attached."
        )
        try:
            svc.add_comment(issue_key, note)
        except JiraError:
            pass
    except JiraError as e:
        raise HTTPException(400, str(e))
    return {"issue_key": issue_key, "attached": attached, "count": len(attached)}


class XrayBody(BaseModel):
    project_key: str
    status: str
    summary: str = "TestGenX automated run"
    comment: str = ""


@router.post("/tests/{issue_key}/xray")
def jira_xray_execution(issue_key: str, body: XrayBody):
    try:
        result = _svc().import_xray_execution(
            project_key=body.project_key,
            test_key=issue_key,
            status=body.status,
            summary=body.summary,
            comment=body.comment,
        )
    except JiraError as e:
        raise HTTPException(400, str(e))
    return {"issue_key": issue_key, "xray": result}


class PublishBody(BaseModel):
    """One click: attach report/evidence AND record PASS/FAIL on the Xray test."""

    test_id: str
    project_key: str
    as_pdf: bool = True
    include_evidence: bool = True
    include_result_json: bool = True
    push_xray: bool = True


@router.post("/tests/{issue_key}/publish")
def jira_publish(issue_key: str, body: PublishBody):
    if store is None:
        raise HTTPException(500, "TestGenX services not available on server.")
    run = store.get_run(body.test_id)
    if not run:
        raise HTTPException(404, f"Run '{body.test_id}' not found.")
    svc = _svc()
    out = {"issue_key": issue_key}

    # 1) attach documents
    try:
        rb, rn, rt, ez, rj = _build_result_files(
            run, body.as_pdf, body.include_evidence, body.include_result_json
        )
        attached = svc.attach_run_results(
            issue_key,
            report_bytes=rb,
            report_name=rn,
            report_type=rt,
            evidence_zip=ez,
            evidence_name=f"evidence_{body.test_id}.zip",
            result_json=rj,
        )
        out["attached"] = len(attached)
    except (JiraError, Exception) as e:
        raise HTTPException(400, f"Attach failed: {e}")

    # 2) push PASS/FAIL to Xray (best-effort; report is already attached)
    if body.push_xray:
        try:
            status = run.get("status") or "failed"
            summary = f"TestGenX run · {run.get('title','')}".strip()
            comment = (
                f"{run.get('passed',0)}/{run.get('total',0)} checks passed. "
                f"Report attached to {issue_key}."
            )
            out["xray"] = svc.import_xray_execution(
                project_key=body.project_key,
                test_key=issue_key,
                status=status,
                summary=summary,
                comment=comment,
            )
        except JiraError as e:
            out["xray_error"] = str(e)  # surfaced but not fatal

    return out
