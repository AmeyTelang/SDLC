"""FastAPI dependencies that enforce the TestGenX role model.

The SPA identifies the caller with:

    X-User-Email: lead@testgenx.io
    X-User-Role:  test_lead      (advisory only)

The role is ALWAYS re-read from the database server-side, so a tampered
header cannot escalate privileges.
"""

from __future__ import annotations

from typing import Optional

from fastapi import Depends, Header, HTTPException, status

from auth.roles import User, authenticate, has_capability

from services import audit_hooks


def current_user(
    x_user_email: Optional[str] = Header(default=None, alias="X-User-Email"),
) -> User:
    user = authenticate(x_user_email or "")
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Sign in to continue.",
        )
    return user


def require(capability: str):
    """Dependency factory: `Depends(require("test.execute"))`."""

    def _guard(user: User = Depends(current_user)) -> User:
        if not has_capability(user.role, capability):
            audit_hooks.access_denied(user.email, user.role, capability)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"Your role ({user.role}) is not permitted to perform "
                    f"'{capability}'."
                ),
            )
        return user

    return _guard
