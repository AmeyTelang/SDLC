"""Authentication & role-based access control for TestGenX."""

from auth.roles import (  # noqa: F401
    TEST_ENGINEER,
    TEST_LEAD,
    CAPABILITIES,
    ROLE_LABEL,
    User,
    authenticate,
    has_capability,
)
