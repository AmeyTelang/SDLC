"""Role definitions and the prototype user directory for TestGenX.

Two roles access the studio:

* TEST_ENGINEER - imports stories and test cases, runs the authoring and
                  generation agents, reviews and submits their own work.
                  Cannot approve, cannot execute, cannot write to JIRA.
* TEST_LEAD     - reviews submitted artefacts, approves/sends back/rejects,
                  creates the approved Xray test in JIRA, and releases the
                  Execution Agent. Also sees Token Usage.

Run History and the Audit Trail are available to BOTH roles: an audit log only
the approver can read is weaker evidence, because the reviewed party cannot
verify what was recorded about their own work.

Login is by email address (prototype: no password store - swap
``authenticate()`` for your IdP/OIDC call in production).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

TEST_ENGINEER = "test_engineer"
TEST_LEAD = "test_lead"

ROLE_LABEL = {
    TEST_ENGINEER: "Test Engineer",
    TEST_LEAD: "Test Lead",
}

# ----------------------------------------------------------------------
# Capability matrix - the single source of truth for both API guards
# and the UI (served to the client on login).
#
# Separation of duty is deliberate and enforced server-side:
#   * the engineer who authors a test case can never approve it;
#   * only the lead can write anything into JIRA;
#   * the two review queues (test case, script) are gated independently.
# ----------------------------------------------------------------------
CAPABILITIES: Dict[str, List[str]] = {
    TEST_ENGINEER: [
        # Story -> Xray test case authoring
        "story.import",  # pull a story + parse its acceptance criteria
        "testcase.generate",  # run the Story Agent, edit and submit drafts
        "testcase.view.own",  # see their own drafts
        # Script generation
        "test.import",  # JIRA / Xray / manual import
        "test.generate",  # run the Generation Agent
        "queue.view.own",  # see what they submitted (read-only)
        # Cross-cutting
        "history.view",
        "audit.view",
    ],
    TEST_LEAD: [
        # Story -> Xray test case authoring
        "story.import",
        "testcase.view",  # full test case queue
        "testcase.review",  # approve / send back / reject
        "testcase.publish",  # create the Xray test in JIRA (LEAD ONLY)
        # Script generation
        "queue.view",  # full Pending Approval panel
        "queue.pull",  # pull a script into the review workspace
        "review.approve",  # approve / reject
        "test.execute",  # release the Execution Agent
        "jira.push",  # push a passed run to JIRA/Xray
        # Cross-cutting
        "usage.view",  # Token Usage (LEAD ONLY)
        "history.view",
        "audit.view",
    ],
}

# Views each role may open in the SPA.
ALLOWED_VIEWS: Dict[str, List[str]] = {
    TEST_ENGINEER: ["authoring", "studio", "etl", "history", "audit"],
    TEST_LEAD: ["authoring", "review", "etl", "usage", "history", "audit"],
}

DEFAULT_VIEW = {TEST_ENGINEER: "authoring", TEST_LEAD: "review"}


@dataclass
class User:
    email: str
    name: str
    role: str

    @property
    def role_label(self) -> str:
        return ROLE_LABEL.get(self.role, self.role)

    @property
    def is_lead(self) -> bool:
        return self.role == TEST_LEAD

    def to_dict(self) -> dict:
        return {
            "email": self.email,
            "name": self.name,
            "role": self.role,
            "role_label": self.role_label,
            "capabilities": CAPABILITIES.get(self.role, []),
            "allowed_views": ALLOWED_VIEWS.get(self.role, []),
            "default_view": DEFAULT_VIEW.get(self.role, "history"),
        }


# ----------------------------------------------------------------------
# Prototype directory. Replace with your identity source.
# Emails are matched case-insensitively.
# ----------------------------------------------------------------------
USER_DIRECTORY: Dict[str, User] = {
    u.email: u
    for u in [
        User("engineer@testgenx.io", "Test Engineer", TEST_ENGINEER),
        User("lead@testgenx.io", "Test Lead", TEST_LEAD),
    ]
}

# Fallback rule so any corporate address can sign in during the demo:
# addresses containing "lead"/"manager"/"approver" become Test Lead.
LEAD_HINTS = ("lead", "manager", "approver")


def authenticate(email: str) -> Optional[User]:
    if not email or "@" not in email:
        return None

    key = email.strip().lower()
    user = USER_DIRECTORY.get(key)
    if user:
        return user

    local = key.split("@", 1)[0]
    role = TEST_LEAD if any(hint in local for hint in LEAD_HINTS) else TEST_ENGINEER
    display = local.replace(".", " ").replace("_", " ").title()
    return User(key, display, role)


def has_capability(role: str, capability: str) -> bool:
    return capability in CAPABILITIES.get(role, [])
