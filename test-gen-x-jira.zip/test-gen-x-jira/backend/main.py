from __future__ import annotations

import io
import logging

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    FileResponse,
    HTMLResponse,
    PlainTextResponse,
    StreamingResponse,
)

import config
from agents.execution_agent import execution_agent
from agents.generation_agent import generation_agent
from agents.llm_client import llm_client
from backend_validation.router import router as xray_validation_router
from backend_validation.router import seed_on_startup
from etl_validation.router import router as etl_validation_router
from models.schemas import (
    ExecuteRequest,
    ExecuteResponse,
    GenerateRequest,
    GenerateResponse,
    Project,
    ProjectCreate,
)
from services import (
    archive_service,
    orchestrator,
    report_service,
    runtime,
    store,
    workspace,
)
from services.audit_log import audit_log
from services.audit_routes import router as audit_router
from services.auth_routes import router as auth_router
from services.hitl_workflow import router as hitl_router
from services.jira_api import router as jira_router
from services.jira_diag import router as jira_diag_router
from services.testcase_routes import router as testcase_router
from token_tracker import delete_db
from usage_routes import router as usage_routes_router

logging.basicConfig(level=logging.INFO)

store.seed_default_projects()

app = FastAPI(
    title="TestGenX",
    version="4.0.0",
    description=(
        "Agentic test automation - story-to-Xray authoring, NL-to-Playwright "
        "generation, HITL review, execution, evidence and a tamper-evident audit trail."
    ),
)

app.include_router(auth_router)
app.include_router(testcase_router)
app.include_router(hitl_router)
app.include_router(usage_routes_router)
app.include_router(jira_router)
app.include_router(jira_diag_router)
app.include_router(audit_router)
app.include_router(xray_validation_router, prefix="/api/xray-validation")
app.include_router(etl_validation_router, prefix="/api/etl")

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _zip_response(data: bytes, filename: str) -> StreamingResponse:
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def _require_run(test_id: str) -> dict:
    run = store.get_run(test_id) or orchestrator.ARTIFACTS.get(test_id)
    if not run:
        raise HTTPException(404, "Run not found")
    return run


def _require_project(project_id: str) -> dict:
    project = store.get_project(project_id)
    if not project:
        raise HTTPException(404, "Project not found")
    return project


@app.on_event("startup")
def _seed_validation_db() -> None:
    delete_db()
    seed_on_startup()


@app.on_event("startup")
def _warm_audit() -> None:
    """Verify the hash chain at boot so tampering is surfaced immediately."""
    verdict = audit_log.verify()
    if not verdict.get("valid"):
        logging.error(
            "AUDIT INTEGRITY FAILURE at entry #%s: %s",
            verdict.get("broken_at_seq"),
            verdict.get("reason"),
        )


@app.get("/")
def root():
    return {
        "name": "TestGenX",
        "agents": ["story", "generation", "execution"],
        "llm_available": llm_client.available,
        "docs": "/docs",
    }


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "engine": "llm" if llm_client.available else "fallback",
        "model": config.MISTRAL_MODEL if llm_client.available else None,
        "llm_transport": llm_client.mode,
        "runtime": runtime.status(),
    }


# ----------------------------------------------------------------------
# Projects
# ----------------------------------------------------------------------
@app.get("/api/projects")
def list_projects():
    return store.list_projects()


@app.post("/api/projects", response_model=Project)
def create_project(body: ProjectCreate):
    return store.create_project(
        body.name.strip(), body.aut_url.strip(), body.description
    )


@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    return _require_project(project_id)


@app.get("/api/projects/{project_id}/runs")
def project_runs(project_id: str):
    return [store.summary(r) for r in store.list_runs(project_id)]


@app.get("/api/projects/{project_id}/scripts.zip")
def download_project_scripts(project_id: str):
    project = _require_project(project_id)
    return _zip_response(
        archive_service.project_scripts_zip(project_id),
        f"{project['name'].replace(' ', '_')}_scripts.zip",
    )


@app.get("/api/projects/{project_id}/evidence.zip")
def download_project_evidence(project_id: str):
    project = _require_project(project_id)
    return _zip_response(
        archive_service.project_evidence_zip(project_id),
        f"{project['name'].replace(' ', '_')}_evidence.zip",
    )


@app.get("/api/projects/{project_id}/results.zip")
def download_project_results(project_id: str):
    project = _require_project(project_id)
    return _zip_response(
        archive_service.project_results_zip(project_id),
        f"{project['name'].replace(' ', '_')}_results.zip",
    )


@app.get("/api/projects/{project_id}/reports.zip")
def download_project_reports(
    project_id: str, format: str = Query("pdf", pattern="^(pdf|html)$")
):
    project = _require_project(project_id)
    return _zip_response(
        archive_service.project_reports_zip(project_id, format),
        f"{project['name'].replace(' ', '_')}_reports_{format}.zip",
    )


# ----------------------------------------------------------------------
# Runs / history
# ----------------------------------------------------------------------
@app.get("/api/runs")
def list_runs(project_id: str = Query(None)):
    return [store.summary(r) for r in store.list_runs(project_id)]


@app.get("/api/runs/{test_id}")
def get_run(test_id: str):
    return _require_run(test_id)


@app.get("/api/runs/{test_id}/script", response_class=PlainTextResponse)
def get_run_script(test_id: str):
    return _require_run(test_id).get("script", "")


@app.get("/api/runs/{test_id}/result.json")
def get_run_result(test_id: str):
    return _require_run(test_id)


@app.get("/api/runs/{test_id}/evidence.zip")
def download_run_evidence(test_id: str):
    run = _require_run(test_id)
    return _zip_response(
        archive_service.run_evidence_zip(run), f"evidence_{test_id}.zip"
    )


@app.get("/api/runs/{test_id}/bundle.zip")
def download_run_bundle(test_id: str):
    run = _require_run(test_id)
    return _zip_response(archive_service.run_bundle_zip(run), f"testrun_{test_id}.zip")


# ----------------------------------------------------------------------
# Generate / execute
#
# These endpoints are ungated utilities for local diagnostics. The governed
# path that enforces HITL approval is /api/workflow/* in hitl_workflow.py.
# ----------------------------------------------------------------------
@app.post("/api/generate", response_model=GenerateResponse)
def generate(req: GenerateRequest):
    if req.project_id and not req.base_url:
        project = store.get_project(req.project_id)
        if project:
            req.base_url = project["aut_url"]
    return generation_agent.generate(req)


@app.post("/api/execute", response_model=ExecuteResponse)
def execute(req: ExecuteRequest):
    artifact = orchestrator.ARTIFACTS.get(req.test_id) or store.get_run(req.test_id)
    script = req.script or (artifact.get("script") if artifact else None)
    if not script:
        raise HTTPException(404, "No script for this test_id. Generate first.")

    file_name = (artifact.get("file_name") if artifact else None) or (
        f"{req.test_id}.py"
        if req.language.value == "python"
        else f"{req.test_id}.spec.ts"
    )
    return execution_agent.execute(
        req,
        file_name,
        script,
        project_id=(artifact or {}).get("project_id"),
        project_name=(artifact or {}).get("project_name"),
        enforce_approval=True,
    )


# ----------------------------------------------------------------------
# Evidence & reports
# ----------------------------------------------------------------------
@app.get("/api/evidence/{test_id}/{file_name}")
def get_evidence(test_id: str, file_name: str):
    path = workspace.find_evidence(test_id, file_name)
    if not path:
        raise HTTPException(404, "Evidence not found")
    return FileResponse(str(path), media_type="image/png")


@app.get("/api/report/{test_id}")
def get_report(
    test_id: str,
    format: str = Query("pdf", pattern="^(pdf|html)$"),
    download: bool = Query(True),
):
    run = _require_run(test_id)
    try:
        out = report_service.generate_report(run, format)
    except Exception as exc:  # pragma: no cover
        logging.exception("Report generation failed")
        raise HTTPException(500, f"Report generation failed: {exc}")

    title = run.get("title", "report").replace(" ", "_")
    if format == "html":
        if download:
            return FileResponse(
                str(out),
                media_type="text/html",
                filename=f"Evidence_Report_{title}.html",
            )
        return HTMLResponse(out.read_text(encoding="utf-8"))

    return FileResponse(
        str(out), media_type="application/pdf", filename=f"Evidence_Report_{title}.pdf"
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=9091, reload=True)
