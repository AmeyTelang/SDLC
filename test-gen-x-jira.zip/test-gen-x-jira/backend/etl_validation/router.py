"""
ETL Validation Router
- Exposes ETL validation workflow via REST API
- Delegates to orchestrator and agents
- Supports streaming responses
"""

import logging
from typing import Generator

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from models.schemas import (
    ETLExtractedSpec,
    ETLExecuteResponse,
    ETLGenerateRequest,
    ETLGenerateResponse,
    ETLImportRequest,
    ETLPushRequest,
    ETLPushResult,
    ETLWorkflowEvent,
)
from services.etl_orchestrator import get_etl_orchestrator
from .jira_client import JiraClient
from .xray_client import XrayClient
from .config import settings
from .introspect import build_schema_context
from agents.etl_generation_agent import get_etl_generation_agent

logger = logging.getLogger("testgenx.etl_router")

router = APIRouter(tags=["ETL Validation"])


# ============================================================================
# Health & Setup
# ============================================================================


@router.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "ok", "module": "etl_validation"}


@router.get("/config")
def get_config():
    """Get ETL validation module configuration."""
    return {
        "mistral_model": settings.MISTRAL_MODEL,
        "jira_base_url": settings.JIRA_BASE_URL,
        "target_db": settings.TARGET_DB_URL,
    }


# ============================================================================
# Agent Endpoints
# ============================================================================


@router.post("/import", response_model=ETLExtractedSpec)
def import_specification(req: ETLImportRequest):
    """
    Import ETL specification from JIRA story.

    - Fetches story description and summary from JIRA
    - Extracts business rules and LOV mappings using Mistral AI
    - Returns structured specification for script generation
    """
    try:
        orchestrator = get_etl_orchestrator(
            mistral_api_key=settings.MISTRAL_API_KEY,
            mistral_model=settings.MISTRAL_MODEL,
            db_url=settings.TARGET_DB_URL,
            jira_client=JiraClient(),
            xray_client=None,
        )

        spec = orchestrator.import_spec(req)
        logger.info(
            f"Imported spec for {req.story_key}: {len(spec.business_rules)} rules, {len(spec.lovs)} LOVs"
        )
        return spec

    except Exception as e:
        logger.error(f"Import failed: {e}")
        raise HTTPException(status_code=400, detail=f"Import failed: {e}")


@router.post("/generate", response_model=ETLGenerateResponse)
def generate_script(req: ETLGenerateRequest):
    spec = req.spec.model_dump()
    # Ground the generator in the ACTUAL database contents.
    spec["schema_context"] = build_schema_context(spec)
    grounded_spec = type(req.spec)(**spec)
    print(spec["schema_context"])
    """
    Generate SQL validation script from ETL specification.

    - Takes extracted specification
    - Generates SQL SELECT statements for each business rule and LOV
    - Returns structured test steps with SQL queries
    """
    try:
        agent = get_etl_generation_agent(
            api_key=settings.MISTRAL_API_KEY,
            model=settings.MISTRAL_MODEL,
        )
        # script = orchestrator.generate_script(req)
        # logger.info(
        #     f"Generated script {script.test_id}: {len(script.test_steps)} steps for {req.spec.target_table}"
        # )
        return agent.generate(grounded_spec)

    except Exception as e:
        logger.error(f"Generation failed: {e}")
        raise HTTPException(status_code=400, detail=f"Generation failed: {e}")


@router.post("/execute", response_model=ETLExecuteResponse)
def execute_validation(script: ETLGenerateResponse):
    """
    Execute SQL validation against target database.

    - Runs each test step SQL query
    - Collects pass/fail results
    - Performs AI analysis of results
    """
    try:
        orchestrator = get_etl_orchestrator(
            mistral_api_key=settings.MISTRAL_API_KEY,
            mistral_model=settings.MISTRAL_MODEL,
            db_url=settings.TARGET_DB_URL,
        )
        result = orchestrator.execute_validation(script.test_id, script)
        logger.info(
            f"Execution {script.test_id}: {result.overall_status} ({result.passed} passed, {result.failed} failed)"
        )
        return result

    except Exception as e:
        logger.error(f"Execution failed: {e}")
        raise HTTPException(status_code=400, detail=f"Execution failed: {e}")


@router.post("/push", response_model=ETLPushResult)
def push_to_jira(req: ETLPushRequest):
    """
    Push successful validation results to JIRA Xray.

    - Creates Xray Test under story
    - Adds test steps and results
    - Links test to original story
    """
    if req.execution.overall_status != "PASS":
        raise HTTPException(
            status_code=409,
            detail="Validation not successful; only PASS validations can be pushed.",
        )
    try:
        orchestrator = get_etl_orchestrator(
            mistral_api_key=settings.MISTRAL_API_KEY,
            mistral_model=settings.MISTRAL_MODEL,
            db_url=settings.TARGET_DB_URL,
            jira_client=JiraClient(),
            xray_client=XrayClient(),
        )
        result = orchestrator.push_results(req)
        logger.info(f"Pushed results: {result.test_key} at {result.url}")
        return result

    except Exception as e:
        logger.error(f"Push failed: {e}")
        raise HTTPException(status_code=400, detail=f"Push failed: {e}")


# ============================================================================
# Orchestrated Workflow (Streaming)
# ============================================================================


def _workflow_event_stream(
    story_key: str, project_id: str = None
) -> Generator[str, None, None]:
    """
    Generator for streaming workflow events as Server-Sent Events.
    """
    try:
        orchestrator = get_etl_orchestrator(
            mistral_api_key=settings.MISTRAL_API_KEY,
            mistral_model=settings.MISTRAL_MODEL,
            db_url=settings.TARGET_DB_URL,
            jira_client=JiraClient(),
            xray_client=XrayClient(),
        )

        for event in orchestrator.run_workflow_streaming(story_key, project_id):
            yield f"data: {event.model_dump_json()}\n\n"

    except Exception as e:
        logger.exception(f"Workflow streaming error: {e}")
        error_event = ETLWorkflowEvent(
            agent="orchestrator",
            phase="ERROR",
            message=f"Workflow failed: {str(e)}",
            progress=-1,
        )
        yield f"data: {error_event.model_dump_json()}\n\n"


@router.post("/workflow")
def run_workflow(req: ETLImportRequest):
    """
    Run complete ETL validation workflow as streaming response.

    Workflow phases:
    1. IMPORT - Read from JIRA and extract spec
    2. GENERATE - Create SQL validation script
    3. EXECUTE - Run validation and analyze results
    4. PUSH - Save results to JIRA Xray

    Returns: Server-Sent Events stream with progress updates
    """
    return StreamingResponse(
        _workflow_event_stream(req.story_key),
        media_type="text/event-stream",
    )
