import os
from dotenv import load_dotenv

load_dotenv()

_APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_DEFAULT_DB_PATH = os.path.join(_APP_DIR, "data", "validation.db")


class Settings:
    MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
    MISTRAL_MODEL = os.getenv("MISTRAL_MODEL", "mistral-large-latest")

    JIRA_BASE_URL = os.getenv("JIRA_BASE_URL", "").rstrip("/")
    JIRA_EMAIL = os.getenv("JIRA_EMAIL", "")
    JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN", "")
    JIRA_PROJECT_KEY = os.getenv("JIRA_PROJECT_KEY", "ETL")

    XRAY_CLIENT_ID = os.getenv("XRAY_CLIENT_ID", "")
    XRAY_CLIENT_SECRET = os.getenv("XRAY_CLIENT_SECRET", "")
    XRAY_BASE_URL = os.getenv("XRAY_BASE_URL", "https://xray.cloud.getxray.app").rstrip(
        "/"
    )

    TARGET_DB_URL = os.getenv(
        "TARGET_DB_URL",
        "sqlite:///" + _DEFAULT_DB_PATH,
    )


settings = Settings()
