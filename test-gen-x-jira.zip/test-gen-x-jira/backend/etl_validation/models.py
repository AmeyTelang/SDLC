from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class ImportRequest(BaseModel):
    story_key: str = Field(..., description="JIRA story key, e.g. ETL-123")


class BusinessRule(BaseModel):
    id: str
    description: str


class Lov(BaseModel):
    field: str
    source_value: str
    target_value: str


class ExtractedSpec(BaseModel):
    story_key: str
    summary: str = ""
    source_table: str = ""
    target_table: str = ""
    business_rules: List[BusinessRule] = []
    lovs: List[Lov] = []
    raw_description: str = ""


class GenerateRequest(BaseModel):
    spec: ExtractedSpec


class TestStep(BaseModel):
    index: int
    action: str
    data: str
    expected_result: str


class GeneratedScript(BaseModel):
    story_key: str
    target_table: str
    sql_script: str
    test_steps: List[TestStep] = []


class ExecuteRequest(BaseModel):
    script: GeneratedScript


class StepResult(BaseModel):
    index: int
    action: str
    expected_result: str
    actual_result: str
    status: str  # PASS | FAIL | ERROR


class ExecutionResult(BaseModel):
    story_key: str
    target_table: str
    overall_status: str
    passed: int
    failed: int
    step_results: List[StepResult] = []
    log: str = ""


class PushRequest(BaseModel):
    story_key: str
    execution: ExecutionResult
    script: GeneratedScript


class PushResult(BaseModel):
    test_key: str
    test_execution_key: str
    url: str
    status: str
