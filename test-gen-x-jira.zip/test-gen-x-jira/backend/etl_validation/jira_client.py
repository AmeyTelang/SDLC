import requests
from typing import Dict, Any, List, Optional
from .config import settings


class JiraClient:
    def __init__(self):
        self.base = settings.JIRA_BASE_URL
        self.auth = (settings.JIRA_EMAIL, settings.JIRA_API_TOKEN)
        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------ #
    # Error surfacing                                                     #
    # ------------------------------------------------------------------ #
    @staticmethod
    def _raise_with_body(resp: requests.Response, context: str):
        """JIRA returns a JSON body with `errorMessages` / `errors` on 400s.
        Surface it instead of the opaque 'raise_for_status' message."""
        if resp.ok:
            return
        detail = ""
        try:
            data = resp.json()
            msgs = data.get("errorMessages") or []
            errs = data.get("errors") or {}
            parts = list(msgs) + [f"{k}: {v}" for k, v in errs.items()]
            detail = "; ".join(parts) if parts else resp.text
        except Exception:
            detail = resp.text
        raise RuntimeError(f"{context} [{resp.status_code}]: {detail}")

    # ------------------------------------------------------------------ #
    # Reads                                                               #
    # ------------------------------------------------------------------ #
    def get_story(self, story_key: str) -> Dict[str, Any]:
        url = f"{self.base}/rest/api/3/issue/{story_key}"
        resp = requests.get(url, auth=self.auth, headers=self.headers, timeout=30)
        self._raise_with_body(resp, f"Get story {story_key} failed")
        return resp.json()

    def get_story_description(self, story_key: str) -> str:
        return self._adf_to_text(
            self.get_story(story_key).get("fields", {}).get("description")
        )

    def get_story_summary(self, story_key: str) -> str:
        return self.get_story(story_key).get("fields", {}).get("summary", "")

    def _project_key_of(self, issue_key: str) -> str:
        # Derive project key from an issue key like "DP-7" -> "DP".
        return (issue_key or "").split("-")[0]

    def get_create_issue_types(self, project_key: str) -> List[Dict[str, Any]]:
        """List issue types actually available on this project's create screen."""
        url = f"{self.base}/rest/api/3/issue/createmeta"
        params = {"projectKeys": project_key, "expand": "projects.issuetypes"}
        resp = requests.get(
            url, params=params, auth=self.auth, headers=self.headers, timeout=30
        )
        if not resp.ok:
            return []
        projects = resp.json().get("projects", [])
        if not projects:
            return []
        return projects[0].get("issuetypes", [])

    def _resolve_test_issuetype(self, project_key: str) -> str:
        """Pick a valid issue type: prefer 'Test' (Xray), else 'Task', else the
        first non-subtask type available on the project."""
        types = self.get_create_issue_types(project_key)
        if not types:
            return "Test"
        names = {t.get("name", ""): t for t in types}
        for preferred in ("Test", "Task", "Story", "Bug"):
            t = names.get(preferred)
            if t and not t.get("subtask", False):
                return preferred
        for t in types:
            if not t.get("subtask", False):
                return t.get("name", "Test")
        return "Test"

    # ------------------------------------------------------------------ #
    # Writes                                                              #
    # ------------------------------------------------------------------ #
    def create_test_issue(
        self,
        summary: str,
        description_text: str,
        story_key: str,
        project_key: Optional[str] = None,
        issue_type: Optional[str] = None,
    ) -> str:
        # Choose the project: explicit arg > derived from story > configured default.
        project_key = (
            project_key
            or (self._project_key_of(story_key) if story_key else "")
            or settings.JIRA_PROJECT_KEY
        )
        # Choose a VALID issue type for THIS project (fixes most 400s).
        issue_type = issue_type or self._resolve_test_issuetype(project_key)

        url = f"{self.base}/rest/api/3/issue"
        payload = {
            "fields": {
                "project": {"key": project_key},
                "summary": summary or "ETL Validation",
                "issuetype": {"name": issue_type},
                "description": self._text_to_adf(description_text),
            }
        }
        resp = requests.post(
            url, json=payload, auth=self.auth, headers=self.headers, timeout=30
        )
        # If the type was rejected, retry once with a safe fallback ("Task").
        if resp.status_code == 400 and issue_type != "Task":
            payload["fields"]["issuetype"] = {"name": "Task"}
            resp = requests.post(
                url, json=payload, auth=self.auth, headers=self.headers, timeout=30
            )
        self._raise_with_body(
            resp, f"Create issue in project '{project_key}' as '{issue_type}' failed"
        )
        return resp.json().get("key", "")

    def link_issues(
        self, inward_key: str, outward_key: str, link_type: str = "Test"
    ) -> str:
        url = f"{self.base}/rest/api/3/issueLink"
        payload = {
            "type": {"name": link_type},
            "inwardIssue": {"key": inward_key},
            "outwardIssue": {"key": outward_key},
        }
        try:
            requests.post(
                url, json=payload, auth=self.auth, headers=self.headers, timeout=30
            )
        except Exception:
            pass
        return "done"

    # ------------------------------------------------------------------ #
    # ADF helpers                                                         #
    # ------------------------------------------------------------------ #
    def _text_to_adf(self, text: str) -> Dict[str, Any]:
        return {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [{"type": "text", "text": text or " "}],
                }
            ],
        }

    def _adf_to_text(self, adf: Any) -> str:
        if not adf:
            return ""
        if isinstance(adf, str):
            return adf
        parts: List[str] = []

        def walk(node):
            if isinstance(node, dict):
                if node.get("type") == "text":
                    parts.append(node.get("text", ""))
                for child in node.get("content", []) or []:
                    walk(child)
                if node.get("type") in ("paragraph", "heading"):
                    parts.append("\n")
            elif isinstance(node, list):
                for n in node:
                    walk(n)

        walk(adf)
        return "".join(parts).strip()
