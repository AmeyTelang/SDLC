import requests
from typing import Dict, Any, List, Optional
from .config import settings


class XrayClient:
    """Xray CLOUD client.

    Key facts about Xray Cloud (differs from Server/DC):
    - Auth: POST {base}/api/v2/authenticate -> bearer token (string).
    - Test STEPS cannot be set via REST /test/{key}/step (that is Server/DC
      only). On Cloud, steps are set through the GraphQL API:
        POST {base}/api/v2/graphql   mutation updateTestType/addTestStep.
      We use `updateTestSteps`-style calls via addTestStep for each step.
    - Execution results import via POST {base}/api/v2/import/execution.
    """

    def __init__(self):
        self.base = settings.XRAY_BASE_URL.rstrip("/")
        self._token: Optional[str] = None

    # ------------------------------------------------------------------ #
    # Auth                                                               #
    # ------------------------------------------------------------------ #
    def _authenticate(self) -> str:
        if self._token:
            return self._token
        url = f"{self.base}/api/v2/authenticate"
        payload = {
            "client_id": settings.XRAY_CLIENT_ID,
            "client_secret": settings.XRAY_CLIENT_SECRET,
        }
        resp = requests.post(url, json=payload, timeout=30)
        if not resp.ok:
            raise RuntimeError(f"Xray auth failed [{resp.status_code}]: {resp.text}")
        self._token = resp.text.strip('"')
        return self._token

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self._authenticate()}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------ #
    # GraphQL helpers                                                    #
    # ------------------------------------------------------------------ #
    def _graphql(self, query: str, variables: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self.base}/api/v2/graphql"
        resp = requests.post(
            url,
            json={"query": query, "variables": variables},
            headers=self._headers(),
            timeout=30,
        )
        if not resp.ok:
            raise RuntimeError(f"Xray GraphQL HTTP {resp.status_code}: {resp.text}")
        data = resp.json()
        if data.get("errors"):
            raise RuntimeError(f"Xray GraphQL errors: {data['errors']}")
        return data.get("data", {}) or {}

    def _issue_id_for(self, test_key: str) -> str:
        """Xray GraphQL uses the numeric issueId, not the JIRA key."""
        query = """
        query ($jql: String!) {
          getTests(jql: $jql, limit: 1) {
            results { issueId jira(fields: ["key"]) }
          }
        }
        """
        data = self._graphql(query, {"jql": f'key = "{test_key}"'})
        results = (data.get("getTests") or {}).get("results") or []
        if not results:
            raise RuntimeError(
                f"Xray could not find a Test with key {test_key}. "
                f"Ensure the issue type is 'Test' (Xray-enabled) in this project."
            )
        return results[0]["issueId"]

    # ------------------------------------------------------------------ #
    # Steps (Cloud = GraphQL)                                            #
    # ------------------------------------------------------------------ #
    def add_test_steps(self, test_key: str, steps: List[Dict[str, Any]]) -> None:
        """
        Add manual steps to a Cloud Test via GraphQL `addTestStep`.
        """
        if not steps:
            return

        # Get the issueId for the test_key
        issue_id = self._issue_id_for(test_key)

        # Mutation to add a single test step
        mutation = """
        mutation ($issueId: String!, $step: CreateStepInput!) {
        addTestStep(issueId: $issueId, step: $step) {
            id
        }
        }
        """

        # Add each step individually
        for step in steps:
            step_input = {
                "action": str(step.get("action", "") or ""),
                "data": str(step.get("data", "") or ""),
                "result": str(
                    step.get("expected_result", "") or ""
                ),  # Use 'result' instead of 'expectedResult'
            }
            self._graphql(mutation, {"issueId": issue_id, "step": step_input})

    # ------------------------------------------------------------------ #
    # Execution import (Cloud REST works fine)                          #
    # ------------------------------------------------------------------ #
    def import_execution(
        self,
        test_key: str,
        story_key: str,
        steps: List[Dict[str, Any]],
        overall_status: str,
    ) -> str:
        url = f"{self.base}/api/v2/import/execution"
        xray_status = "PASSED" if overall_status == "PASS" else "FAILED"
        payload = {
            "tests": [
                {
                    "testKey": test_key,
                    "status": xray_status,
                    "steps": [
                        {
                            "status": (
                                "PASSED" if s.get("status") == "PASS" else "FAILED"
                            ),
                            "actualResult": s.get("actual_result", ""),
                            "comment": s.get("action", ""),
                        }
                        for s in steps
                    ],
                }
            ]
        }
        resp = requests.post(url, json=payload, headers=self._headers(), timeout=30)
        if not resp.ok:
            raise RuntimeError(
                f"Xray import/execution failed [{resp.status_code}]: {resp.text}"
            )
        data = resp.json()
        # Cloud returns {"key": "<TestExecution key>", ...}
        return data.get("key", "") or (data.get("testExecIssue", {}) or {}).get(
            "key", ""
        )

    def create_test(
        self,
        project_key: str,
        summary: str,
        description: str = "",
        issue_type: str = "Test",
        labels: Optional[List[str]] = None,
        components: Optional[List[str]] = None,
    ) -> str:
        """
        Create a new Xray Test issue in the specified project.

        Args:
            project_key: Jira project key (e.g., "PROJ").
            summary: Test summary/title.
            description: Test description (supports wiki markup).
            issue_type: Issue type (default: "Test").
            labels: List of labels to add to the test.
            components: List of component names to add to the test.

        Returns:
            The Jira key of the created test (e.g., "PROJ-123").

        Raises:
            RuntimeError: If the GraphQL mutation fails or returns errors.
        """
        mutation = """
        mutation ($jira: JSON!) {
        createTest(jira: $jira) {
            test {
            jira(fields: ["key"])
            }
        }
        }
        """
        # Wrap Jira fields inside a 'fields' object
        jira_fields = {
            "fields": {
                "project": {"key": project_key},
                "summary": summary,
                "description": description,
                "issuetype": {"name": issue_type},
            }
        }
        if labels:
            jira_fields["fields"]["labels"] = labels
        if components:
            jira_fields["fields"]["components"] = [
                {"name": comp} for comp in components
            ]

        variables = {"jira": jira_fields}
        data = self._graphql(mutation, variables)
        test = (data.get("createTest") or {}).get("test") or {}
        jira = test.get("jira") or {}
        test_key = jira.get("key")
        if not test_key:
            raise RuntimeError("Xray did not return a test key after creation.")
        return test_key
