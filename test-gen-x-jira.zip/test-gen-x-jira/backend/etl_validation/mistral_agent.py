import json
import re
from typing import Any, Dict, Tuple
from .config import settings
from .token_tracker import record_usage, normalize_usage

try:
    from mistralai import Mistral

    _HAS_MISTRAL = True
except Exception as e:
    print("Mistral import failed:", e)
    _HAS_MISTRAL = False

# Fixed seed so the same spec always yields the same SQL script.
_SEED = 42


class MistralAgent:
    def __init__(self):
        self.model = settings.MISTRAL_MODEL
        self.client = None
        if _HAS_MISTRAL and settings.MISTRAL_API_KEY:
            self.client = Mistral(api_key=settings.MISTRAL_API_KEY)

    def _chat(
        self, system: str, user: str, call_type: str = "chat", story_key: str = ""
    ) -> Tuple[str, Dict[str, Any]]:
        """Run a chat completion and record token usage + cost for the call.

        Returns (content, usage_row) where usage_row is the persisted DB row.
        """
        if not self.client:
            raise RuntimeError("Mistral client not configured. Set MISTRAL_API_KEY.")
        kwargs = dict(
            model=self.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0,  # deterministic
            response_format={"type": "json_object"},
        )
        # random_seed pins the sampling so repeated runs are identical.
        try:
            resp = self.client.chat.complete(random_seed=_SEED, **kwargs)
        except TypeError:
            resp = self.client.chat.complete(**kwargs)

        content = resp.choices[0].message.content
        usage = normalize_usage(getattr(resp, "usage", None))
        usage_row = record_usage(
            call_type=call_type,
            model=self.model,
            usage=usage,
            story_key=story_key,
            success=True,
        )
        return content, usage_row

    @staticmethod
    def _sanitize(text: str) -> str:
        out = []
        in_str = False
        escaped = False
        for ch in text:
            if in_str:
                if escaped:
                    out.append(ch)
                    escaped = False
                    continue
                if ch == "\\":
                    out.append(ch)
                    escaped = True
                    continue
                if ch == '"':
                    in_str = False
                    out.append(ch)
                    continue
                if ch == "\n":
                    out.append("\\n")
                elif ch == "\r":
                    out.append("\\r")
                elif ch == "\t":
                    out.append("\\t")
                elif ord(ch) < 0x20:
                    out.append("\\u%04x" % ord(ch))
                else:
                    out.append(ch)
            else:
                if ch == '"':
                    in_str = True
                out.append(ch)
        return "".join(out)

    @classmethod
    def _extract_json(cls, text: str) -> Any:
        fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
        if fence:
            text = fence.group(1)
        text = text.strip()
        idxs = [i for i in [text.find("{"), text.find("[")] if i != -1]
        if idxs:
            text = text[min(idxs) :]
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return json.loads(cls._sanitize(text))

    def extract_spec(
        self, story_key: str, description: str, summary: str = ""
    ) -> Dict[str, Any]:
        system = (
            "You are an ETL business analyst agent. Extract a structured ETL validation "
            "specification from a JIRA story description. Return ONLY valid JSON."
        )
        user = f"""Story: {story_key}
Summary: {summary}
Description:
{description}

Return JSON with this schema:
{{
  "summary": string,
  "source_table": string,
  "target_table": string,
  "business_rules": [{{"id": string, "description": string}}],
  "lovs": [{{"field": string, "source_value": string, "target_value": string}}]
}}"""
        content, usage_row = self._chat(
            system, user, call_type="extract_spec", story_key=story_key
        )
        data = self._extract_json(content)
        data["story_key"] = story_key
        data["raw_description"] = description
        data["_usage"] = usage_row  # per-call token/cost metadata for the UI
        return data

    def generate_sql_script(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        # Real DB schema (declared types, storage types, distinct stored values).
        # This is the GROUND TRUTH the model must compare against.
        schema_context = spec.get("schema_context") or {}
        story_key = spec.get("story_key", "")

        system = (
            "You are a DETERMINISTIC ETL test generation agent. Given an ETL spec "
            "(source table, target table, business rules, LOV mappings) and a "
            "SCHEMA CONTEXT describing the ACTUAL database, generate a Playwright-style "
            "SQL validation test that verifies the transformed data in the TARGET table "
            "is correct after the rules and LOVs are applied to source data. Return ONLY "
            "valid JSON. Inside JSON string values, escape newlines as \\n; never emit raw "
            "control characters.\n"
            "STRICT RULES (follow exactly, every time):\n"
            "1. DETERMINISM: For the same input you MUST produce byte-for-byte identical "
            "output. Emit exactly one validation statement per business rule, in the SAME "
            "ORDER as the rules appear in the spec. Do not add, drop, reorder, or reword "
            "statements between runs. Use UPPERCASE SQL keywords consistently. Do not "
            "include comments, timestamps, random aliases, or LIMIT clauses.\n"
            "2. GROUND EVERY COMPARISON IN SCHEMA CONTEXT (CRITICAL): The 'schema_context' "
            "gives each column's declared_type, storage_types, and distinct_values as they "
            "ACTUALLY exist in the database. You MUST compare against the ACTUAL stored "
            "representation from schema_context, NOT the representation implied by the "
            "business-rule wording. Example: if a rule says 'set is_active to the inverse "
            "of deprecated_flag' but schema_context shows target column is_active has "
            "storage_types=['integer'] and distinct_values=[0,1], you MUST produce 0/1 "
            "integer comparisons (e.g. t.is_active = CASE WHEN s.deprecated_flag='Y' THEN 0 "
            "ELSE 1 END) — do NOT compare is_active against 'Y'/'N'. Every literal you "
            "write must be a value that appears in that column's distinct_values.\n"
            "3. DATATYPE-AWARE COMPARISONS: Match each column's storage type. Use "
            "CAST(col AS INTEGER/REAL) for numeric columns, TRIM(col) for text, and never "
            "rely on implicit type coercion. If a source coded column and a target coded "
            "column use different encodings (e.g. source 'Y'/'N' vs target 0/1), translate "
            "explicitly using the values from schema_context.\n"
            "4. USE ONLY LITERAL VALUES FROM THE SPEC LOVs AND SCHEMA CONTEXT: never invent "
            "'Y'/'N', 'true'/'false', etc. unless those exact values appear in the spec's "
            "lovs or in the column's distinct_values.\n"
            "5. Each SQL statement must return ZERO rows when the transformation is CORRECT "
            "and NON-ZERO rows when the data is INVALID (select the violating rows).\n"
            "6. Every test_step.data must be an exact, runnable SQL statement that also "
            "appears verbatim in sql_script."
        )
        user = f"""ETL Spec:
{json.dumps({k: v for k, v in spec.items() if k != "schema_context"}, indent=2, sort_keys=True)}

SCHEMA CONTEXT (actual database — declared_type, storage_types, distinct_values):
{json.dumps(schema_context, indent=2, sort_keys=True, default=str)}

Produce JSON:
{{
  "target_table": string,
  "sql_script": "One or more SQL SELECT statements separated by semicolons. Exactly one statement per business rule, in spec order, each datatype-aware and grounded in schema_context distinct_values, returning 0 rows when valid.",
  "test_steps": [
    {{"index": number, "action": "the business rule id/description being validated", "data": "the exact SQL statement", "expected_result": "0 rows returned"}}
  ]
}}
Generate exactly one test_step per business rule, in the same order as the spec. Every compared literal MUST come from schema_context.distinct_values or the spec lovs. Ensure each test_step.data is present verbatim in sql_script."""
        content, usage_row = self._chat(
            system, user, call_type="generate_sql_script", story_key=story_key
        )
        data = self._extract_json(content)
        data["story_key"] = story_key
        data["_usage"] = usage_row  # per-call token/cost metadata for the UI
        return data
