import sqlite3
import re
from typing import Dict, Any, List
from .config import settings


class SqlExecutor:
    """Execution agent: runs the generated SQL validation statements against the
    target database. Each validation statement is expected to return zero rows
    when the transformation is correct."""

    def __init__(self):
        self.db_path = self._resolve_sqlite_path(settings.TARGET_DB_URL)

    @staticmethod
    def _resolve_sqlite_path(url: str) -> str:
        if url.startswith("sqlite:///"):
            return url.replace("sqlite:///", "", 1)
        return url

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def execute(self, script: Dict[str, Any]) -> Dict[str, Any]:
        steps = script.get("test_steps", [])
        step_results: List[Dict[str, Any]] = []
        passed = 0
        failed = 0
        log_lines: List[str] = []

        conn = None
        try:
            conn = self._connect()
            cur = conn.cursor()
            for step in steps:
                sql = (step.get("data") or "").strip().rstrip(";")
                action = step.get("action", "")
                expected = step.get("expected_result", "0 rows returned")
                if not sql:
                    continue
                try:
                    cur.execute(sql)
                    rows = cur.fetchall()
                    count = len(rows)
                    status = "PASS" if count == 0 else "FAIL"
                    actual = f"{count} rows returned"
                    if count > 0:
                        actual += f"; sample={rows[:3]}"
                    if status == "PASS":
                        passed += 1
                    else:
                        failed += 1
                    step_results.append(
                        {
                            "index": step.get("index", 0),
                            "action": action,
                            "expected_result": expected,
                            "actual_result": actual,
                            "status": status,
                        }
                    )
                    log_lines.append(f"[{status}] {action} -> {actual}")
                except Exception as e:
                    failed += 1
                    step_results.append(
                        {
                            "index": step.get("index", 0),
                            "action": action,
                            "expected_result": expected,
                            "actual_result": f"ERROR: {e}",
                            "status": "ERROR",
                        }
                    )
                    log_lines.append(f"[ERROR] {action} -> {e}")
        finally:
            if conn:
                conn.close()

        overall = "PASS" if failed == 0 and passed > 0 else "FAIL"
        return {
            "story_key": script.get("story_key", ""),
            "target_table": script.get("target_table", ""),
            "overall_status": overall,
            "passed": passed,
            "failed": failed,
            "step_results": step_results,
            "log": "\n".join(log_lines),
        }
