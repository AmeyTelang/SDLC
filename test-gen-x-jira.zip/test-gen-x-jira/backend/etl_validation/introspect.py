import sqlite3
from typing import Any, Dict, List
from .config import settings


def _db_path(url: str) -> str:
    # sqlite:////abs -> /abs ; sqlite:///rel -> rel
    if url.startswith("sqlite:////"):
        return "/" + url[len("sqlite:////") :]
    if url.startswith("sqlite:///"):
        return url[len("sqlite:///") :]
    return url


def _table_context(cur, table: str, sample_limit: int = 15) -> Dict[str, Any]:
    cols: List[Dict[str, Any]] = []
    try:
        cur.execute(f"PRAGMA table_info({table})")
        info = cur.fetchall()
    except Exception:
        return {"table": table, "columns": []}

    for row in info:
        name = row[1]
        decl_type = row[2] or ""
        col: Dict[str, Any] = {"name": name, "declared_type": decl_type}
        # runtime storage type + distinct stored values (the ground truth)
        try:
            cur.execute(
                f"SELECT DISTINCT typeof({name}) FROM {table} "
                f"WHERE {name} IS NOT NULL LIMIT 5"
            )
            col["storage_types"] = [r[0] for r in cur.fetchall()]
        except Exception:
            col["storage_types"] = []
        try:
            cur.execute(
                f"SELECT DISTINCT {name} FROM {table} "
                f"WHERE {name} IS NOT NULL LIMIT {sample_limit}"
            )
            col["distinct_values"] = [r[0] for r in cur.fetchall()]
        except Exception:
            col["distinct_values"] = []
        cols.append(col)
    return {"table": table, "columns": cols}


def build_schema_context(spec: Dict[str, Any]) -> Dict[str, Any]:
    """Introspect the ACTUAL source/target tables so the generator uses the
    real datatypes and stored literals (e.g. is_active = 0/1, not 'Y'/'N')."""
    tables = [t for t in [spec.get("source_table"), spec.get("target_table")] if t]
    ctx: Dict[str, Any] = {}
    conn = None
    try:
        conn = sqlite3.connect(_db_path(settings.TARGET_DB_URL))
        cur = conn.cursor()
        for t in tables:
            ctx[t] = _table_context(cur, t)
    except Exception as e:
        ctx["_error"] = str(e)
    finally:
        if conn:
            conn.close()
    return ctx
