import { useEffect, useState } from "react";

import Header from "./components/Header.jsx";
import EngineerWorkspace from "./EngineerWorkspace.jsx";
import LeadWorkspace from "./LeadWorkspace.jsx";
import HistoryView from "./components/HistoryView.jsx";
import AuditTrailView from "./AuditTrailView.jsx";
import TokenUsagePage from "./components/TokenUsage/TokenUsagePage.jsx";
import TestCaseStudio from "./components/testcase_studio/TestCaseStudio.jsx";
import ETLValidationTab from "./components/etl_validator/ETLValidationTab.jsx";
import { listProjects } from "./services/api.js";
import { useAuth } from "./context/AuthContext.jsx";

/**
 * Authenticated shell.
 *
 * Routing here is by ROLE, not by URL: the server tells us which views the
 * signed-in user may open (`allowed_views`) and where they land
 * (`default_view`). Rendering an unpermitted view is prevented here as a
 * courtesy; the API refuses it regardless.
 *
 * The ETL tab is kept mounted but hidden so its in-flight streaming state
 * survives a tab switch - the other views are cheap to remount.
 */
export default function Workspace() {
  const { user, canView, defaultView } = useAuth();

  const [view, setView] = useState(defaultView);
  const [projects, setProjects] = useState([]);
  const [etlRuns, setEtlRuns] = useState([]);
  const [usageRefresh, setUsageRefresh] = useState(0);

  useEffect(() => {
    listProjects()
      .then(setProjects)
      .catch(() => setProjects([]));
  }, []);

  // If the role changes (or a stale view is restored), fall back to a view
  // this user is actually allowed to open.
  useEffect(() => {
    if (!canView(view)) setView(defaultView);
  }, [view, canView, defaultView]);

  const handleEtlHistoryAdd = (run) => {
    setEtlRuns((prev) => [
      run,
      ...prev.filter((r) => r.test_id !== run.test_id),
    ]);
    setUsageRefresh((n) => n + 1);
  };

  const focusApproval = () => {
    setView(user?.role === "test_lead" ? "review" : "authoring");
    setTimeout(
      () =>
        document
          .getElementById("tcs-queue")
          ?.scrollIntoView({ behavior: "smooth", block: "center" }) ??
        document
          .getElementById("approval-queue")
          ?.scrollIntoView({ behavior: "smooth", block: "center" }),
      80,
    );
  };

  return (
    <div className="app-shell">
      <Header view={view} setView={setView} onOpenApproval={focusApproval} />

      {/* Kept mounted: the ETL workflow streams and must survive tab changes. */}
      <div style={{ display: view === "etl" ? "block" : "none" }}>
        <ETLValidationTab onHistoryAdd={handleEtlHistoryAdd} />
      </div>

      {view === "authoring" && <TestCaseStudio />}
      {view === "studio" && <EngineerWorkspace />}
      {view === "review" && <LeadWorkspace />}
      {view === "usage" && <TokenUsagePage refreshKey={usageRefresh} />}
      {view === "audit" && <AuditTrailView />}

      {view === "history" && (
        <div className="container">
          <HistoryView projects={projects} etlRuns={etlRuns} />
        </div>
      )}
    </div>
  );
}
