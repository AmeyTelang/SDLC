import { Navigate, Route, Routes } from "react-router-dom";

import Workspace from "./Workspace.jsx";
import TestGenXLogin from "./components/Login.jsx";
import { AuthProvider, useAuth } from "./context/AuthContext.jsx";
import { NotificationsProvider } from "./context/NotificationsContext.jsx";

function ProtectedRoute({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/" replace />;
}

function LoginRoute() {
  const { user } = useAuth();
  return user ? <Navigate to="/workspace" replace /> : <TestGenXLogin />;
}

export default function App() {
  return (
    <AuthProvider>
      <NotificationsProvider>
        <Routes>
          <Route path="/" element={<LoginRoute />} />
          <Route
            path="/workspace"
            element={
              <ProtectedRoute>
                <Workspace />
              </ProtectedRoute>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </NotificationsProvider>
    </AuthProvider>
  );
}
