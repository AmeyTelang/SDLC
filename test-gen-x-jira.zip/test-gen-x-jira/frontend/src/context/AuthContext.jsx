import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

/**
 * Authentication + role context for TestGenX.
 *
 * The server is the only authority on role and capability: `/api/auth/login`
 * resolves an email to a user and returns the capability set, and every
 * guarded endpoint re-reads the role server-side from the `X-User-Email`
 * header. Nothing here grants access - this context only decides what the UI
 * bothers to render, so a tampered session yields a 403, not an escalation.
 */

export const TEST_ENGINEER = "test_engineer";
export const TEST_LEAD = "test_lead";

const STORAGE_KEY = "testgenx.session";
const BASE = import.meta?.env?.VITE_API_BASE || "/api";

const AuthContext = createContext(null);

/* ------------------------------------------------------------------
   Module-level session accessor.

   `authHeaders()` is deliberately NOT a hook: the API service modules
   (approvalApi, auditApi, testcaseApi) are plain functions called from
   event handlers, and they need the identity header without being
   inside a React render.
------------------------------------------------------------------- */
let activeSession = null;

function readStoredSession() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && parsed.email ? parsed : null;
  } catch {
    return null;
  }
}

function writeStoredSession(user) {
  try {
    if (user) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    else window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* storage unavailable (private mode) - session stays in memory */
  }
}

activeSession = readStoredSession();

/** Identity headers for every guarded API call. */
export function authHeaders(extra = {}) {
  if (!activeSession?.email) return { ...extra };
  return {
    "X-User-Email": activeSession.email,
    "X-User-Role": activeSession.role || "",
    ...extra,
  };
}

export function currentSession() {
  return activeSession;
}

/* ------------------------------------------------------------------ */
async function postJSON(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const payload = await res.json();
      if (payload?.detail) detail = payload.detail;
    } catch {
      /* not JSON */
    }
    throw new Error(detail);
  }
  return res.json();
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => activeSession);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Revalidate a restored session on boot. If the directory no longer
  // recognises the address, the stale session is cleared rather than left
  // to fail on the first guarded call.
  useEffect(() => {
    if (!activeSession?.email) return;
    let cancelled = false;

    fetch(`${BASE}/auth/me`, { headers: authHeaders() })
      .then((res) => (res.ok ? res.json() : Promise.reject(res)))
      .then((fresh) => {
        if (cancelled || !fresh?.email) return;
        activeSession = fresh;
        writeStoredSession(fresh);
        setUser(fresh);
      })
      .catch(() => {
        if (cancelled) return;
        activeSession = null;
        writeStoredSession(null);
        setUser(null);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (email) => {
    setLoading(true);
    setError(null);
    try {
      const resolved = await postJSON("/auth/login", { email });
      activeSession = resolved;
      writeStoredSession(resolved);
      setUser(resolved);
      return resolved;
    } catch (e) {
      setError(e.message || "Sign-in failed.");
      throw e;
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await postJSON("/auth/logout", {});
    } catch {
      /* the audit entry is best-effort; the local session always clears */
    }
    activeSession = null;
    writeStoredSession(null);
    setUser(null);
  }, []);

  const can = useCallback(
    (capability) =>
      !capability || Boolean(user?.capabilities?.includes(capability)),
    [user],
  );

  const canView = useCallback(
    (view) => Boolean(user?.allowed_views?.includes(view)),
    [user],
  );

  const value = useMemo(
    () => ({
      user,
      loading,
      error,
      login,
      logout,
      can,
      canView,
      isLead: user?.role === TEST_LEAD,
      isEngineer: user?.role === TEST_ENGINEER,
      defaultView: user?.default_view || "history",
    }),
    [user, loading, error, login, logout, can, canView],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used inside an <AuthProvider>.");
  }
  return ctx;
}
