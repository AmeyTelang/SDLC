import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";

const NotificationsContext = createContext(null);

let _seq = 0;

export function NotificationsProvider({ children }) {
  const [items, setItems] = useState([]);

  const push = useCallback((n) => {
    const item = {
      id: `n${++_seq}`,
      kind: n.kind || "info",
      title: n.title || "Notification",
      body: n.body || "",
      testId: n.testId || n.test_id || null,
      at: new Date(),
      read: false,
    };
    setItems((prev) => [item, ...prev].slice(0, 30));
    return item.id;
  }, []);

  const markAllRead = useCallback(
    () => setItems((prev) => prev.map((i) => ({ ...i, read: true }))),
    [],
  );

  const markRead = useCallback(
    (id) =>
      setItems((prev) =>
        prev.map((i) => (i.id === id ? { ...i, read: true } : i)),
      ),
    [],
  );

  const clear = useCallback(() => setItems([]), []);

  const unread = items.filter((i) => !i.read).length;

  const value = useMemo(
    () => ({ items, unread, push, markAllRead, markRead, clear }),
    [items, unread, push, markAllRead, markRead, clear],
  );

  return (
    <NotificationsContext.Provider value={value}>
      {children}
    </NotificationsContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationsContext);
  if (!ctx)
    return {
      items: [],
      unread: 0,
      push: () => {},
      markAllRead: () => {},
      markRead: () => {},
      clear: () => {},
    };
  return ctx;
}
