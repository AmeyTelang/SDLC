import { useCallback, useEffect, useState } from "react";
import { ShieldCheck, Network, Inbox } from "lucide-react";
import AgentWorkflowStream from "./components/AgentWorkflowStream.jsx";
import ScriptViewer from "./components/ScriptViewer.jsx";
import ResultCard from "./components/ResultCard.jsx";
import ApprovalGate from "./components/ApprovalGate.jsx";
import ApprovalQueuePanel from "./components/ApprovalQueuePanel.jsx";
import { ExecutionSkeleton } from "./components/SkeletonPanels.jsx";
import { listProjects } from "./services/api.js";
import {
  runExecutionStream,
  approveScript,
  sendBackForRework,
  listApprovalQueue,
  fetchQueueItem,
} from "./services/approvalApi.js";
import { useNotifications } from "./context/NotificationsContext.jsx";

const IDLE = "idle";
const POLL_MS = 20000;

/**
 * TEST LEAD workspace.
 *
 * The queue now contains only scripts the engineer has explicitly SUBMITTED.
 * Two outcomes: approve (releases Agent Y) or send back for regeneration
 * with feedback.
 */
export default function LeadWorkspace() {
  const [projects, setProjects] = useState([]);
  const [queue, setQueue] = useState([]);
  const [queueLoading, setQueueLoading] = useState(false);

  const [mode, setMode] = useState(IDLE);
  const [events, setEvents] = useState([]);
  const [progress, setProgress] = useState(0);
  const [gen, setGen] = useState(null);
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState(null);
  const [banner, setBanner] = useState(null);

  const [gate, setGate] = useState(null);
  const [busy, setBusy] = useState(false);
  const { push: pushNotification } = useNotifications();

  const refreshQueue = useCallback(async () => {
    setQueueLoading(true);
    try {
      setQueue(await listApprovalQueue());
    } catch {
      /* keep last known */
    } finally {
      setQueueLoading(false);
    }
  }, []);

  useEffect(() => {
    listProjects()
      .then(setProjects)
      .catch(() => setProjects([]));
    refreshQueue();
    const t = setInterval(refreshQueue, POLL_MS);
    return () => clearInterval(t);
  }, [refreshQueue]);

  // Notify on newly SUBMITTED scripts (drafts never reach here).
  const [seen, setSeen] = useState(() => new Set());
  useEffect(() => {
    const fresh = queue.filter(
      (q) => q.status === "pending" && !seen.has(q.test_id),
    );
    if (fresh.length === 0) return;
    fresh.forEach((q) =>
      pushNotification({
        kind: "approval_required",
        title:
          (q.iteration || 1) > 1
            ? "Revised script submitted for approval"
            : "Test script submitted for approval",
        body: `“${q.title}” · ${q.step_count} steps · iteration ${q.iteration} · from ${
          q.requested_by || "a Test Engineer"
        }`,
        testId: q.test_id,
      }),
    );
    setSeen((prev) => {
      const next = new Set(prev);
      fresh.forEach((q) => next.add(q.test_id));
      return next;
    });
  }, [queue, seen, pushNotification]);

  const collect = (ev) => {
    setEvents((prev) => [...prev, ev]);
    if (typeof ev.progress === "number") setProgress(ev.progress);
  };

  const resetWorkspace = useCallback(() => {
    setMode(IDLE);
    setEvents([]);
    setProgress(0);
    setGen(null);
    setResult(null);
    setGate(null);
    setError(null);
  }, []);

  // ---- pull a submitted script in for review -------------------------
  const onPull = async (testId) => {
    setBanner(null);
    setError(null);
    try {
      const item = await fetchQueueItem(testId);
      setEvents([
        {
          agent: "approval",
          phase: "review",
          message: `Approval Queue: “${item.title}” (iteration ${item.iteration}) pulled in for review.`,
          progress: 60,
        },
      ]);
      setProgress(60);
      setResult(null);
      setGen(item.artifact || null);
      setGate(item);
      setMode("review");
      setTimeout(
        () =>
          document
            .getElementById("approval-gate")
            ?.scrollIntoView({ behavior: "smooth", block: "center" }),
        80,
      );
    } catch (e) {
      setError(e.message || "Could not load this queued test.");
      refreshQueue();
    }
  };

  // ---- approve -> Execution Agent ------------------------------------
  const onApprove = async (testId, comment) => {
    setBusy(true);
    setError(null);
    const title = gate?.title;
    try {
      await approveScript(testId, comment);
      setGate(null);
      setMode("execute");
      setRunning(true);

      await runExecutionStream(testId, (ev) => {
        collect(ev);
        if (ev.agent === "execution" && ev.phase === "artifact" && ev.data)
          setResult({ ...ev.data, title });
      });

      setQueue((prev) => prev.filter((i) => i.test_id !== testId));
      refreshQueue();
    } catch (e) {
      setError(e.message || "Execution failed");
    } finally {
      setBusy(false);
      setRunning(false);
    }
  };

  // ---- send back for regeneration ------------------------------------
  const onSendBack = async (testId, feedback) => {
    setBusy(true);
    setError(null);
    const title = gate?.title;
    try {
      await sendBackForRework(testId, feedback);
      setQueue((prev) => prev.filter((i) => i.test_id !== testId));
      setSeen((prev) => {
        const next = new Set(prev);
        next.delete(testId); // re-notify when it comes back revised
        return next;
      });
      resetWorkspace();
      setBanner(
        `“${title}” sent back to the Test Engineer for regeneration. It will return here once resubmitted.`,
      );
      refreshQueue();
    } catch (e) {
      setError(e.message || "Could not send this script back.");
    } finally {
      setBusy(false);
    }
  };

  const project =
    projects.find((p) => p.name === gate?.project_name) || projects[0] || null;
  const started = events.length > 0 || running;
  const pending = queue.filter((i) => i.status === "pending").length;

  return (
    <div className="container">
      <div className="grid-3">
        {/* LEFT — submitted scripts awaiting review */}
        <aside className="col-left">
          <div id="approval-queue">
            <ApprovalQueuePanel
              items={queue}
              activeTestId={gate?.test_id || null}
              loading={queueLoading}
              onPull={onPull}
              onRefresh={refreshQueue}
              showAuthor
            />
          </div>
        </aside>

        {/* MIDDLE — review + execution */}
        <main className="col-mid">
          {error && (
            <div className="card">
              <div className="card-body" style={{ color: "var(--fail)" }}>
                {error}
              </div>
            </div>
          )}

          {banner && (
            <div className="ws-banner rejected">
              <Inbox size={15} />
              <span>{banner}</span>
              <button onClick={() => setBanner(null)} aria-label="Dismiss">
                ×
              </button>
            </div>
          )}

          {mode === IDLE && !started && (
            <div className="card">
              <div className="empty">
                <div className="ico">
                  <ShieldCheck size={28} />
                </div>
                <h3>Review & Approve</h3>
                <p>
                  {pending > 0 ? (
                    <>
                      <b>{pending}</b> script
                      {pending === 1 ? "" : "s"} submitted by your Test
                      Engineers
                      {pending === 1 ? " is" : " are"} waiting for review. Pull
                      one in to inspect it, then <b>approve</b> to release Agent
                      Y or <b>send it back</b> with feedback.
                    </>
                  ) : (
                    <>
                      Nothing is waiting for review. Scripts appear here only
                      once a Test Engineer has reviewed their draft and{" "}
                      <b>submitted it for approval</b>.
                    </>
                  )}
                </p>
              </div>
            </div>
          )}

          {gen && <ScriptViewer gen={gen} />}

          {mode === "review" && gate && (
            <ApprovalGate
              gate={gate}
              onApprove={onApprove}
              onSendBack={onSendBack}
              onClose={resetWorkspace}
              busy={busy}
            />
          )}

          {result ? (
            <ResultCard result={result} project={project} />
          ) : (
            mode === "execute" && running && <ExecutionSkeleton />
          )}
        </main>

        {/* RIGHT — workflow stream */}
        <aside className="col-right">
          {started ? (
            <AgentWorkflowStream
              events={events}
              progress={progress}
              running={running}
              awaitingApproval={mode === "review"}
            />
          ) : (
            <div className="card">
              <div className="card-head">
                <span className="icon">
                  <Network size={18} />
                </span>
                <h2>Agent Workflow Stream</h2>
                <span className="spacer" />
              </div>
              <div className="card-body">
                <div className="wf-idle">
                  Pull a submitted script from the queue to begin a review.
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
