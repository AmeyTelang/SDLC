// API service layer for the TestGenX POC frontend.
const BASE = import.meta.env.VITE_API_BASE || "";

async function jget(path) {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`GET ${path} failed (${r.status})`);
  return r.json();
}

export const getHealth = () => jget("/api/health");

export const listProjects = () => jget("/api/projects");
export async function createProject(body) {
  const r = await fetch(`${BASE}/api/projects`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("Create project failed");
  return r.json();
}

export const listRuns = (projectId) =>
  jget(`/api/runs${projectId ? `?project_id=${projectId}` : ""}`);
export const getRun = (testId) => jget(`/api/runs/${testId}`);

export async function runWorkflowStream(payload, onEvent, signal) {
  const r = await fetch(`${BASE}/api/run/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal,
  });
  if (!r.ok || !r.body) throw new Error("Failed to start workflow stream");
  const reader = r.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf("\n\n")) !== -1) {
      const chunk = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 2);
      if (chunk.startsWith("data:")) {
        try {
          onEvent(JSON.parse(chunk.slice(5).trim()));
        } catch (e) {
          /* keep-alive */
        }
      }
    }
  }
}

export const reportUrl = (testId, fmt) =>
  `${BASE}/api/report/${testId}?format=${fmt}`;
export const evidenceImg = (url) => `${BASE}${url}`;

const downloads = {
  report: (id, fmt) => reportUrl(id, fmt),
  runBundle: (id) => `${BASE}/api/runs/${id}/bundle.zip`,
  runEvidence: (id) => `${BASE}/api/runs/${id}/evidence.zip`,
  projectScripts: (pid) => `${BASE}/api/projects/${pid}/scripts.zip`,
  projectEvidence: (pid) => `${BASE}/api/projects/${pid}/evidence.zip`,
  projectResults: (pid) => `${BASE}/api/projects/${pid}/results.zip`,
  projectReports: (pid, fmt = "pdf") =>
    `${BASE}/api/projects/${pid}/reports.zip?format=${fmt}`,
};
export { downloads };

export async function download(url, filename) {
  const r = await fetch(url);
  if (!r.ok) throw new Error(`Download failed (${r.status})`);
  const blob = await r.blob();
  const objUrl = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = objUrl;
  if (filename) a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(objUrl);
}
