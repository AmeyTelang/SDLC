// Story -> Xray test case authoring API.
import { authHeaders } from "../context/AuthContext.jsx";

const BASE = import.meta?.env?.VITE_API_BASE || "/api";

function headers(extra = {}) {
  return { ...authHeaders(), ...extra };
}

async function errorFrom(res, fallback) {
  if (res.status === 401) return "Your session has expired. Sign in again.";
  if (res.status === 403)
    return "Your role is not permitted to perform this action.";
  if (res.status === 404)
    return "Test case service unavailable (routes not mounted on the server).";
  try {
    const body = await res.json();
    if (body?.detail) {
      return typeof body.detail === "string"
        ? body.detail
        : JSON.stringify(body.detail);
    }
  } catch {
    /* not JSON */
  }
  return fallback;
}

async function request(path, { method = "GET", body, fallback } = {}) {
  const init = { method, headers: headers() };
  if (body !== undefined) {
    init.headers = headers({ "Content-Type": "application/json" });
    init.body = JSON.stringify(body);
  }
  const res = await fetch(`${BASE}${path}`, init);
  if (!res.ok)
    throw new Error(await errorFrom(res, fallback || "Request failed."));
  if (res.status === 204) return null;
  return res.json();
}

async function safeRequest(path, fallbackValue) {
  try {
    return await request(path);
  } catch {
    return fallbackValue;
  }
}

const id = (value) => encodeURIComponent(value);

/* ================= shared ================= */

export function testcaseHealth() {
  return safeRequest("/testcase/health", { configured: false });
}

/* ================= import + generate ================= */

/** Pull the story and parse its BDD acceptance criteria. */
export function importStory({ storyKey, projectKey = "" }) {
  return request("/testcase/import", {
    method: "POST",
    body: { story_key: storyKey, project_key: projectKey },
    fallback: "Could not import this story from JIRA.",
  });
}

/** Synthesise (or regenerate) the Xray test case from the criteria. */
export function generateTestCase({
  storyKey,
  projectKey = "",
  summary = "",
  acceptanceCriteria = "",
  rawDescription = "",
  autUrl = "",
  scenarioNames = [],
  draftId = null,
  feedback = "",
}) {
  return request("/testcase/generate", {
    method: "POST",
    body: {
      story_key: storyKey,
      project_key: projectKey,
      summary,
      acceptance_criteria: acceptanceCriteria,
      raw_description: rawDescription,
      aut_url: autUrl,
      scenario_names: scenarioNames,
      draft_id: draftId,
      feedback,
    },
    fallback: "Test case generation failed.",
  });
}

/* ================= engineer ================= */

export function listMyTestCases() {
  return safeRequest("/testcase/mine", []);
}

export function fetchDraft(draftId) {
  return request(`/testcase/drafts/${id(draftId)}`, {
    fallback: "Could not load this test case.",
  });
}

/** Persist manual edits to the generated content. */
export function saveDraft(draftId, patch) {
  return request(`/testcase/drafts/${id(draftId)}`, {
    method: "PUT",
    body: patch,
    fallback: "Could not save your changes.",
  });
}

export function submitTestCase(draftId, note = "") {
  return request(`/testcase/drafts/${id(draftId)}/submit`, {
    method: "POST",
    body: { note },
    fallback: "Could not submit this test case.",
  });
}

export function withdrawTestCase(draftId) {
  return request(`/testcase/drafts/${id(draftId)}/withdraw`, {
    method: "POST",
    body: {},
    fallback: "Could not withdraw this submission.",
  });
}

export function discardTestCase(draftId) {
  return request(`/testcase/drafts/${id(draftId)}`, {
    method: "DELETE",
    fallback: "Could not discard this draft.",
  });
}

/* ================= lead ================= */

export function listTestCaseQueue(projectKey) {
  const qs = projectKey ? `?project_key=${id(projectKey)}` : "";
  return safeRequest(`/testcase/queue${qs}`, []);
}

export function fetchQueueItem(draftId) {
  return request(`/testcase/queue/${id(draftId)}`, {
    fallback: "This test case is no longer in the review queue.",
  });
}

export function approveTestCase(draftId, comment = "") {
  return request(`/testcase/queue/${id(draftId)}/approve`, {
    method: "POST",
    body: { comment },
    fallback: "Could not approve this test case.",
  });
}

export function sendBackTestCase(draftId, feedback) {
  return request(`/testcase/queue/${id(draftId)}/send-back`, {
    method: "POST",
    body: { feedback },
    fallback: "Could not send this test case back.",
  });
}

export function rejectTestCase(draftId, comment = "") {
  return request(`/testcase/queue/${id(draftId)}/reject`, {
    method: "POST",
    body: { comment },
    fallback: "Could not reject this test case.",
  });
}

/** Create the approved Xray test under the story in JIRA. */
export function publishTestCase(
  draftId,
  { projectKey = "", linkType = "Tests" } = {},
) {
  return request(`/testcase/queue/${id(draftId)}/publish`, {
    method: "POST",
    body: { project_key: projectKey, link_type: linkType },
    fallback: "Could not create the test in JIRA.",
  });
}

export function testCasesForStory(storyKey) {
  return safeRequest(`/testcase/story/${id(storyKey)}`, []);
}
