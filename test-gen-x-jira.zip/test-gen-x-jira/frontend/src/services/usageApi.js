// usageApi.js — client for the shared Token Usage endpoints.
// Honors VITE_API_BASE if your app proxies the backend under a prefix.

const BASE = (import.meta?.env?.VITE_API_BASE || "").replace(/\/$/, "");

function qs(params) {
  const p = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") p.append(k, v);
  });
  const s = p.toString();
  return s ? `?${s}` : "";
}

async function getJson(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

export function getUsageSummary({ module, storyKey } = {}) {
  return getJson(`/api/usage/summary${qs({ module, story_key: storyKey })}`);
}

export function getUsageList({ module, storyKey, limit = 200 } = {}) {
  return getJson(`/api/usage${qs({ module, story_key: storyKey, limit })}`);
}

export function getUsageModules() {
  return getJson(`/api/usage/modules`);
}
