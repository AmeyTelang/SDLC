// HITL review API — engineer self-review, submit, and Lead send-back.

import { authHeaders } from "../context/AuthContext.jsx";

const BASE = import.meta?.env?.VITE_API_BASE || "/api";

function headers(extra = {}) {
  return { ...authHeaders(), ...extra };
}

async function errorFrom(res, fallback) {
  if (res.status === 404)
    return "Workflow service unavailable (routes not mounted on the server).";
  if (res.status === 403)
    return "Your role is not permitted to perform this action.";
  try {
    const body = await res.json();
    if (body?.detail) return body.detail;
  } catch {
    /* not JSON */
  }
  return fallback;
}

async function readSSE(response, onEvent) {
  if (!response.ok || !response.body)
    throw new Error(
      await errorFrom(response, `Request failed (${response.status})`),
    );

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let idx;
    while ((idx = buffer.indexOf("\n\n")) !== -1) {
      const raw = buffer.slice(0, idx).trim();
      buffer = buffer.slice(idx + 2);
      if (!raw.startsWith("data:")) continue;
      const payload = raw.slice(5).trim();
      if (!payload) continue;
      try {
        onEvent(JSON.parse(payload));
      } catch {
        /* ignore malformed frame */
      }
    }
  }
}

async function postJSON(path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: headers({ "Content-Type": "application/json" }),
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) throw new Error(await errorFrom(res, "Request failed."));
  return res.json();
}

/* ================= TEST ENGINEER ================= */

/** Generate. The stream now ends on an `approval/draft` event. */
export async function runGenerationStream(body, onEvent) {
  const res = await fetch(`${BASE}/workflow/generate`, {
    method: "POST",
    headers: headers({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });
  return readSSE(res, onEvent);
}

/** Drafts, submitted and returned scripts belonging to me. */
export async function listMyScripts() {
  const res = await fetch(`${BASE}/workflow/my-scripts`, {
    headers: headers(),
  });
  if (!res.ok) return [];
  return res.json();
}

/** Re-open one of my scripts (draft or returned) in the workspace. */
export async function fetchMyScript(testId) {
  const res = await fetch(
    `${BASE}/workflow/draft/${encodeURIComponent(testId)}`,
    {
      headers: headers(),
    },
  );
  if (!res.ok)
    throw new Error(await errorFrom(res, "Could not load this script."));
  return res.json();
}

/** Engineer has reviewed the draft — send it to the Test Lead. */
export function submitForReview(testId, note = "") {
  return postJSON(`/workflow/submit/${encodeURIComponent(testId)}`, { note });
}

/** Pull a submission back before the Lead decides. */
export function withdrawSubmission(testId) {
  return postJSON(`/workflow/withdraw/${encodeURIComponent(testId)}`, {});
}

export async function discardDraft(testId) {
  const res = await fetch(
    `${BASE}/workflow/draft/${encodeURIComponent(testId)}`,
    {
      method: "DELETE",
      headers: headers(),
    },
  );
  if (!res.ok)
    throw new Error(await errorFrom(res, "Could not discard this draft."));
  return res.json();
}

/* ================= TEST LEAD ================= */

export async function listApprovalQueue(projectId) {
  const qs = projectId ? `?project_id=${encodeURIComponent(projectId)}` : "";
  const res = await fetch(`${BASE}/workflow/queue${qs}`, {
    headers: headers(),
  });
  if (!res.ok) return [];
  return res.json();
}

export async function fetchQueueItem(testId) {
  const res = await fetch(
    `${BASE}/workflow/queue/${encodeURIComponent(testId)}`,
    {
      headers: headers(),
    },
  );
  if (!res.ok)
    throw new Error(
      await errorFrom(res, "This script is no longer in the queue."),
    );
  return res.json();
}

export function approveScript(testId, comment = "") {
  return postJSON(`/workflow/approve/${encodeURIComponent(testId)}`, {
    comment,
  });
}

/** Return to the engineer for regeneration. Feedback is mandatory. */
export function sendBackForRework(testId, feedback) {
  return postJSON(`/workflow/send-back/${encodeURIComponent(testId)}`, {
    feedback,
  });
}

export function rejectScript(testId, comment = "") {
  return postJSON(`/workflow/reject/${encodeURIComponent(testId)}`, {
    comment,
  });
}

export async function runExecutionStream(testId, onEvent) {
  const res = await fetch(
    `${BASE}/workflow/execute/${encodeURIComponent(testId)}`,
    {
      method: "GET",
      headers: headers({ Accept: "text/event-stream" }),
    },
  );
  return readSSE(res, onEvent);
}
