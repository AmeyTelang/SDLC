const DEFAULTS = [
  {
    // SauceDemo Web
    match: (p) =>
      /saucedemo/i.test(p.aut_url || "") || /sauce\s*demo/i.test(p.name || ""),
    title: "Login and add to cart",
    steps: [
      "Open the application",
      "Login with username standard_user and password secret_sauce",
      'Verify that "Products" is visible',
      'Verify that "Sauce Labs Backpack" is visible',
      'Click on "Add to cart"',
      'Verify that "Remove" is visible',
      'Verify that "Sauce Labs Bike Light" is visible',
      'Click on "Add to cart"',
      'Click on "2"',
      'Verify that "Your Cart" is visible',
      'Verify that "Sauce Labs Backpack" is visible',
      'Click on "Checkout"',
      'Enter "John" into "First Name"',
      'Enter "Doe" into "Last Name"',
      'Enter "12345" into "Zip/Postal Code"',
      'Click on "Continue"',
      'Verify that "Checkout: Overview" is visible',
      'Verify that "Payment Information" is visible',
      'Click on "Finish"',
      'Verify that "Thank you for your order!" is visible',
    ].join("\n"),
  },
  {
    // Playwright Docs (playwright.dev)
    match: (p) =>
      /playwright\.dev/i.test(p.aut_url || "") ||
      /playwright/i.test(p.name || ""),
    title: "Playwright docs smoke",
    steps: [
      "Open the application",
      "Verify that Get started is visible",
      'Click on "Get started" link',
      'Verify that "Installation" is visible',
      'Click on "Agents" link',
      'Verify that "Playwright Test Agents" is visible',
    ].join("\n"),
  },
  {
    // Hydra app (localhost:9050 / Johnson & Johnson Medical Affairs workspace)
    match: (p) =>
      /localhost:9050/i.test(p.aut_url || "") ||
      /hydra/i.test((p.name || "") + " " + (p.aut_url || "")),
    title: "Advisory workspace smoke",
    steps: [
      "Open the application",
      'Verify that "Upload Document" is visible',
      'Verify that "Drop files or browse" is visible',
      'Upload file "C:/Users/Sanjeev/Desktop/Sushavon/hydra-backup/backend/data/test.pdf"',
      'Click on "Upload and index documents" button',
      'Verify that "Upload and index documents" is not visible',
    ].join("\n"),
  },
  {
    // Heroku App (the-internet.herokuapp.com)
    match: (p) =>
      /the-internet.herokuapp\.com/i.test(p.aut_url || "") ||
      /heroku/i.test(p.name || ""),
    title: "Heroku App smoke",
    steps: [
      "Open the application",
      'Enter "tomsmith" into "Username"',
      'Enter "SuperSecretPassword!" into "Password"',
      "Click on Login button",
      "Verify that the login message is visible",
      "Click on Logout button",
      "Verify that the logout message is visible",
    ].join("\n"),
  },
];
/**
 * Returns { title, steps } defaults for a project, or null if none match.
 * @param {{id:string,name?:string,aut_url?:string}} project
 */
export function defaultsForProject(project) {
  if (!project) return null;
  const hit = DEFAULTS.find((d) => {
    try {
      return d.match(project);
    } catch {
      return false;
    }
  });
  return hit ? { title: hit.title, steps: hit.steps } : null;
}
