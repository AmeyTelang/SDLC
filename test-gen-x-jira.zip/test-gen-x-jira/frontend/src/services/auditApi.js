// Audit trail API — read-only. There is no write helper by design.

import { authHeaders } from "../context/AuthContext.jsx";

const BASE = import.meta?.env?.VITE_API_BASE || "/api";

function headers(extra = {}) {
  return { ...authHeaders(), ...extra };
}

function qs(params = {}) {
  const p = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") p.append(k, v);
  });
  const s = p.toString();
  return s ? `?${s}` : "";
}

async function getJSON(path, fallback) {
  const res = await fetch(`${BASE}${path}`, { headers: headers() });
  if (res.status === 403)
    throw new Error("Your role is not permitted to view the audit trail.");
  if (!res.ok) {
    if (fallback !== undefined) return fallback;
    throw new Error(`Request failed (${res.status})`);
  }
  return res.json();
}

/** Filtered, paginated feed (newest first). */
export function listAuditEvents(params = {}) {
  return getJSON(`/audit/events${qs(params)}`, {
    total: 0,
    entries: [],
    returned: 0,
  });
}

/** Chronological trail for one test. */
export function auditTrailFor(entityId) {
  return getJSON(`/audit/events/${encodeURIComponent(entityId)}`, {
    entries: [],
  });
}

export function auditStats(days = 30) {
  return getJSON(`/audit/stats${qs({ days })}`, null);
}

/** Hash-chain integrity verdict. */
export function verifyAuditChain() {
  return getJSON("/audit/verify", null);
}

export function auditFilters() {
  return getJSON("/audit/filters", {
    actors: [],
    projects: [],
    stages: [],
    severities: [],
    actions: [],
  });
}

/** Trigger a browser download of the filtered trail. */
export async function exportAudit(format, params = {}) {
  const path = format === "csv" ? "/audit/export.csv" : "/audit/export.json";
  const res = await fetch(`${BASE}${path}${qs(params)}`, {
    headers: headers(),
  });
  if (!res.ok) throw new Error("Export failed.");

  const blob = await res.blob();
  const stamp = new Date().toISOString().slice(0, 10);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `testgenx_audit_trail_${stamp}.${format}`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
