const BASE = (import.meta?.env?.VITE_API_BASE || "").replace(/\/$/, "");

async function _json(res) {
  let body = null;
  try {
    body = await res.json();
  } catch {
    /* ignore */
  }
  if (!res.ok) {
    const msg = (body && (body.detail || body.message)) || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  return body;
}

export async function jiraHealth() {
  return _json(await fetch(`${BASE}/api/jira/health`));
}

// Two-level lookup. Pass projectKey and/or storyKey.
export async function jiraListTests({
  projectKey = "",
  storyKey = "",
  maxResults = 100,
  jql = "",
} = {}) {
  const q = new URLSearchParams({ max_results: String(maxResults) });
  if (projectKey) q.set("project_key", projectKey);
  if (storyKey) q.set("story_key", storyKey);
  if (jql) q.set("jql", jql);
  return _json(await fetch(`${BASE}/api/jira/tests?${q.toString()}`));
}

export async function jiraAttachResults(issueKey, testId, opts = {}) {
  const body = {
    test_id: testId,
    as_pdf: opts.asPdf !== false,
    include_evidence: opts.includeEvidence !== false,
    include_result_json: opts.includeResultJson !== false,
    comment: opts.comment || null,
  };
  return _json(
    await fetch(
      `${BASE}/api/jira/tests/${encodeURIComponent(issueKey)}/attach`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    ),
  );
}

// One click: attach report/evidence AND push PASS/FAIL onto the Xray test.
export async function jiraPublish(
  issueKey,
  testId,
  { projectKey, pushXray = true, asPdf = true, includeEvidence = true } = {},
) {
  const body = {
    test_id: testId,
    project_key: projectKey,
    push_xray: pushXray,
    as_pdf: asPdf,
    include_evidence: includeEvidence,
    include_result_json: true,
  };
  return _json(
    await fetch(
      `${BASE}/api/jira/tests/${encodeURIComponent(issueKey)}/publish`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      },
    ),
  );
}

export async function jiraXrayExecution(
  issueKey,
  { projectKey, status, summary = "", comment = "" },
) {
  return _json(
    await fetch(`${BASE}/api/jira/tests/${encodeURIComponent(issueKey)}/xray`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        project_key: projectKey,
        status,
        summary,
        comment,
      }),
    }),
  );
}
