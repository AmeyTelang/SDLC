import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";

import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";

import "./styles/theme.css";
import "./styles/ui-fixes.css";
import "./styles/layout3.css";
import "./styles/jira.css";
import "./styles/resultcard.css";
import "./styles/jira_push_row.css";
import "./styles/jira_2level.css";
import "./styles/jira_push_gate.css";
import "./styles/hitl.css";
import "./styles/rbac.css";
import "./styles/review_flow.css";
import "./styles/regen.css";
import "./styles/clear_cr.css";
import "./styles/drawer_fix.css";
import "./styles/audit.css";
import "./styles/testcase_studio.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </BrowserRouter>
  </React.StrictMode>,
);
