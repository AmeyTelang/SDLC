import { useCallback, useEffect, useRef, useState } from "react";
import { Rocket, Pen, Network, Ticket, PenLine, Inbox } from "lucide-react";
import Header from "./components/Header.jsx";
import ProjectSelector from "./components/ProjectSelector.jsx";
import NewTestCard from "./components/NewTestCard.jsx";
import Modal from "./components/Modal.jsx";
import TestStepsInput from "./components/TestStepsInput.jsx";
import AgentWorkflowStream from "./components/AgentWorkflowStream.jsx";
import ScriptViewer from "./components/ScriptViewer.jsx";
import ResultCard from "./components/ResultCard.jsx";
import HistoryView from "./components/HistoryView.jsx";
import JiraImport from "./components/JiraImport.jsx";
import ApprovalGate from "./components/ApprovalGate.jsx";
import ApprovalQueuePanel from "./components/ApprovalQueuePanel.jsx";
import {
  GenerationSkeleton,
  ExecutionSkeleton,
} from "./components/SkeletonPanels.jsx";
import { getHealth, listProjects } from "./services/api.js";
import {
  runGenerationStream,
  runExecutionStream,
  approveScript,
  rejectScript,
  listApprovalQueue,
  fetchQueueItem,
  discardQueueItem,
} from "./services/approvalApi.js";
import { useNotifications } from "./context/NotificationsContext.jsx";
import { defaultsForProject } from "./services/projectDefaults.js";
import XrayValidationTab from "./components/backend_validator/XrayValidationTab.jsx";
import ETLValidationTab from "./components/etl_validator/ETLValidationTab.jsx";
import TokenUsagePage from "./components/TokenUsage/TokenUsagePage.jsx";

const ENV_DEFAULT_SOURCE =
  (import.meta?.env?.VITE_DEFAULT_SOURCE || "manual").toLowerCase() === "jira"
    ? "jira"
    : "jira";

const LOCK_SOURCE =
  String(import.meta?.env?.VITE_LOCK_SOURCE || "").toLowerCase() === "true";

// Workspace modes:
//   "idle"     – nothing loaded, ready for a new test case
//   "generate" – Agent X is running (or just finished and queued the script)
//   "review"   – a queued test was pulled back in for approval
//   "execute"  – approved; Agent Y is running / has produced a result
const IDLE = "idle";

export default function LandingPage() {
  const [health, setHealth] = useState(null);
  const appliedDefaultsRef = useRef(null);

  const [view, setView] = useState("studio");
  const [source, setSource] = useState(ENV_DEFAULT_SOURCE);

  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [jiraIssueKey, setJiraIssueKey] = useState("");

  const [form, setForm] = useState({
    title: "Login and add to cart",
    natural_language_steps:
      "Open the application\nLogin with username standard_user and password secret_sauce\nVerify that Products is visible\nClick on Add to cart",
    language: "python",
  });

  // ---- workspace state ----------------------------------------------
  const [mode, setMode] = useState(IDLE);
  const [events, setEvents] = useState([]);
  const [progress, setProgress] = useState(0);
  const [gen, setGen] = useState(null);
  const [result, setResult] = useState(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState(null);
  const [banner, setBanner] = useState(null);
  const [etlRuns, setEtlRuns] = useState([]);

  // ---- HITL approval queue -------------------------------------------
  const [queue, setQueue] = useState([]);
  const [queueLoading, setQueueLoading] = useState(false);
  const [gate, setGate] = useState(null); // non-null only in "review" mode
  const [approving, setApproving] = useState(false);
  const { push: pushNotification } = useNotifications();

  const [usageRefresh, setUsageRefresh] = useState(0);

  const loadProjects = () =>
    listProjects()
      .then((ps) => {
        setProjects(ps);
        setProjectId((cur) => cur || (ps[0]?.id ?? null));
      })
      .catch(() => setProjects([]));

  const refreshQueue = useCallback(async () => {
    setQueueLoading(true);
    try {
      setQueue(await listApprovalQueue());
    } catch {
      /* keep the last known queue */
    } finally {
      setQueueLoading(false);
    }
  }, []);

  useEffect(() => {
    getHealth()
      .then(setHealth)
      .catch(() => setHealth({ engine: "fallback" }));
    loadProjects();
    refreshQueue();
  }, [refreshQueue]);

  useEffect(() => {
    if (!projectId || appliedDefaultsRef.current === projectId) return;
    const proj = projects.find((p) => p.id === projectId);
    if (!proj) return;
    appliedDefaultsRef.current = projectId;
    const d = defaultsForProject(proj);
    if (d)
      setForm((f) => ({
        ...f,
        title: d.title,
        natural_language_steps: d.steps,
      }));
  }, [projectId, projects]);

  const project = projects.find((p) => p.id === projectId) || null;

  const handleEtlHistoryAdd = (run) => {
    setEtlRuns((prev) => [
      run,
      ...prev.filter((r) => r.test_id !== run.test_id),
    ]);
    setUsageRefresh((n) => n + 1);
  };

  const collect = (ev) => {
    setEvents((prev) => [...prev, ev]);
    if (typeof ev.progress === "number") setProgress(ev.progress);
  };

  /** Clear the middle column so a new test case can be authored. */
  const resetWorkspace = useCallback(() => {
    setMode(IDLE);
    setEvents([]);
    setProgress(0);
    setGen(null);
    setResult(null);
    setGate(null);
    setError(null);
  }, []);

  // ==================================================================
  // STEP 1 — generate, then queue and reset the workspace
  // ==================================================================
  const onRun = async () => {
    setShowModal(false);
    resetWorkspace();
    setBanner(null);
    setMode("generate");
    setRunning(true);

    let queuedTitle = form.title;

    try {
      await runGenerationStream({ ...form, project_id: projectId }, (ev) => {
        collect(ev);

        if (ev.agent === "generation" && ev.phase === "artifact" && ev.data)
          setGen(ev.data);

        // STEP 2 — script parked in the queue.
        if (ev.agent === "approval" && ev.phase === "queued" && ev.data) {
          const q = ev.data.queued || {};
          queuedTitle = q.title || queuedTitle;
          setQueue((prev) => [
            q,
            ...prev.filter((i) => i.test_id !== q.test_id),
          ]);
          const n = ev.data.notification || {};
          pushNotification({
            kind: "approval_required",
            title: n.title || "Test script queued for approval",
            body: n.body || `“${q.title}” is awaiting review`,
            testId: ev.data.test_id || q.test_id,
          });
        }
      });

      setUsageRefresh((n) => n + 1);
      refreshQueue();

      // Workspace is handed back for the next test case.
      resetWorkspace();
      setBanner({
        kind: "queued",
        text: `“${queuedTitle}” is queued for approval. The workspace is ready for your next test case.`,
      });
    } catch (e) {
      setError(e.message || "Generation failed");
    } finally {
      setRunning(false);
    }
  };

  // ==================================================================
  // STEP 3 — pull a queued test back into the workspace
  // ==================================================================
  const onPull = async (testId) => {
    setBanner(null);
    setError(null);
    try {
      const item = await fetchQueueItem(testId);
      setEvents([]);
      setProgress(60);
      setResult(null);
      setGen(item.artifact || null);
      setGate({
        test_id: item.test_id,
        title: item.title,
        file_name: item.file_name,
        step_count: item.step_count,
        iteration: item.iteration,
        project_name: item.project_name,
      });
      setMode("review");
      setEvents([
        {
          agent: "approval",
          phase: "review",
          message: `Approval Queue: “${item.title}” pulled into the workspace for review.`,
          progress: 60,
        },
      ]);
      setTimeout(
        () =>
          document
            .getElementById("approval-gate")
            ?.scrollIntoView({ behavior: "smooth", block: "center" }),
        80,
      );
    } catch (e) {
      setError(e.message || "Could not load this queued test.");
      refreshQueue();
    }
  };

  const onDiscard = async (testId) => {
    try {
      await discardQueueItem(testId);
      setQueue((prev) => prev.filter((i) => i.test_id !== testId));
      if (gate?.test_id === testId) resetWorkspace();
    } catch (e) {
      setError(e.message || "Could not discard this item.");
    }
  };

  // ==================================================================
  // STEP 4 + 5 — approve, then the Execution Agent runs
  // ==================================================================
  const onApprove = async (testId, comment) => {
    setApproving(true);
    setError(null);
    try {
      await approveScript(testId, "reviewer", comment);
      setGate(null);
      setMode("execute");
      setRunning(true);
      pushNotification({
        kind: "approved",
        title: "Script approved",
        body: "Execution Agent has been released to run the test.",
        testId,
      });

      await runExecutionStream(testId, (ev) => {
        collect(ev);
        if (ev.agent === "execution" && ev.phase === "artifact" && ev.data)
          setResult({
            ...ev.data,
            title: gate?.title,
            jira_issue_key: jiraIssueKey,
          });
      });

      setQueue((prev) => prev.filter((i) => i.test_id !== testId));
      loadProjects();
      refreshQueue();
      setUsageRefresh((n) => n + 1);
    } catch (e) {
      setError(e.message || "Execution failed");
    } finally {
      setApproving(false);
      setRunning(false);
    }
  };

  const onReject = async (testId, comment) => {
    setApproving(true);
    try {
      await rejectScript(testId, "reviewer", comment);
      setQueue((prev) => prev.filter((i) => i.test_id !== testId));
      pushNotification({
        kind: "rejected",
        title: "Script rejected",
        body: "Execution Agent was not invoked. Regenerate the test to retry.",
        testId,
      });
      resetWorkspace();
      setBanner({
        kind: "rejected",
        text: "Script rejected and removed from the approval queue.",
      });
      refreshQueue();
    } catch (e) {
      setError(e.message || "Rejection failed");
    } finally {
      setApproving(false);
    }
  };

  // Bell click -> jump to the queue panel.
  const focusApproval = () => {
    setView("studio");
    setTimeout(
      () =>
        document
          .getElementById("approval-queue")
          ?.scrollIntoView({ behavior: "smooth", block: "center" }),
      60,
    );
  };

  const onJiraImport = (t) => {
    setForm((f) => ({
      ...f,
      title: t.summary || t.key,
      natural_language_steps:
        Array.isArray(t.steps) && t.steps.length > 0
          ? t.steps.join("\n")
          : f.natural_language_steps,
    }));
    setJiraIssueKey(t.key || "");
    setShowModal(true);
  };

  const started = events.length > 0 || running;
  const showGenSkeleton = mode === "generate" && running && !gen;

  return (
    <div className="app-shell">
      <Header
        health={health}
        view={view}
        setView={setView}
        onOpenApproval={focusApproval}
      />

      <div style={{ display: view === "etl" ? "block" : "none" }}>
        <ETLValidationTab onHistoryAdd={handleEtlHistoryAdd} />
      </div>

      {view === "xray" ? <XrayValidationTab /> : null}
      {view === "usage" ? <TokenUsagePage refreshKey={usageRefresh} /> : null}

      {view === "history" ? (
        <div className="container">
          <HistoryView projects={projects} etlRuns={etlRuns} />
        </div>
      ) : null}

      {view === "studio" && (
        <div className="container">
          <div className="grid-3">
            {/* LEFT — source, project, author + the approval queue */}
            <aside className="col-left">
              {!LOCK_SOURCE && (
                <div
                  className="source-toggle"
                  role="tablist"
                  aria-label="Test source"
                >
                  <button
                    role="tab"
                    aria-selected={source === "manual"}
                    className={source === "manual" ? "active" : ""}
                    onClick={() => setSource("manual")}
                  >
                    <PenLine size={14} /> Manual
                  </button>
                  <button
                    role="tab"
                    aria-selected={source === "jira"}
                    className={source === "jira" ? "active" : ""}
                    onClick={() => setSource("jira")}
                  >
                    <Ticket size={14} /> JIRA
                  </button>
                </div>
              )}

              {source === "jira" ? (
                <JiraImport
                  defaultProjectKey={project?.jira_project_key || ""}
                  onImport={onJiraImport}
                />
              ) : (
                <>
                  <ProjectSelector
                    projects={projects}
                    selectedId={projectId}
                    onSelect={setProjectId}
                    onCreated={(p) => {
                      setProjects((prev) => [...prev, p]);
                      setProjectId(p.id);
                    }}
                  />
                  <NewTestCard
                    project={project}
                    running={running}
                    onOpen={() => setShowModal(true)}
                  />
                </>
              )}

              {/* STEP 2/3 — parked scripts live here */}
              <div id="approval-queue">
                <ApprovalQueuePanel
                  items={queue}
                  activeTestId={gate?.test_id || null}
                  loading={queueLoading}
                  onPull={onPull}
                  onDiscard={onDiscard}
                  onRefresh={refreshQueue}
                />
              </div>
            </aside>

            {/* MIDDLE — the workspace */}
            <main className="col-mid">
              {error && (
                <div className="card">
                  <div className="card-body" style={{ color: "var(--fail)" }}>
                    {error}
                  </div>
                </div>
              )}

              {banner && (
                <div className={`ws-banner ${banner.kind}`}>
                  <Inbox size={15} />
                  <span>{banner.text}</span>
                  <button onClick={() => setBanner(null)} aria-label="Dismiss">
                    ×
                  </button>
                </div>
              )}

              {mode === IDLE && !started && (
                <div className="card">
                  <div className="empty">
                    <div className="ico">
                      <Rocket size={28} />
                    </div>
                    <h3>Agentic Test Automation</h3>
                    <p>
                      Pick a <b>project</b>, click <b>New Test</b> and describe
                      it in plain English. <b>Agent X</b> generates the
                      Playwright script and parks it in <b>Pending Approval</b>{" "}
                      — the workspace clears immediately so you can queue up the
                      next test case. When you're ready, pull a queued test back
                      in, <b>review & approve</b> it, and <b>Agent Y</b>{" "}
                      executes it and reports the result.
                    </p>
                  </div>
                </div>
              )}

              {gen ? (
                <ScriptViewer gen={gen} />
              ) : (
                showGenSkeleton && <GenerationSkeleton />
              )}

              {/* STEP 4 — only after an explicit pull from the queue */}
              {mode === "review" && gate && (
                <ApprovalGate
                  gate={gate}
                  onApprove={onApprove}
                  onReject={onReject}
                  onClose={resetWorkspace}
                  busy={approving}
                />
              )}

              {result ? (
                <ResultCard
                  result={result}
                  project={project}
                  jiraIssueKey={jiraIssueKey}
                />
              ) : (
                mode === "execute" && running && <ExecutionSkeleton />
              )}
            </main>

            {/* RIGHT — live workflow */}
            <aside className="col-right">
              {started ? (
                <AgentWorkflowStream
                  events={events}
                  progress={progress}
                  running={running}
                  awaitingApproval={mode === "review"}
                />
              ) : (
                <div className="card">
                  <div className="card-head">
                    <span className="icon">
                      <Network size={18} />
                    </span>
                    <h2>Agent Workflow Stream</h2>
                    <span className="spacer" />
                  </div>
                  <div className="card-body">
                    <div className="wf-idle">
                      The live agent workflow will appear here when you run a
                      test.
                    </div>
                  </div>
                </div>
              )}
            </aside>
          </div>
        </div>
      )}

      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        width={620}
        title="New Test"
        icon={
          <Pen size={18} style={{ marginRight: 8, color: "var(--primary)" }} />
        }
      >
        <TestStepsInput
          form={form}
          setForm={setForm}
          onRun={onRun}
          running={running}
          project={project}
          embedded
        />
      </Modal>
    </div>
  );
}
