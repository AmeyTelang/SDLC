import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ScrollText,
  ShieldCheck,
  ShieldAlert,
  Search,
  RefreshCw,
  Download,
  FileJson,
  Loader2,
  X,
  ChevronDown,
  ChevronUp,
  CircleUser,
  Hash,
  Filter,
} from "lucide-react";
import {
  listAuditEvents,
  auditStats,
  verifyAuditChain,
  auditFilters,
  exportAudit,
} from "./services/auditApi.js";
import { useAuth } from "./context/AuthContext.jsx";

const PAGE = 100;

function when(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function ago(iso) {
  if (!iso) return "";
  const s = Math.max(
    1,
    Math.round((Date.now() - new Date(iso).getTime()) / 1000),
  );
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

function daysAgoISO(n) {
  return new Date(Date.now() - n * 86400000).toISOString();
}

/** One expandable row. */
function EventRow({ e, expanded, onToggle }) {
  const hasDetail = e.details && Object.keys(e.details).length > 0;
  return (
    <>
      <tr className={`audit-row sev-${e.severity}`} onClick={onToggle}>
        <td className="c-seq">#{e.seq}</td>
        <td className="c-when">
          <span>{when(e.at)}</span>
          <i>{ago(e.at)}</i>
        </td>
        <td className="c-actor">
          <span className={`role-dot ${e.actor_role}`} />
          <span className="a-name">{e.actor}</span>
        </td>
        <td>
          <span className={`audit-pill sev-${e.severity}`}>{e.label}</span>
        </td>
        <td className="c-stage">{e.stage}</td>
        <td className="c-entity">
          {e.entity_title ? (
            <>
              <b>{e.entity_title}</b>
              {e.iteration ? <i> · iter {e.iteration}</i> : null}
            </>
          ) : (
            <span className="muted">{e.entity_id || "—"}</span>
          )}
        </td>
        <td className="c-summary">{e.summary}</td>
        <td className="c-exp">
          {hasDetail ? (
            expanded ? (
              <ChevronUp size={14} />
            ) : (
              <ChevronDown size={14} />
            )
          ) : null}
        </td>
      </tr>
      {expanded && hasDetail && (
        <tr className="audit-detail-row">
          <td colSpan={8}>
            <div className="audit-detail">
              <div className="ad-grid">
                {Object.entries(e.details)
                  .filter(([, v]) => v !== null && v !== undefined && v !== "")
                  .map(([k, v]) => (
                    <div key={k} className="ad-item">
                      <span className="ad-k">{k.replace(/_/g, " ")}</span>
                      <span className="ad-v">
                        {typeof v === "object" ? JSON.stringify(v) : String(v)}
                      </span>
                    </div>
                  ))}
              </div>
              <div className="ad-hash">
                <Hash size={11} />
                <span title={e.hash}>{(e.hash || "").slice(0, 24)}…</span>
                <span className="ad-prev" title={e.prev_hash}>
                  prev {(e.prev_hash || "").slice(0, 12)}…
                </span>
                {e.entity_id && <span className="ad-eid">{e.entity_id}</span>}
              </div>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

/**
 * Audit Trail — visible to BOTH roles, read-only for both.
 *
 * Deliberately has no mutation controls of any kind: entries exist only as a
 * side effect of workflow actions. The integrity banner surfaces the
 * hash-chain verdict so a reader can tell at a glance whether the log has
 * been altered outside the application.
 */
export default function AuditTrailView() {
  const { user } = useAuth();

  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [stats, setStats] = useState(null);
  const [integrity, setIntegrity] = useState(null);
  const [opts, setOpts] = useState({
    actors: [],
    stages: [],
    actions: [],
    severities: [],
  });

  const [expanded, setExpanded] = useState(null);
  const [exporting, setExporting] = useState(null);
  const [showFilters, setShowFilters] = useState(false);

  const [f, setF] = useState({
    search: "",
    actor: "",
    action: "",
    stage: "",
    severity: "",
    days: "30",
  });

  const params = useMemo(() => {
    const p = {
      search: f.search || undefined,
      actor: f.actor || undefined,
      action: f.action || undefined,
      stage: f.stage || undefined,
      severity: f.severity || undefined,
    };
    if (f.days && f.days !== "all") p.since = daysAgoISO(Number(f.days));
    return p;
  }, [f]);

  const load = useCallback(
    async (nextOffset = 0, append = false) => {
      setLoading(true);
      setError(null);
      try {
        const res = await listAuditEvents({
          ...params,
          limit: PAGE,
          offset: nextOffset,
        });
        setTotal(res.total || 0);
        setOffset(nextOffset);
        setRows((prev) =>
          append ? [...prev, ...(res.entries || [])] : res.entries || [],
        );
      } catch (e) {
        setError(e.message || "Could not load the audit trail.");
        if (!append) setRows([]);
      } finally {
        setLoading(false);
      }
    },
    [params],
  );

  useEffect(() => {
    load(0, false);
  }, [load]);

  useEffect(() => {
    auditFilters()
      .then(setOpts)
      .catch(() => {});
  }, []);

  const refreshMeta = useCallback(() => {
    auditStats(f.days === "all" ? 3650 : Number(f.days))
      .then(setStats)
      .catch(() => {});
    verifyAuditChain()
      .then(setIntegrity)
      .catch(() => {});
  }, [f.days]);

  useEffect(refreshMeta, [refreshMeta]);

  const doExport = async (fmt) => {
    setExporting(fmt);
    try {
      await exportAudit(fmt, params);
    } catch (e) {
      setError(e.message || "Export failed.");
    } finally {
      setExporting(null);
    }
  };

  const set = (k) => (e) => setF((prev) => ({ ...prev, [k]: e.target.value }));
  const clearFilters = () =>
    setF({
      search: "",
      actor: "",
      action: "",
      stage: "",
      severity: "",
      days: "30",
    });

  const activeFilters =
    [f.search, f.actor, f.action, f.stage, f.severity].filter(Boolean).length +
    (f.days !== "30" ? 1 : 0);

  return (
    <div className="container audit-view">
      {/* ---------- header ---------- */}
      <div className="audit-head">
        <div className="audit-title">
          <span className="audit-ico">
            <ScrollText size={20} />
          </span>
          <div>
            <h2>Audit Trail</h2>
            <p>
              Complete, append-only record of every workflow action. Read-only
              for all roles — you are viewing as <b>{user?.role_label}</b>.
            </p>
          </div>
        </div>

        {/* <div className="audit-head-actions">
          <button
            className="audit-btn"
            onClick={() => {
              load(0, false);
              refreshMeta();
            }}
            disabled={loading}
          >
            <RefreshCw size={14} className={loading ? "spin" : ""} /> Refresh
          </button>
          <button
            className="audit-btn"
            onClick={() => doExport("csv")}
            disabled={!!exporting}
          >
            {exporting === "csv" ? (
              <Loader2 size={14} className="spin" />
            ) : (
              <Download size={14} />
            )}
            CSV
          </button>
          <button
            className="audit-btn"
            onClick={() => doExport("json")}
            disabled={!!exporting}
          >
            {exporting === "json" ? (
              <Loader2 size={14} className="spin" />
            ) : (
              <FileJson size={14} />
            )}
            JSON
          </button>
        </div> */}
      </div>

      {/* ---------- integrity banner ---------- */}
      {/* {integrity && (
        <div className={`integrity-bar ${integrity.valid ? "ok" : "broken"}`}>
          {integrity.valid ? (
            <ShieldCheck size={16} />
          ) : (
            <ShieldAlert size={16} />
          )}
          <div>
            <b>
              {integrity.valid
                ? "Chain verified — the audit trail has not been altered"
                : `Integrity failure at entry #${integrity.broken_at_seq}`}
            </b>
            <span>
              {integrity.reason}
              {integrity.valid && integrity.head_hash
                ? ` Head ${integrity.head_hash.slice(0, 16)}…`
                : ""}
            </span>
          </div>
          <span className="integrity-count">{integrity.checked} entries</span>
        </div>
      )} */}

      {/* ---------- KPIs ---------- */}
      {/* {stats && (
        <div className="metrics audit-metrics">
          <div className="metric">
            <div className="n">{stats.total_events}</div>
            <div className="l">Total events</div>
          </div>
          <div className="metric ok">
            <div className="n">{stats.approvals}</div>
            <div className="l">Approvals</div>
          </div>
          <div className="metric warn">
            <div className="n">{stats.sent_back}</div>
            <div className="l">Sent back</div>
          </div>
          <div className="metric">
            <div className="n">
              {stats.first_pass_rate === null
                ? "—"
                : `${stats.first_pass_rate}%`}
            </div>
            <div className="l">First-pass rate</div>
          </div>
          <div className="metric">
            <div className="n">{stats.executions}</div>
            <div className="l">Executions</div>
          </div>
          <div className="metric bad">
            <div className="n">{stats.blocked}</div>
            <div className="l">Blocked</div>
          </div>
        </div>
      )} */}

      {/* ---------- filters ---------- */}
      <div className="audit-filters">
        <div className="search-box">
          <Search size={15} />
          <input
            placeholder="Search actor, test, summary or detail…"
            value={f.search}
            onChange={set("search")}
          />
          {f.search && (
            <button
              className="sb-clear"
              onClick={() => setF((p) => ({ ...p, search: "" }))}
            >
              <X size={13} />
            </button>
          )}
        </div>

        {/* <select className="audit-dd" value={f.days} onChange={set("days")}>
          <option value="1">Last 24 hours</option>
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
          <option value="90">Last 90 days</option>
          <option value="all">All time</option>
        </select> */}

        <button
          className={`audit-btn ${showFilters ? "active" : ""}`}
          onClick={() => setShowFilters((v) => !v)}
        >
          <Filter size={14} /> Filters
          {activeFilters > 0 && (
            <span className="f-count">{activeFilters}</span>
          )}
        </button>

        {activeFilters > 0 && (
          <button className="audit-link" onClick={clearFilters}>
            Clear all
          </button>
        )}

        <span className="audit-total">
          {total.toLocaleString()} event{total === 1 ? "" : "s"}
        </span>
      </div>

      {showFilters && (
        <div className="audit-filter-row">
          <label>
            <span>Actor</span>
            <select
              className="audit-dd"
              value={f.actor}
              onChange={set("actor")}
            >
              <option value="">Anyone</option>
              {opts.actors.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Stage</span>
            <select
              className="audit-dd"
              value={f.stage}
              onChange={set("stage")}
            >
              <option value="">All stages</option>
              {opts.stages.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Action</span>
            <select
              className="audit-dd"
              value={f.action}
              onChange={set("action")}
            >
              <option value="">All actions</option>
              {opts.actions.map((a) => (
                <option key={a.value} value={a.value}>
                  {a.label}
                </option>
              ))}
            </select>
          </label>
          <label>
            <span>Severity</span>
            <select
              className="audit-dd"
              value={f.severity}
              onChange={set("severity")}
            >
              <option value="">Any</option>
              {opts.severities.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </label>
        </div>
      )}

      {/* ---------- table ---------- */}
      <div className="card">
        {error ? (
          <div className="card-body" style={{ color: "var(--fail)" }}>
            {error}
          </div>
        ) : loading && rows.length === 0 ? (
          <div className="drawer-loading">
            <Loader2 size={22} className="spin" /> Loading audit trail…
          </div>
        ) : rows.length === 0 ? (
          <div className="empty">
            <div className="ico">
              <ScrollText size={28} />
            </div>
            <h3>No events match</h3>
            <p>
              {activeFilters > 0
                ? "Try widening the time range or clearing the filters."
                : "Events are appended automatically as work moves through the workflow."}
            </p>
          </div>
        ) : (
          <>
            <table className="run-table audit-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>When</th>
                  <th>Actor</th>
                  <th>Action</th>
                  <th>Stage</th>
                  <th>Test</th>
                  <th>Summary</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {rows.map((e) => (
                  <EventRow
                    key={e.seq}
                    e={e}
                    expanded={expanded === e.seq}
                    onToggle={() =>
                      setExpanded(expanded === e.seq ? null : e.seq)
                    }
                  />
                ))}
              </tbody>
            </table>

            {rows.length < total && (
              <div className="audit-more">
                <button
                  className="audit-btn"
                  disabled={loading}
                  onClick={() => load(offset + PAGE, true)}
                >
                  {loading ? <Loader2 size={14} className="spin" /> : null}
                  Load {Math.min(PAGE, total - rows.length)} more ({rows.length}{" "}
                  of {total})
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* <p className="audit-foot">
        <CircleUser size={12} /> Entries are written only as a side effect of
        workflow actions. No user or role — including yours — can create, edit
        or delete a record. Each entry embeds the hash of the one before it, so
        any alteration breaks verification at that point and every point after.
      </p> */}
    </div>
  );
}
