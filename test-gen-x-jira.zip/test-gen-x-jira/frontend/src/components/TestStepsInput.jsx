import {
  Play,
  Loader2,
  RefreshCw,
  MessageSquareWarning,
  Globe,
} from "lucide-react";

/**
 * "New Test" steps form, rendered inside the modal.
 *
 * Delta: accepts an optional `rework` context. When present the form becomes
 * the **revise-and-regenerate** step of the HITL loop — the Test Lead's
 * feedback is pinned above the steps box, the steps are pre-filled with what
 * was originally authored, and the CTA changes from "Generate" to
 * "Regenerate Script".
 */
export default function TestStepsInput({
  form,
  setForm,
  onRun,
  running = false,
  project,
  embedded = false,
  rework = null, // { test_id, iteration, feedback, approver }
}) {
  const isRework = !!rework;
  const steps = form.natural_language_steps || "";
  const stepCount = steps.split("\n").filter((s) => s.trim()).length;

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <div className={`steps-form ${embedded ? "embedded" : ""}`}>
      {/* ---- Test Lead feedback (regeneration only) ---- */}
      {/* {isRework && (
        <div className="rework-banner">
          <span className="rw-ico">
            <MessageSquareWarning size={16} />
          </span>
          <div>
            <b>
              {rework.approver || "Test Lead"} asked for changes
              {rework.iteration ? ` · revision ${rework.iteration + 1}` : ""}
            </b>
            <p>{rework.feedback}</p>
            <span className="rw-hint">
              Edit the steps below to address this, then regenerate.
            </span>
          </div>
        </div>
      )} */}

      {/* {project && (
        <div className="steps-target">
          <Globe size={13} />
          <span>
            <b>{project.name}</b>
            {project.aut_url ? ` · ${project.aut_url}` : ""}
          </span>
        </div>
      )} */}

      <label className="steps-label" htmlFor="test-title">
        Test title
      </label>
      <input
        id="test-title"
        className="steps-input"
        type="text"
        value={form.title || ""}
        onChange={set("title")}
        placeholder="e.g. Login and add to cart"
      />
      <br />
      <br />
      <div className="steps-label-row">
        <label className="steps-label" htmlFor="test-steps">
          Test steps
        </label>
        {/* <span className="steps-count">
          {stepCount} step{stepCount === 1 ? "" : "s"} · one per line
        </span> */}
      </div>
      <textarea
        id="test-steps"
        className="steps-textarea"
        rows={9}
        value={steps}
        onChange={set("natural_language_steps")}
        placeholder={
          "Open the application\nLogin with username …\nVerify that …"
        }
      />

      {/* <label className="steps-label" htmlFor="test-lang">
        Language
      </label>
      <select
        id="test-lang"
        className="steps-input"
        value={form.language || "python"}
        onChange={set("language")}
      >
        <option value="python">Python · Playwright</option>
        <option value="typescript">TypeScript · Playwright</option>
      </select> */}

      <div className="steps-actions">
        <button
          className={`btn btn-primary ${isRework ? "regen-cta" : "generate-cta"}`}
          onClick={onRun}
          disabled={running || !stepCount}
        >
          {running ? (
            <Loader2 size={16} className="spin" />
          ) : isRework ? (
            <RefreshCw size={15} />
          ) : (
            <Play size={15} />
          )}
          {running
            ? isRework
              ? "Regenerating…"
              : "Generating…"
            : isRework
              ? "Regenerate Script"
              : "Generate Script"}
        </button>

        {/* <span className="steps-note">
          {isRework
            ? "Creates a fresh draft — it returns to the Test Lead only when you submit it."
            : "Agent X generates a draft for your review."}
        </span> */}
      </div>
    </div>
  );
}
