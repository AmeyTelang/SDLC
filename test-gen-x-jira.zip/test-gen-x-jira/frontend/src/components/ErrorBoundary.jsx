import React from "react";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, info: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    // eslint-disable-next-line no-console
    console.error("TestGenX crashed:", error, info);
    this.setState({ info });
  }
  render() {
    if (!this.state.error) return this.props.children;
    const { error, info } = this.state;
    return (
      <div
        style={{
          minHeight: "100vh",
          padding: "40px",
          color: "#eaeef7",
          background: "#0a0e1a",
          fontFamily: "Inter, Segoe UI, system-ui, sans-serif",
        }}
      >
        <div
          style={{
            maxWidth: 820,
            margin: "40px auto",
            background: "#131a2c",
            border: "1px solid #232c44",
            borderRadius: 16,
            padding: 24,
            boxShadow: "0 16px 40px rgba(0,0,0,.5)",
          }}
        >
          <h2 style={{ margin: "0 0 8px", color: "#ff6b81" }}>
            ⚠️ The UI hit an error
          </h2>
          <p style={{ color: "#98a3bd", marginTop: 0 }}>
            The details below tell you exactly what broke. Open the browser
            console (F12) for the full stack trace.
          </p>
          <pre
            style={{
              background: "#070b14",
              color: "#ff9aa8",
              border: "1px solid #232c44",
              borderRadius: 12,
              padding: 16,
              overflow: "auto",
              fontSize: 13,
              lineHeight: 1.5,
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
            }}
          >
            {String(error && (error.stack || error.message || error))}
            {info && info.componentStack
              ? "\n\nComponent stack:" + info.componentStack
              : ""}
          </pre>
          <button
            onClick={() => window.location.reload()}
            style={{
              marginTop: 14,
              padding: "10px 16px",
              borderRadius: 11,
              border: "none",
              cursor: "pointer",
              fontWeight: 700,
              color: "#fff",
              background: "linear-gradient(135deg,#6a5cff,#9a7cff)",
            }}
          >
            Reload
          </button>
        </div>
      </div>
    );
  }
}
