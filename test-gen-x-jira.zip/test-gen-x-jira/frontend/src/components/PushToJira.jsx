import { useEffect, useRef, useState } from "react";
import { Ticket, Loader2, CheckCircle2, AlertTriangle, X } from "lucide-react";
import { jiraPublish, jiraAttachResults } from "../services/jiraApi.js";

const AUTO_CLOSE_MS = 1800;

// "DP-3" -> "DP" ; "ABC-123" -> "ABC" ; "" -> ""
function projectFromKey(key) {
  const m = String(key || "")
    .trim()
    .match(/^([A-Za-z][A-Za-z0-9]+)-\d+/);
  return m ? m[1].toUpperCase() : "";
}

export default function PushToJira({
  testId,
  status,
  defaultIssueKey = "",
  projectKey = "",
}) {
  const [open, setOpen] = useState(false);
  const [issueKey, setIssueKey] = useState(defaultIssueKey);
  const [asPdf, setAsPdf] = useState(true);
  const [includeEvidence, setIncludeEvidence] = useState(true);
  const [pushXray, setPushXray] = useState(true);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const closeTimer = useRef(null);

  // Effective project key: explicit prop wins, else derive from the typed key.
  const effProject = projectKey || projectFromKey(issueKey);
  const canXray = Boolean(effProject);

  useEffect(
    () => () => {
      if (closeTimer.current) clearTimeout(closeTimer.current);
    },
    [],
  );

  const closeSoon = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => {
      setOpen(false);
      setResult(null);
    }, AUTO_CLOSE_MS);
  };
  const closeNow = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    setOpen(false);
  };

  const submit = async () => {
    if (!issueKey.trim()) {
      setResult({ ok: false, msg: "Enter a JIRA test key (e.g. DP-3)." });
      return;
    }
    setBusy(true);
    setResult(null);
    try {
      let msg;
      const wantXray = pushXray && canXray;
      if (wantXray) {
        const r = await jiraPublish(issueKey.trim(), testId, {
          projectKey: effProject,
          pushXray: true,
          asPdf,
          includeEvidence,
        });
        msg = `Attached ${r.attached ?? 0} file(s) to ${issueKey.trim()}`;
        if (r.xray) msg += " · Xray result recorded.";
        else if (r.xray_error) msg += ` · Xray skipped: ${r.xray_error}`;
      } else {
        const r = await jiraAttachResults(issueKey.trim(), testId, {
          asPdf,
          includeEvidence,
        });
        msg = `Attached ${r.count} file(s) to ${issueKey.trim()}.`;
      }
      setResult({ ok: true, msg });
      closeSoon();
    } catch (e) {
      setResult({ ok: false, msg: e.message || "Push to JIRA failed." });
    } finally {
      setBusy(false);
    }
  };

  const toggle = () => {
    if (open) closeNow();
    else {
      setResult(null);
      setOpen(true);
    }
  };

  return (
    <div className="ptj-wrap">
      <button
        className="btn btn-sm"
        onClick={toggle}
        title="Attach results & record status on the JIRA/Xray test"
      >
        <Ticket size={15} /> Push to JIRA
      </button>

      {open && (
        <div className="ptj-pop" role="dialog">
          <div className="ptj-head">
            <span>Publish to JIRA</span>
            <button className="ptj-x" onClick={closeNow}>
              <X size={14} />
            </button>
          </div>

          <label className="ptj-label">JIRA test key</label>
          <input
            className="jira-input"
            placeholder="e.g. DP-3"
            value={issueKey}
            onChange={(e) => setIssueKey(e.target.value)}
            disabled={busy}
          />

          <label className="ptj-check">
            <input
              type="checkbox"
              checked={asPdf}
              onChange={(e) => setAsPdf(e.target.checked)}
              disabled={busy}
            />
            Report as PDF {asPdf ? "" : "(HTML)"}
          </label>
          <label className="ptj-check">
            <input
              type="checkbox"
              checked={includeEvidence}
              onChange={(e) => setIncludeEvidence(e.target.checked)}
              disabled={busy}
            />
            Include evidence .zip
          </label>
          <label className="ptj-check">
            <input
              type="checkbox"
              checked={pushXray && canXray}
              onChange={(e) => setPushXray(e.target.checked)}
              disabled={busy || !canXray}
            />
            Record {String(status || "").toUpperCase()} on Xray test
            {canXray
              ? ` (project ${effProject})`
              : " (enter a valid key like DP-3)"}
          </label>

          <button
            className="btn btn-primary"
            onClick={submit}
            disabled={busy}
            style={{ marginTop: 8, width: "100%" }}
          >
            {busy ? (
              <Loader2 size={15} className="spin" />
            ) : (
              <Ticket size={15} />
            )}
            {busy ? "Publishing…" : "Publish to JIRA"}
          </button>

          {result && (
            <div className={`ptj-result ${result.ok ? "ok" : "err"}`}>
              {result.ok ? (
                <CheckCircle2 size={14} />
              ) : (
                <AlertTriangle size={14} />
              )}{" "}
              {result.msg}
              {result.ok}
              {/* {result.ok} && <span className="ptj-closing"> — closing…</span>} */}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
