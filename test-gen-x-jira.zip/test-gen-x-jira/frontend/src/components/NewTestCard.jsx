import { FlaskConical, Plus, Globe, Info, Pen } from "lucide-react";

export default function NewTestCard({ project, onOpen, running }) {
  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Pen size={18} />
        </span>
        <h2>Author Test</h2>
      </div>
      <div className="card-body">
        {project ? (
          <div className="nt-target">
            <Globe size={14} />
            <div>
              <b>Target</b>
              <span>
                {project.name} · {project.aut_url}
              </span>
            </div>
          </div>
        ) : (
          <div className="inline-note">
            <Info size={13} /> Select a project above to set the target
            application.
          </div>
        )}
        <button
          className="btn btn-primary"
          onClick={onOpen}
          disabled={running || !project}
          style={{ marginTop: 12 }}
        >
          <Plus size={17} /> {running ? "Agents running…" : "New Test"}
        </button>
      </div>
    </div>
  );
}
