import React from "react";
import {
  Download,
  ClipboardList,
  Search,
  Sparkles,
  Loader2,
  ListChecks,
  Database,
  Scale,
  ArrowRightLeft,
  ArrowRight,
  CloudDownload,
} from "lucide-react";

/**
 * LeftPanel — Source / JIRA import + extracted spec.
 * Pure presentational: all state & handlers are passed in as props.
 */
export default function LeftPanel({
  projectId,
  setProjectId,
  storyKey,
  setStoryKey,
  spec,
  busy,
  onImport,
  onGenerate,
}) {
  const importing = busy === "import";

  return (
    <div className="xvt-col">
      <div className="card">
        <div className="card-title">
          <Download size={16} className="head-ic" /> Import from JIRA
          <span className="spacer" />
          <span className="badge cyan">Cloud</span>
        </div>

        <div className="two-col">
          <div className="field">
            <label className="field-label">Project ID</label>
            <input
              className="input"
              placeholder="e.g., DP"
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
            />
          </div>
          <div className="field">
            <label className="field-label">Story Key</label>
            <input
              className="input"
              placeholder="e.g., DP-1"
              value={storyKey}
              onChange={(e) => setStoryKey(e.target.value)}
            />
          </div>
        </div>

        <button className="btn" disabled={!storyKey || busy} onClick={onImport}>
          {importing ? (
            <Loader2 size={16} className="spin" />
          ) : (
            <CloudDownload size={16} />
          )}
          Import Business Rules & LOVs
        </button>
      </div>

      {(importing || spec) && (
        <div className="card" style={{ height: "500px", overflow: "auto" }}>
          <div className="card-title">
            <ListChecks size={16} /> Extracted Spec
            {importing && (
              <>
                <span className="spacer" />
                <span className="agent-status">
                  <Loader2 size={14} className="spin" /> importing…
                </span>
              </>
            )}
          </div>

          {importing ? (
            <div className="waiting">
              <div
                className="skel-grid"
                style={{ gridTemplateColumns: "1fr 1fr" }}
              >
                <div className="skel-tile" />
                <div className="skel-tile" />
              </div>
              <div className="skel-line w40" />
              <div className="skel-line w80" />
              <div className="skel-line w60" />
              <div className="skel-line w80" />
              <div className="skel-line w40" />
              <div className="skel-block" />
            </div>
          ) : (
            <>
              <div className="grid2">
                <div className="spec-box">
                  <div className="lbl">
                    <Database size={13} /> Source Table
                  </div>
                  <div className="val">{spec.source_table || "—"}</div>
                </div>
                <div className="spec-box">
                  <div className="lbl">
                    <ArrowRightLeft size={13} /> Target Table
                  </div>
                  <div className="val">{spec.target_table || "—"}</div>
                </div>
              </div>

              <div className="section-label">
                <Scale size={12} style={{ verticalAlign: -2 }} /> Business Rules
              </div>
              <ul className="list">
                {(spec.business_rules || []).map((r, i) => (
                  <li key={r.id || i}>
                    <span className="rnum">{i + 1}</span> {r.description}
                  </li>
                ))}
              </ul>

              <div className="section-label">
                <ClipboardList size={12} style={{ verticalAlign: -2 }} />
                &nbsp;LOV Mappings
              </div>
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Field</th>
                    <th>Source</th>
                    <th>Target</th>
                  </tr>
                </thead>
                <tbody>
                  {(spec.lovs || []).map((l, idx) => (
                    <tr key={idx}>
                      <td>{l.field}</td>
                      <td className="mono">{l.source_value}</td>
                      <td className="mono">{l.target_value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <button className="btn mt" disabled={busy} onClick={onGenerate}>
                {busy === "generate" ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <Sparkles size={16} />
                )}
                Generate SQL Test
                <ArrowRight size={15} />
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
