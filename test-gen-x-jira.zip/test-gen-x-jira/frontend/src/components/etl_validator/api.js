const BASE = import.meta?.env?.VITE_XRAY_API_BASE || "/api/etl";

async function post(path, body) {
  const resp = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.detail || `Request failed: ${resp.status}`);
  }
  return resp.json();
}

async function postStream(path, body, onEvent) {
  const resp = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!resp.ok) {
    const err = await resp.json().catch(() => ({}));
    throw new Error(err.detail || `Request failed: ${resp.status}`);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split("\n");

    for (const line of lines) {
      if (line.startsWith("data: ")) {
        const jsonStr = line.slice(6);
        if (jsonStr.trim()) {
          try {
            const event = JSON.parse(jsonStr);
            onEvent?.(event);
          } catch (e) {
            console.error("Failed to parse event:", jsonStr, e);
          }
        }
      }
    }
  }
}

export const etlApi = {
  /**
   * Import ETL specification from JIRA story.
   * Extracts business rules and LOV mappings using Mistral AI.
   * Returns: ETLExtractedSpec
   */
  importStory: (story_key) => post("/import", { story_key }),

  /**
   * Generate SQL validation script from ETL specification.
   * Creates SELECT queries for each business rule and LOV mapping.
   * Returns: ETLGenerateResponse
   */
  generate: (spec) => post("/generate", { spec }),

  /**
   * Execute SQL validation against target database.
   * Runs each test step and collects results.
   * Returns: ETLExecuteResponse
   */
  execute: (script) => post("/execute", script),

  /**
   * Push successful validation results to JIRA Xray.
   * Creates Test issue and Test Execution with results.
   * Returns: ETLPushResult
   */
  push: (story_key, execution, script) =>
    post("/push", { story_key, execution, script }),

  /**
   * Run complete ETL validation workflow with streaming events.
   * Orchestrates import → generate → execute → push.
   * Yields: ETLWorkflowEvent (Server-Sent Events)
   */
  runWorkflow: (story_key, onEvent) =>
    postStream("/workflow", { story_key }, onEvent),
};
