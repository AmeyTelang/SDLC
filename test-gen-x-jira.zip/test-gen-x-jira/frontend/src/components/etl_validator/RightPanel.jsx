import React from "react";
import { Network, CheckCircle2, Loader2 } from "lucide-react";

/**
 * RightPanel — Live Agent Workflow Stream.
 * Ordered flow: Orchestrator START → Generation steps → Execution steps →
 * Orchestrator END. Pure presentational.
 */
export default function RightPanel({ stream, progress, busy }) {
  const started = stream.length > 0;

  return (
    <div className="xvt-col">
      <div className="card">
        <div className="card-head">
          <span className="icon">
            <Network size={18} />
          </span>
          <h2>Agent Workflow Stream</h2>
          <span className="spacer" />
          {started && <span className="badge live">Live</span>}
        </div>

        {!started ? (
          <div className="card-body">
            <div className="wf-empty">
              The live agent workflow will appear here when you run a
              validation.
            </div>
          </div>
        ) : (
          <div className="card-body">
            <div className="wf-progress">
              <span
                style={{ width: `${progress}%` }}
                className={progress >= 100 ? "done" : ""}
              />
            </div>
            <div className="wf-timeline">
              {stream.map((w, i) => {
                const cls = w.agent;
                const isOrchestratorEnd =
                  w.agent === "orch" && w.status === "END";
                const inProgress =
                  !!busy && i === stream.length - 1 && !isOrchestratorEnd;
                const label =
                  w.agent === "orch"
                    ? "ORCHESTRATOR"
                    : w.agent === "gen"
                      ? "GEN AGENT"
                      : "EXEC AGENT";
                return (
                  <div
                    key={i}
                    className={`wf-node ${inProgress ? "active" : ""}`}
                  >
                    <div className="wf-rail">
                      <span
                        className={`wf-dot ${inProgress ? "loading" : "ok"}`}
                      >
                        {inProgress ? (
                          <Loader2 size={13} className="spin" />
                        ) : (
                          <CheckCircle2 size={14} />
                        )}
                      </span>
                      {i !== stream.length - 1 && (
                        <span className="wf-connector" />
                      )}
                    </div>
                    <div className="wf-content">
                      <div className="wf-row">
                        <span className={`agent-tag ${cls}`}>{label}</span>
                        <span className={`wf-phase ${w.status.toLowerCase()}`}>
                          {w.status}
                        </span>
                      </div>
                      <div className="wf-msg">
                        <span>{w.text}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
