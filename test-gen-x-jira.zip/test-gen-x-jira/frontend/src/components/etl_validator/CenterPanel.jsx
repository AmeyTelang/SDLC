import React from "react";
import {
  Sparkles,
  PlayCircle,
  UploadCloud,
  CheckCircle2,
  XCircle,
  Loader2,
  FileCode2,
  GitBranch,
  Copy,
  FileDown,
  Rocket,
  Cpu,
  ArrowRight,
  Bot,
} from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { atomDark } from "react-syntax-highlighter/dist/esm/styles/prism";

/**
 * CenterPanel — Agent output: intro/ready hero, Generation Agent panel,
 * and Execution Agent panel. Pure presentational.
 */
export default function CenterPanel({
  spec,
  script,
  scriptTab,
  setScriptTab,
  execution,
  pushResult,
  busy,
  error,
  onGenerate,
  onExecute,
  onPush,
}) {
  const showGenPanel = busy === "generate" || !!script;
  const showExecPanel = busy === "execute" || !!execution;
  const showIntro = !showGenPanel && !showExecPanel;

  return (
    <div className="xvt-col">
      {error && (
        <div className="alert error">
          <XCircle size={16} /> {error}
        </div>
      )}

      {/* Intro / ready panel — always present when no agent panel is active */}
      {showIntro && (
        <div className="empty">
          <div className="ico">
            <Rocket size={30} />
          </div>
          <h3>
            {spec
              ? "Spec imported — ready to generate"
              : "Agentic ETL Validation"}
          </h3>
          {spec ? (
            <>
              <p>
                Imported <b>{spec.story_key}</b> with{" "}
                <b>{(spec.business_rules || []).length} business rules</b>.
                Source <b>{spec.source_table || "—"}</b> → target{" "}
                <b>{spec.target_table || "—"}</b>. Click{" "}
                <b>Generate SQL Test</b> to synthesize the Playwright validation
                script.
              </p>
              <button
                className="btn hero-btn"
                disabled={busy}
                onClick={onGenerate}
              >
                {busy === "generate" ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <Sparkles size={16} />
                )}
                Generate SQL Test
                <ArrowRight size={15} />
              </button>
            </>
          ) : (
            <p>
              Import a <b>JIRA story</b>, and run. <b>Generation Agent</b>{" "}
              synthesizes a Playwright SQL test from the business rules & LOVs;{" "}
              <b>Execution Agent</b> validates the target table, and on success
              an <b>Xray Test</b> is created under the story with steps &
              results.
            </p>
          )}
        </div>
      )}

      {/* ---- Generation Agent panel ---- */}
      {showGenPanel && (
        <div className="card" style={{ height: "500px", overflow: "auto" }}>
          <div className="card-title">
            <Cpu size={16} className="cpu-color" />{" "}
            {busy === "generate" ? (
              <span>Agent X · Test Script Generator</span>
            ) : (
              <span>Agent X · Test Script Generated</span>
            )}
            <span className="spacer" />
            {busy === "generate" ? (
              <span className="agent-status">
                <Loader2 size={14} className="spin" /> generating test…
              </span>
            ) : (
              <span className="badge purple">
                <Bot size={9} />
                LLM
              </span>
            )}
          </div>

          {busy === "generate" && !script ? (
            <div className="waiting">
              <div className="skel-line w60" />
              <div className="skel-block" />
              <div className="skel-line w40" />
              <div className="skel-grid">
                <div className="skel-tile" />
                <div className="skel-tile" />
                <div className="skel-tile" />
                <div className="skel-tile" />
              </div>
            </div>
          ) : script ? (
            <>
              <div className="subtabs">
                <button
                  className={`subtab ${scriptTab === "steps" ? "active" : ""}`}
                  onClick={() => setScriptTab("steps")}
                >
                  Structured Steps
                </button>
                <button
                  className={`subtab ${scriptTab === "script" ? "active" : ""}`}
                  onClick={() => setScriptTab("script")}
                >
                  Playwright SQL
                </button>
              </div>

              {scriptTab === "script" ? (
                <>
                  <div className="code-head">
                    <FileCode2 size={13} />{" "}
                    <span className="small">
                      {spec?.target_table || "target"}_validation.sql
                    </span>
                    <span className="spacer" style={{ marginLeft: "auto" }} />
                    <button className="btn ghost sm">
                      <Copy size={13} /> Copy
                    </button>
                    <button className="btn ghost sm">
                      <FileDown size={13} /> .sql
                    </button>
                  </div>
                  <SyntaxHighlighter
                    language="sql"
                    style={atomDark}
                    customStyle={{ margin: 0, padding: "1rem" }}
                  >
                    {script.sql_script}
                  </SyntaxHighlighter>
                </>
              ) : (
                <table className="tbl">
                  <thead>
                    <tr>
                      <th className="col-index index-num">#</th>
                      <th>Action</th>
                      <th>Data (SQL)</th>
                      <th>Expected</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(script.test_steps || []).map((s) => (
                      <tr key={s.index}>
                        <td
                          className="col-index index-num"
                          style={{ color: "#22d3ee" }}
                        >
                          {s.index}
                        </td>
                        <td>{s.action}</td>
                        <td className="mono small">{s.data}</td>
                        <td className="small">{s.expected_result}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              <button
                style={{ visibility: "hidden" }}
                className="btn mt"
                disabled={busy}
                onClick={onExecute}
              >
                {busy === "execute" ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <PlayCircle size={16} />
                )}
                Execute Against Target Table
              </button>
            </>
          ) : null}
        </div>
      )}

      {/* ---- Execution Agent panel ---- */}
      {showExecPanel && (
        <div className="card" style={{ height: "500px", overflow: "auto" }}>
          <div className="card-title">
            <Cpu size={16} className="cpu-color" />
            {busy === "execute" ? (
              <span>Agent Y · Test Script Executor & Validator</span>
            ) : (
              <span>Agent Y · Test Script Executed & Validated</span>
            )}
            <span className="spacer" />
            {busy === "execute" ? (
              <span className="agent-status">
                <Loader2 size={14} className="spin" /> executing test…
              </span>
            ) : (
              <span className="badge green">LLM Verdict</span>
            )}
          </div>

          {busy === "execute" && !execution ? (
            <div className="waiting">
              <div className="skel-block tall" />
              <div className="skel-grid">
                <div className="skel-tile" />
                <div className="skel-tile" />
                <div className="skel-tile" />
                <div className="skel-tile" />
              </div>
              <div className="skel-line w80" />
              <div className="skel-line w60" />
            </div>
          ) : execution ? (
            <>
              <div
                className={`verdict-banner ${
                  execution.overall_status === "PASS" ? "" : "bad"
                }`}
              >
                <div className="ic">
                  {execution.overall_status === "PASS" ? (
                    <CheckCircle2 size={18} />
                  ) : (
                    <XCircle size={18} />
                  )}
                </div>
                <div>
                  <div className="t">
                    {execution.overall_status === "PASS" ? "Passed" : "Failed"}
                  </div>
                  <div className="s">
                    {execution.passed}/{execution.passed + execution.failed}{" "}
                    checks passed
                  </div>
                </div>
              </div>

              <div className="stats">
                <div className="stat total">
                  <div className="num">
                    {execution.passed + execution.failed}
                  </div>
                  <div className="lab">Total</div>
                </div>
                <div className="stat pass">
                  <div className="num">{execution.passed}</div>
                  <div className="lab">Passed</div>
                </div>
                <div className="stat fail">
                  <div className="num">{execution.failed}</div>
                  <div className="lab">Failed</div>
                </div>
                <div className="stat evi">
                  <div className="num">{(script?.test_steps || []).length}</div>
                  <div className="lab">Steps</div>
                </div>
              </div>

              <table className="tbl">
                <thead>
                  <tr>
                    <th className="col-index">#</th>
                    <th>Action</th>
                    <th>Expected</th>
                    <th>Actual</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {(execution.step_results || []).map((s) => (
                    <tr key={s.index}>
                      <td
                        className="index-num col-index"
                        style={{ color: "#22d3ee" }}
                      >
                        {s.index}
                      </td>
                      <td>{s.action}</td>
                      <td className="small">{s.expected_result}</td>
                      <td className="mono small">{s.actual_result}</td>
                      <td>
                        <span
                          className={`pill ${
                            s.status === "PASS"
                              ? "ok"
                              : s.status === "ERROR"
                                ? "err"
                                : "bad"
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <button
                className="btn mt"
                disabled={busy || execution.overall_status !== "PASS"}
                onClick={onPush}
                title={
                  execution.overall_status !== "PASS"
                    ? "Push enabled only on successful validation"
                    : ""
                }
              >
                {busy === "push" ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <UploadCloud size={16} />
                )}
                Create Xray Task & Push Results
              </button>
            </>
          ) : null}
        </div>
      )}
      {pushResult && (
        <div className="alert success mt">
          <GitBranch size={16} />
          Created Xray Test <b>&nbsp;{pushResult.test_key}&nbsp;</b> ( Execution{" "}
          {pushResult.test_execution_key}).{" "}
          <a href={pushResult.url} target="_blank" rel="noreferrer">
            Open in JIRA
          </a>
        </div>
      )}
    </div>
  );
}
