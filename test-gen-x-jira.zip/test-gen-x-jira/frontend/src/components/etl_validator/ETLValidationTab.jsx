import React, { useState } from "react";
import { etlApi } from "./api.js";
import LeftPanel from "./LeftPanel.jsx";
import CenterPanel from "./CenterPanel.jsx";
import RightPanel from "./RightPanel.jsx";
import "./ETLValidationTab.css";

/**
 * ETLValidationTab — Container / orchestrator.
 * Owns all state + agent workflow logic and stitches together the three
 * presentational panels (Left / Center / Right).
 *
 * Autonomous handoff:
 *   Generation Agent completes  ->  the executor is triggered automatically
 *   (no manual "Execute" click).
 *
 * Agent Workflow Stream order:
 *   Orchestrator START → Generation steps → Execution steps → Orchestrator END
 * JIRA import and Xray push (upload) are intentionally NOT streamed.
 * The stream resets at the start of every (re)generation iteration.
 */
export default function ETLValidationTab({ onHistoryAdd }) {
  const [projectId, setProjectId] = useState("");
  const [storyKey, setStoryKey] = useState("");
  const [spec, setSpec] = useState(null);
  const [script, setScript] = useState(null);
  const [scriptTab, setScriptTab] = useState("steps");
  const [execution, setExecution] = useState(null);
  const [pushResult, setPushResult] = useState(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [stream, setStream] = useState([]);
  const [progress, setProgress] = useState(0);

  const log = (agent, status, text, progressValue) => {
    setStream((s) => [
      ...s,
      {
        agent,
        status,
        text,
        progress:
          typeof progressValue === "number"
            ? progressValue
            : (s[s.length - 1]?.progress ?? 0),
      },
    ]);
    if (typeof progressValue === "number") setProgress(progressValue);
  };

  // ---- Execution Agent (auto-triggered after generation) ------------- #
  // Takes the freshly generated script directly to avoid stale state.
  const runExecution = async (activeScript) => {
    setBusy("execute");
    log(
      "exec",
      "START",
      "Execution Agent: running SQL against target table…",
      70,
    );
    const r = await etlApi.execute(activeScript);
    log(
      "exec",
      "ARTIFACT",
      `Execution Agent: ${r.overall_status} — ${r.passed}/${r.passed + r.failed} checks passed.`,
      90,
    );
    log("exec", "DONE", "Execution Agent: analysis complete.", 96);
    log("orch", "END", `Workflow finished · verdict: ${r.overall_status}`, 100);
    setExecution(r);
    setPushResult(null);
    return r;
  };

  // JIRA import — NOT part of the agent workflow stream.
  const doImport = async () => {
    setBusy("import");
    setError("");
    try {
      const s = await etlApi.importStory(storyKey.trim());
      console.log(s);
      setSpec(s);
      setScript(null);
      setExecution(null);
      setPushResult(null);
      setStream([]);
      setProgress(0);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  };

  // Generation → AUTO-EXECUTE. One continuous run, no manual intervention.
  const doGenerateAndExecute = async () => {
    setError("");
    setBusy("generate");
    // Reset the stream for a fresh iteration.
    setStream([]);
    setProgress(0);
    setScript(null);
    setExecution(null);
    setPushResult(null);
    try {
      log("orch", "START", `Workflow started · story: ${storyKey}`, 5);
      log(
        "gen",
        "PROCESS",
        "Generation Agent: synthesizing Playwright SQL test…",
        30,
      );

      const g = await etlApi.generate(spec);

      log(
        "gen",
        "ARTIFACT",
        `Generation Agent: produced ${(g.test_steps || []).length} steps + SQL script.`,
        55,
      );
      log(
        "gen",
        "HANDSHAKE",
        "Generation Agent: complete. Handing off to Execution Agent.",
        60,
      );

      // Ensure test_id (required by /execute) flows from the generated script.
      const genScript = { ...g, test_id: g?.test_id || `etl-${Date.now()}` };
      setScript(genScript);

      // >>> Auto-execute the executor as soon as generation completes. <<<
      await runExecution(genScript);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  };

  // Manual re-execute (optional) — reuses the current script.
  const doExecute = async () => {
    if (!script) return;
    setError("");
    try {
      await runExecution(script);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  };

  // Xray push (upload) — NOT part of the agent workflow stream.
  const doPush = async () => {
    setBusy("push");
    setError("");
    try {
      const p = await etlApi.push(storyKey.trim(), execution, script);
      const runEntry = {
        test_id: p.test_key || `${storyKey.trim()}-${Date.now()}`,
        project_id: projectId || "etl",
        project_name: projectId || "Backend ETL Studio",
        title: `ETL Validation — ${storyKey.trim()}`,
        language: "sql",
        status: execution.overall_status.toLowerCase(),
        total: execution.passed + execution.failed,
        passed: execution.passed,
        failed: execution.failed,
        evidence_count: (execution.step_results || []).length,
        generated_by: "Mistral AI",
        analyzed_by: "Execution Agent",
        evidence_mode: "sql",
        created_at: new Date().toISOString(),
        finished_at: new Date().toISOString(),
      };
      setPushResult(p);
      onHistoryAdd?.(runEntry);
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="xvt xvt-grid">
      <LeftPanel
        projectId={projectId}
        setProjectId={setProjectId}
        storyKey={storyKey}
        setStoryKey={setStoryKey}
        spec={spec}
        busy={busy}
        onImport={doImport}
        onGenerate={doGenerateAndExecute}
      />

      <CenterPanel
        spec={spec}
        script={script}
        scriptTab={scriptTab}
        setScriptTab={setScriptTab}
        execution={execution}
        pushResult={pushResult}
        busy={busy}
        error={error}
        onGenerate={doGenerateAndExecute}
        onExecute={doExecute}
        onPush={doPush}
      />

      <RightPanel stream={stream} progress={progress} busy={busy} />
    </div>
  );
}
