import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Bot, Mail, LogIn, Loader2, ShieldCheck, PenLine } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

/* ------------------------------------------------------------------
   Inline SVG background - Agentic AI Test Automation
   No external asset required; safe to copy as a single file to VDI.
------------------------------------------------------------------- */
function AgenticAIBackdrop() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 1600 900"
      preserveAspectRatio="xMidYMid slice"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        display: "block",
      }}
    >
      <defs>
        <linearGradient id="bgDeep" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#050A1C" />
          <stop offset="55%" stopColor="#0A1433" />
          <stop offset="100%" stopColor="#11082C" />
        </linearGradient>

        <radialGradient id="glowTop" cx="50%" cy="0%" r="70%">
          <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.30" />
          <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
        </radialGradient>

        <radialGradient id="glowLeft" cx="12%" cy="80%" r="42%">
          <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0.24" />
          <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
        </radialGradient>

        <radialGradient id="glowRight" cx="90%" cy="70%" r="42%">
          <stop offset="0%" stopColor="#22D3EE" stopOpacity="0.20" />
          <stop offset="100%" stopColor="#22D3EE" stopOpacity="0" />
        </radialGradient>

        <radialGradient id="agentCore" cx="50%" cy="34%" r="62%">
          <stop offset="0%" stopColor="#F2F7FF" />
          <stop offset="52%" stopColor="#7FB6FF" />
          <stop offset="100%" stopColor="#2A49BE" />
        </radialGradient>

        <radialGradient id="agentCoreAlt" cx="50%" cy="34%" r="62%">
          <stop offset="0%" stopColor="#F6EFFF" />
          <stop offset="52%" stopColor="#B79BFF" />
          <stop offset="100%" stopColor="#5326BE" />
        </radialGradient>

        <pattern
          id="circuit"
          width="120"
          height="120"
          patternUnits="userSpaceOnUse"
        >
          <path
            d="M0 30 H48 V78 H120 M30 0 V48 H78 V120 M78 48 H120 M0 96 H30 V120"
            fill="none"
            stroke="#6C9BFF"
            strokeOpacity="0.30"
            strokeWidth="1.4"
          />
          <circle cx="48" cy="30" r="2.8" fill="#6C9BFF" fillOpacity="0.55" />
          <circle cx="78" cy="48" r="2.8" fill="#A78BFA" fillOpacity="0.5" />
          <circle cx="30" cy="96" r="2.8" fill="#22D3EE" fillOpacity="0.5" />
        </pattern>

        <radialGradient id="vignette" cx="50%" cy="50%" r="60%">
          <stop offset="42%" stopColor="#05091C" stopOpacity="0.30" />
          <stop offset="100%" stopColor="#05091C" stopOpacity="0" />
        </radialGradient>

        <filter id="soften" x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="9" />
        </filter>
      </defs>

      {/* Base */}
      <rect width="1600" height="900" fill="url(#bgDeep)" />
      <rect width="1600" height="900" fill="url(#circuit)" />
      <rect width="1600" height="900" fill="url(#glowTop)" />
      <rect width="1600" height="900" fill="url(#glowLeft)" />
      <rect width="1600" height="900" fill="url(#glowRight)" />

      {/* Agent mesh connections */}
      <g
        stroke="#8CC0FF"
        strokeOpacity="0.85"
        strokeWidth="2.2"
        strokeDasharray="7 7"
        fill="none"
      >
        <path d="M250 280 L330 520 L470 700" />
        <path d="M330 520 L150 660" />
        <path d="M1180 250 L1310 470 L1200 720" />
        <path d="M1310 470 L1470 620" />
        <path d="M250 280 L1180 250" strokeOpacity="0.35" />
        <path d="M470 700 L1200 720" strokeOpacity="0.35" />
      </g>

      {/* Agent nodes */}
      <g>
        {[
          { x: 250, y: 280, r: 34, fill: "url(#agentCore)" },
          { x: 330, y: 520, r: 28, fill: "url(#agentCoreAlt)" },
          { x: 470, y: 700, r: 32, fill: "url(#agentCoreAlt)" },
          { x: 150, y: 660, r: 20, fill: "url(#agentCore)" },
          { x: 1180, y: 250, r: 30, fill: "url(#agentCoreAlt)" },
          { x: 1310, y: 470, r: 34, fill: "url(#agentCore)" },
          { x: 1200, y: 720, r: 28, fill: "url(#agentCore)" },
          { x: 1470, y: 620, r: 20, fill: "url(#agentCoreAlt)" },
        ].map((n, i) => (
          <g key={i}>
            <circle
              cx={n.x}
              cy={n.y}
              r={n.r * 1.7}
              fill="#4C7DF0"
              fillOpacity="0.22"
              filter="url(#soften)"
            />
            <ellipse
              cx={n.x}
              cy={n.y + n.r * 0.95}
              rx={n.r * 1.7}
              ry={n.r * 0.42}
              fill="none"
              stroke="#7DD3FC"
              strokeOpacity="0.85"
              strokeWidth="2"
            />
            <circle
              cx={n.x}
              cy={n.y}
              r={n.r}
              fill={n.fill}
              stroke="#CFE4FF"
              strokeOpacity="0.55"
              strokeWidth="1.2"
            />
            <circle
              cx={n.x - n.r * 0.32}
              cy={n.y - n.r * 0.1}
              r={n.r * 0.15}
              fill="#050A1C"
            />
            <circle
              cx={n.x + n.r * 0.32}
              cy={n.y - n.r * 0.1}
              r={n.r * 0.15}
              fill="#050A1C"
            />
          </g>
        ))}
      </g>

      {/* Floating test-result panels */}
      <g opacity="0.95">
        {[
          { x: 90, y: 90 },
          { x: 1300, y: 110 },
          { x: 1120, y: 640 },
        ].map((p, i) => (
          <g key={i} transform={`translate(${p.x} ${p.y})`}>
            <rect
              width="210"
              height="120"
              rx="12"
              fill="#0C1738"
              fillOpacity="0.95"
              stroke="#8CC0FF"
              strokeOpacity="0.7"
              strokeWidth="1.4"
            />
            {[0, 1, 2, 3].map((r) => (
              <g key={r} transform={`translate(18 ${24 + r * 24})`}>
                <circle
                  cx="6"
                  cy="0"
                  r="6"
                  fill={r === 3 ? "#FB7185" : "#34D399"}
                />
                <rect
                  x="22"
                  y="-4"
                  width={120 - r * 18}
                  height="8"
                  rx="4"
                  fill="#8CC0FF"
                  fillOpacity="0.8"
                />
              </g>
            ))}
          </g>
        ))}
      </g>

      {/* Code brackets */}
      <g
        fill="none"
        stroke="#C4B0FF"
        strokeOpacity="0.95"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M120 430 L96 452 L120 474" />
        <path d="M168 430 L192 452 L168 474" />
        <path d="M1428 300 L1404 322 L1428 344" />
        <path d="M1476 300 L1500 322 L1476 344" />
      </g>

      {/* Verified shields */}
      <g opacity="1">
        {[
          { x: 400, y: 380 },
          { x: 1100, y: 430 },
        ].map((s, i) => (
          <g key={i} transform={`translate(${s.x} ${s.y})`}>
            <path
              d="M0 0 L34 0 L34 22 C34 36 17 46 17 46 C17 46 0 36 0 22 Z"
              fill="#0C1738"
              fillOpacity="0.95"
              stroke="#38E0F5"
              strokeOpacity="0.95"
              strokeWidth="1.6"
            />
            <path
              d="M9 21 L15 27 L26 15"
              fill="none"
              stroke="#38E0F5"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </g>
        ))}
      </g>

      {/* Soft vignette - light touch so artwork stays crisp */}
      <rect width="1600" height="900" fill="url(#vignette)" />
    </svg>
  );
}

export default function TestGenXLogin() {
  const { login, loading } = useAuth();
  const [email, setEmail] = useState("");
  const [err, setErr] = useState(null);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setErr(null);
    try {
      await login(email.trim());
      navigate("/workspace", { replace: true });
    } catch (ex) {
      setErr(ex.message || "Sign-in failed.");
    }
  };

  return (
    <div
      className="login-shell"
      style={{
        position: "relative",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 24px 72px",
        overflow: "hidden",
        background: "#050A1C",
      }}
    >
      <AgenticAIBackdrop />

      {/* Light scrim only - no blur, so backdrop detail stays sharp.
          Card contrast is handled by the card itself. */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse 46% 62% at 50% 50%, rgba(5,9,28,0.72) 0%, rgba(5,9,28,0.28) 55%, rgba(5,9,28,0.12) 100%)",
        }}
      />

      <form
        className="login-card"
        onSubmit={submit}
        style={{
          position: "relative",
          zIndex: 1,
          width: "100%",
          maxWidth: "420px",
          padding: "32px 28px",
          borderRadius: "18px",
          background: "rgba(9, 15, 36, 0.95)",
          border: "1px solid rgba(140, 170, 255, 0.40)",
          boxShadow:
            "0 28px 70px rgba(0, 0, 0, 0.70), 0 0 0 1px rgba(76, 125, 240, 0.18)",
          color: "#e9edff",
        }}
      >
        <div className="login-brand">
          <span className="brand-mark">
            <Bot size={26} strokeWidth={2.2} />
          </span>
          <div>
            <h1>TestGenX</h1>
            <p>Test Automation Prototype</p>
          </div>
        </div>

        <h2 className="login-title">Sign in</h2>
        <p className="login-sub">
          Use your work email address. Your role determines the workspace you
          land in.
        </p>

        <label className="login-label" htmlFor="email">
          Work email
        </label>
        <div className="login-input">
          <Mail size={15} />
          <input
            id="email"
            type="email"
            autoFocus
            required
            placeholder="name@company.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        {err && <div className="login-error">{err}</div>}

        <button
          className="login-btn"
          type="submit"
          disabled={loading || !email}
        >
          {loading ? (
            <Loader2 size={16} className="spin" />
          ) : (
            <LogIn size={16} />
          )}
          {loading ? "Signing in…" : "Sign in"}
        </button>

        <div className="login-roles">
          <div className="role-chip">
            <PenLine size={14} />
            <div>
              <b>Test Engineer</b>
              <span>Import & generate test scripts</span>
            </div>
          </div>
          <div className="role-chip lead">
            <ShieldCheck size={14} />
            <div>
              <b>Test Lead</b>
              <span>Review, approve & execute</span>
            </div>
          </div>
        </div>

        <p className="login-foot">
          Demo accounts: <code>engineer@testgenx.io</code> ·{" "}
          <code>lead@testgenx.io</code>
        </p>
      </form>

      {/* Copyright panel - centred at the bottom of the page */}
      <div
        className="login-copyright"
        style={{
          position: "absolute",
          bottom: "22px",
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 2,
          padding: "9px 20px",
          borderRadius: "999px",
          background: "rgba(9, 15, 36, 0.82)",
          border: "1px solid rgba(140, 170, 255, 0.28)",
          boxShadow: "0 10px 28px rgba(0, 0, 0, 0.50)",
          color: "#9fb0de",
          fontSize: "11.5px",
          letterSpacing: "0.2px",
          whiteSpace: "nowrap",
          textAlign: "center",
        }}
      >
        © {new Date().getFullYear()} Tata Consultancy Services · All rights
        reserved.
      </div>
    </div>
  );
}
