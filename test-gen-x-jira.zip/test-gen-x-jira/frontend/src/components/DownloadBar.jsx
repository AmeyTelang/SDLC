import { useState } from "react";
import {
  FileText,
  FileCode,
  FileArchive,
  Camera,
  Loader2,
  ExternalLink,
} from "lucide-react";
import { downloads, download, reportUrl } from "../services/api.js";

export default function DownloadBar({ testId, title = "run" }) {
  const [busy, setBusy] = useState(null);
  const [err, setErr] = useState(null);
  const go = async (key, url, filename) => {
    setBusy(key);
    setErr(null);
    try {
      await download(url, filename);
    } catch (e) {
      setErr(e.message || "Download failed");
    } finally {
      setBusy(null);
    }
  };
  const safe = title.replace(/\s+/g, "_");
  return (
    <div className="dlbar">
      <button
        className="dl-btn primary"
        disabled={busy}
        onClick={() =>
          go(
            "pdf",
            downloads.report(testId, "pdf"),
            `Evidence_Report_${safe}.pdf`,
          )
        }
      >
        {busy === "pdf" ? (
          <Loader2 size={15} className="spin" />
        ) : (
          <FileText size={15} />
        )}{" "}
        Report (PDF)
      </button>
      <button
        className="dl-btn"
        disabled={busy}
        onClick={() =>
          go(
            "html",
            downloads.report(testId, "html"),
            `Evidence_Report_${safe}.html`,
          )
        }
      >
        {busy === "html" ? (
          <Loader2 size={15} className="spin" />
        ) : (
          <FileCode size={15} />
        )}{" "}
        Report (HTML)
      </button>
      <button
        className="dl-btn"
        disabled={busy}
        onClick={() =>
          go("ev", downloads.runEvidence(testId), `evidence_${safe}.zip`)
        }
      >
        {busy === "ev" ? (
          <Loader2 size={15} className="spin" />
        ) : (
          <Camera size={15} />
        )}{" "}
        Evidence (ZIP)
      </button>
      <button
        className="dl-btn"
        disabled={busy}
        onClick={() =>
          go("bundle", downloads.runBundle(testId), `testrun_${safe}.zip`)
        }
      >
        {busy === "bundle" ? (
          <Loader2 size={15} className="spin" />
        ) : (
          <FileArchive size={15} />
        )}{" "}
        Full bundle
      </button>
      <a
        className="dl-btn"
        href={`${reportUrl(testId, "html")}&download=false`}
        target="_blank"
        rel="noreferrer"
      >
        <ExternalLink size={15} /> Preview
      </a>
      {err && (
        <div className="report-error" style={{ flexBasis: "100%" }}>
          {err}
        </div>
      )}
    </div>
  );
}
