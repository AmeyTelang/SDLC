import {
  Inbox,
  ArrowRightToLine,
  Clock3,
  RefreshCw,
  FileCode2,
  BadgeCheck,
  User as UserIcon,
  RotateCcw,
} from "lucide-react";

function ago(iso) {
  if (!iso) return "";
  const s = Math.max(
    1,
    Math.round((Date.now() - new Date(iso).getTime()) / 1000),
  );
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

/**
 * TEST LEAD · queue of SUBMITTED scripts.
 *
 * Drafts never appear here — an item only arrives once the Test Engineer has
 * reviewed it and clicked "Submit for Review". Discard is gone: the Lead's
 * non-approval path is "send back for regeneration", handled in the gate.
 */
export default function ApprovalQueuePanel({
  items = [],
  activeTestId = null,
  loading = false,
  onPull,
  onRefresh,
  showAuthor = false,
}) {
  const pending = items.filter((i) => i.status === "pending");

  return (
    <div className="card queue-card">
      <div className="card-head">
        <span className="icon queue-icon">
          <Inbox size={18} />
        </span>
        <h2>Awaiting Review</h2>
        <span className="spacer" />
        {pending.length > 0 && (
          <span className="badge queue-count">{pending.length}</span>
        )}
        <button
          className="queue-refresh"
          onClick={onRefresh}
          title="Refresh queue"
          aria-label="Refresh review queue"
        >
          <RefreshCw size={13} className={loading ? "spin" : ""} />
        </button>
      </div>

      <div className="card-body queue-body">
        {items.length === 0 ? (
          <div className="queue-empty">
            <FileCode2 size={22} />
            <p>
              Nothing submitted. Scripts appear here once a Test Engineer has
              reviewed their draft and sent it for approval.
            </p>
          </div>
        ) : (
          <ul className="queue-list">
            {items.map((it) => {
              const isActive = it.test_id === activeTestId;
              const approved = it.status === "approved";
              const revised = (it.iteration || 1) > 1;

              return (
                <li
                  key={it.test_id}
                  className={`queue-item ${isActive ? "active" : ""} ${
                    approved ? "approved" : ""
                  }`}
                >
                  <div className="q-top">
                    <span className="q-title" title={it.title}>
                      {it.title || it.file_name}
                    </span>
                    <span className={`q-pill ${approved ? "ok" : ""}`}>
                      {approved ? (
                        <>
                          <BadgeCheck size={11} /> approved
                        </>
                      ) : (
                        <>
                          <Clock3 size={11} /> pending
                        </>
                      )}
                    </span>
                  </div>

                  <div className="q-meta">
                    {it.project_name ? `${it.project_name} · ` : ""}
                    {it.step_count} steps · iter {it.iteration} ·{" "}
                    {ago(it.submitted_at || it.created_at)}
                  </div>

                  {showAuthor && it.requested_by && (
                    <div className="q-meta">
                      <UserIcon size={10} style={{ verticalAlign: "-1px" }} />{" "}
                      {it.requested_by}
                    </div>
                  )}

                  {revised && (
                    <div className="q-revised">
                      <RotateCcw size={10} /> revised after your feedback
                    </div>
                  )}

                  {it.comment && !revised && (
                    <div className="q-feedback" title={it.comment}>
                      “{it.comment}”
                    </div>
                  )}

                  <div className="q-actions">
                    <button
                      className="q-pull"
                      onClick={() => onPull(it.test_id)}
                      disabled={isActive}
                    >
                      <ArrowRightToLine size={13} />
                      {isActive ? "In workspace" : "Pull into workspace"}
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
