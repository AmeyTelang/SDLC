import { useState } from "react";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Gauge,
  ChevronDown,
  ChevronRight,
  Check,
  X,
  Camera,
  Download,
  Cpu,
  Ban,
} from "lucide-react";
import EvidenceGallery from "./EvidenceGallery.jsx";
import DownloadBar from "./DownloadBar.jsx";
import PushToJira from "./PushToJira.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function ResultCard({ result, project, jiraIssueKey = "" }) {
  const [showLogs, setShowLogs] = useState(false);
  const [tab, setTab] = useState("results");
  const { can } = useAuth();

  const status = result.status;
  const Icon =
    status === "passed"
      ? CheckCircle2
      : status === "error"
        ? AlertTriangle
        : XCircle;

  const evCount = result.evidence?.length || 0;
  const jiraKey = jiraIssueKey || result.jira_issue_key || "";

  // ---------------------------------------------------------------
  // Push to JIRA requires BOTH a clean pass AND the jira.push
  // capability (Test Lead only).
  // ---------------------------------------------------------------
  const runPassed =
    status === "passed" &&
    (result.failed ?? 0) === 0 &&
    (result.total ?? 0) > 0;
  const canPushToJira = runPassed && can("jira.push");

  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Cpu size={18} />
        </span>
        <h2>Agent Y · Test Script Executed & Validated</h2>
        <span className="sub">
          <span
            className={`agent-tag ${
              result.analyzed_by === "llm" ? "execution" : "orchestrator"
            }`}
          >
            {result.analyzed_by === "llm" ? "LLM verdict" : "fallback verdict"}
          </span>
        </span>
      </div>

      <div className="tabs">
        <button
          className={tab === "results" ? "active" : ""}
          onClick={() => setTab("results")}
        >
          Results
        </button>
        <button
          className={tab === "evidence" ? "active" : ""}
          onClick={() => setTab("evidence")}
        >
          <Camera size={13} style={{ verticalAlign: "-2px", marginRight: 5 }} />
          Evidence{evCount ? ` (${evCount})` : ""}
        </button>
        <button
          className={tab === "downloads" ? "active" : ""}
          onClick={() => setTab("downloads")}
        >
          <Download
            size={13}
            style={{ verticalAlign: "-2px", marginRight: 5 }}
          />
          Downloads
        </button>
      </div>

      {tab === "evidence" ? (
        <div className="card-body">
          <EvidenceGallery evidence={result.evidence || []} />
        </div>
      ) : tab === "downloads" ? (
        <div className="card-body">
          <p className="dl-intro">
            Download this run&apos;s report, screenshots, or a complete bundle
            (script + result + evidence + report).
          </p>

          {result.test_id && (
            <DownloadBar
              testId={result.test_id}
              title={result.title || "run"}
            />
          )}

          {/* Push to JIRA — passed runs, Test Lead only. */}
          {result.test_id &&
            (canPushToJira ? (
              <div className="jira-push-row">
                <span className="jira-push-label">
                  Attach this run&apos;s report & evidence to a JIRA test:
                </span>
                <PushToJira
                  testId={result.test_id}
                  status={status}
                  defaultIssueKey={jiraKey}
                  projectKey={project?.jira_project_key}
                />
              </div>
            ) : (
              <div className="jira-push-blocked">
                <Ban size={14} />
                <span>
                  {runPassed ? (
                    <>
                      Pushing results to JIRA is a <b>Test Lead</b> action.
                    </>
                  ) : (
                    <>
                      Push to JIRA is available only for <b>passed</b> runs.
                      This run finished as <b>{status}</b>
                      {(result.failed ?? 0) > 0
                        ? ` with ${result.failed} failed check${
                            result.failed === 1 ? "" : "s"
                          }`
                        : ""}
                      .
                    </>
                  )}
                </span>
              </div>
            ))}
        </div>
      ) : (
        <div className="card-body">
          <div className={`verdict ${status}`}>
            <div className="v-icon">
              <Icon size={24} />
            </div>
            <div>
              <h3>{status}</h3>
              <p>
                {result.passed}/{result.total} checks passed ·{" "}
                {result.duration_ms} ms
              </p>
            </div>
          </div>

          <div className="metrics">
            <div className="metric">
              <div className="n">{result.total}</div>
              <div className="l">Total</div>
            </div>
            <div className="metric ok">
              <div className="n">{result.passed}</div>
              <div className="l">Passed</div>
            </div>
            <div className="metric bad">
              <div className="n">{result.failed}</div>
              <div className="l">Failed</div>
            </div>
            <div className="metric">
              <div className="n">{evCount}</div>
              <div className="l">Evidence</div>
            </div>
          </div>

          {result.step_results?.length > 0 && (
            <ul className="steps" style={{ marginBottom: 16 }}>
              {result.step_results.map((s, i) => (
                <li key={i} className="step-item">
                  <span
                    className="step-num"
                    style={{
                      background:
                        s.status === "passed" ? "var(--ok)" : "var(--fail)",
                    }}
                  >
                    {s.status === "passed" ? (
                      <Check size={13} />
                    ) : (
                      <X size={13} />
                    )}
                  </span>
                  <div>
                    <div className="txt">{s.name}</div>
                    {s.message && (
                      <span className="exp" style={{ color: "var(--fail)" }}>
                        {s.message}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}

          <div className="analysis">
            <span className="tag">
              <Gauge size={13} /> AI Verdict & Root-Cause: &nbsp;
            </span>
            {result.analysis}
          </div>

          {result.test_id && (
            <div style={{ marginTop: 16 }}>
              <DownloadBar
                testId={result.test_id}
                title={result.title || "run"}
              />
            </div>
          )}

          <button
            className="btn btn-ghost"
            style={{ marginTop: 14 }}
            onClick={() => setShowLogs((v) => !v)}
          >
            {showLogs ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
            {showLogs ? "Hide" : "Show"} execution logs
          </button>

          {showLogs && (
            <pre className="code" style={{ marginTop: 12 }}>
              {(result.stdout || "(no stdout)") +
                (result.stderr ? "\n--- STDERR ---\n" + result.stderr : "")}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}
