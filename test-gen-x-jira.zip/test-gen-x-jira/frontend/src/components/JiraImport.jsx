import { useEffect, useState } from "react";
import {
  Search,
  DownloadCloud,
  Download,
  ExternalLink,
  AlertTriangle,
  Loader2,
  RefreshCw,
  ListChecks,
} from "lucide-react";
import { jiraHealth, jiraListTests } from "../services/jiraApi.js";

export default function JiraImport({
  defaultProjectKey = "",
  defaultStoryKey = "",
  onImport,
}) {
  const [health, setHealth] = useState(null);
  const [projectKey, setProjectKey] = useState(defaultProjectKey);
  const [storyKey, setStoryKey] = useState(defaultStoryKey);
  const [tests, setTests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState("");

  useEffect(() => {
    jiraHealth()
      .then(setHealth)
      .catch(() => setHealth({ configured: false }));
  }, []);

  const load = async () => {
    if (!projectKey.trim() && !storyKey.trim()) return;
    setLoading(true);
    setError(null);
    setTests([]);
    try {
      const data = await jiraListTests({
        projectKey: projectKey.trim(),
        storyKey: storyKey.trim(),
      });
      setTests(data.tests || []);
      if ((data.tests || []).length === 0) {
        setError(
          storyKey.trim()
            ? `No tests linked to / under ${storyKey.trim()}. Link a Test to the story (or add it as a sub-task).`
            : `No "${health?.test_issuetype || "Test"}" issues found in ${projectKey.trim()}.`,
        );
      }
    } catch (e) {
      setError(e.message || "Failed to load JIRA tests");
    } finally {
      setLoading(false);
    }
  };

  const shown = tests.filter((t) => {
    if (!filter.trim()) return true;
    const q = filter.toLowerCase();
    return (
      t.key.toLowerCase().includes(q) ||
      (t.summary || "").toLowerCase().includes(q)
    );
  });

  const notConfigured = health && health.configured === false;
  const noXray =
    health && health.configured && health.xray_configured === false;

  return (
    <div className="wsj">
      <div className="wsj-card">
        <div className="wsj-head">
          <Download size={16} className="wsj-head-ic" />
          <h2>Import from JIRA</h2>
          <span className="wsj-badge">
            {health?.deployment ? health.deployment : "Cloud"}
          </span>
        </div>

        {notConfigured && (
          <div className="wsj-warn">
            <AlertTriangle size={16} style={{ flexShrink: 0, marginTop: 1 }} />
            <div>
              <b>JIRA not configured.</b> Set <code>JIRA_BASE_URL</code>,{" "}
              <code>JIRA_EMAIL</code> and <code>JIRA_API_TOKEN</code> (or{" "}
              <code>JIRA_PAT</code>) on the backend, then restart.
            </div>
          </div>
        )}

        {/* 2-level selection */}
        <div className="wsj-fields">
          <div className="wsj-field">
            <label className="wsj-label">Project ID</label>
            <input
              className="wsj-input"
              placeholder="e.g. DP-1"
              value={projectKey}
              onChange={(e) => setProjectKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && load()}
              disabled={notConfigured}
            />
          </div>
          <div className="wsj-field">
            <label className="wsj-label">
              Story ID <span className="wsj-opt">(optional)</span>
            </label>
            <input
              className="wsj-input"
              placeholder="e.g. DP-1"
              value={storyKey}
              onChange={(e) => setStoryKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && load()}
              disabled={notConfigured}
            />
          </div>
        </div>

        <button
          className="wsj-btn"
          onClick={load}
          disabled={
            loading || notConfigured || (!projectKey.trim() && !storyKey.trim())
          }
        >
          {loading ? (
            <Loader2 size={16} className="wsj-spin" />
          ) : (
            <Search size={16} />
          )}
          {loading ? "Finding tests…" : "Find Test(s)"}
        </button>

        {noXray && tests.length > 0 && (
          <div className="wsj-hint">
            <ListChecks size={13} /> Xray not configured — titles import, but
            manual-test steps won't. Set <code>XRAY_CLIENT_ID/SECRET</code> to
            pull step text.
          </div>
        )}

        {tests.length > 0 && (
          <div className="wsj-row">
            <input
              className="wsj-input"
              placeholder="Filter by key or summary…"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
            <button className="wsj-icon-btn" onClick={load} title="Refresh">
              <RefreshCw size={15} />
            </button>
          </div>
        )}

        {error && (
          <div className="wsj-error">
            <AlertTriangle size={14} /> {error}
          </div>
        )}

        {shown.length > 0 && (
          <div className="wsj-list">
            {shown.map((t) => (
              <div className="wsj-item" key={t.key}>
                <div className="wsj-item-main">
                  <div className="wsj-key">
                    <a href={t.url} target="_blank" rel="noreferrer">
                      {t.key} <ExternalLink size={11} />
                    </a>
                    {t.status && (
                      <span
                        className={`wsj-status s-${(t.status || "").toLowerCase().replace(/\s+/g, "-")}`}
                      >
                        {t.status}
                      </span>
                    )}
                    {t.steps?.length > 0 && (
                      <span
                        className="wsj-steps-chip"
                        title={`${t.steps.length} step(s) from Xray`}
                      >
                        <ListChecks size={11} /> {t.steps.length}
                      </span>
                    )}
                  </div>
                  <div className="wsj-summary">
                    {t.summary || "(no summary)"}
                  </div>
                </div>
                <button
                  className="wsj-icon-btn"
                  onClick={() => onImport?.(t)}
                  title="Import into TestGenX"
                >
                  <DownloadCloud size={15} />
                </button>
              </div>
            ))}
          </div>
        )}

        {!loading && !error && tests.length === 0 && !notConfigured && (
          <div className="wsj-empty">
            Enter a <b>Project key</b> (and optionally a <b>Story ID</b> like{" "}
            <code>DP-1</code>), then <b>Find tests</b>. Steps are pulled from
            each Xray test's manual steps.
          </div>
        )}
      </div>
    </div>
  );
}
