import {
  FolderGit2,
  FileEdit,
  Clock3,
  BadgeCheck,
  MessageSquareWarning,
  RefreshCw,
  Undo2,
  ArrowRightToLine,
  FileCode2,
  Ticket,
  XCircle,
  Inbox,
  User as UserIcon,
} from "lucide-react";
import ConfidenceBadge from "./ConfidenceBadge.jsx";

function ago(iso) {
  if (!iso) return "";
  const seconds = Math.max(
    1,
    Math.round((Date.now() - new Date(iso).getTime()) / 1000),
  );
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.round(seconds / 3600)}h ago`;
  return `${Math.round(seconds / 86400)}d ago`;
}

const STATE = {
  draft: { label: "draft", icon: FileEdit, cls: "draft" },
  pending: { label: "in review", icon: Clock3, cls: "" },
  changes_requested: {
    label: "changes requested",
    icon: MessageSquareWarning,
    cls: "returned",
  },
  approved: { label: "approved", icon: BadgeCheck, cls: "ok" },
  published: { label: "in JIRA", icon: Ticket, cls: "ok" },
  rejected: { label: "rejected", icon: XCircle, cls: "bad" },
};

/**
 * Shared work list.
 *
 * For the engineer it is "My Test Cases" - their own drafts and submissions.
 * For the lead it is the submitted queue, with the author shown. One component
 * because the card anatomy is identical; only the affordances differ.
 */
export default function MyTestCasesPanel({
  items = [],
  activeDraftId = null,
  loading = false,
  lead = false,
  onOpen,
  onWithdraw,
  onRefresh,
}) {
  const attention = lead
    ? items.filter((i) => i.status === "pending").length
    : items.filter((i) => ["draft", "changes_requested"].includes(i.status))
        .length;

  return (
    <div
      className={`card queue-card tcs-panel ${lead ? "lead" : ""}`}
      id="tcs-queue"
    >
      <div className="card-head">
        <span className="icon queue-icon">
          {lead ? <Inbox size={17} /> : <FolderGit2 size={17} />}
        </span>
        <h2>{lead ? "Awaiting Approval" : "My Test Cases"}</h2>
        <span className="spacer" />
        {attention > 0 && (
          <span className="badge queue-count">{attention}</span>
        )}
        <button
          className="queue-refresh"
          onClick={onRefresh}
          title="Refresh"
          aria-label="Refresh test cases"
        >
          <RefreshCw size={13} className={loading ? "spin" : ""} />
        </button>
      </div>

      <div className="card-body queue-body">
        {items.length === 0 ? (
          <div className="queue-empty">
            <FileCode2 size={22} />
            <p>
              {lead
                ? "Nothing submitted. Test cases appear here once a Test Engineer sends one for approval."
                : "Nothing yet. Import a story and generate a test case to get started."}
            </p>
          </div>
        ) : (
          <ul className="queue-list">
            {items.map((item) => {
              const meta = STATE[item.status] || STATE.pending;
              const Icon = meta.icon;
              const isActive = item.draft_id === activeDraftId;
              const openable = lead
                ? item.status === "pending" || item.status === "approved"
                : [
                    "draft",
                    "changes_requested",
                    "approved",
                    "published",
                  ].includes(item.status);

              return (
                <li
                  key={item.draft_id}
                  className={`queue-item ${isActive ? "active" : ""} ${meta.cls}`}
                >
                  <div className="q-top">
                    <span className="q-title" title={item.summary}>
                      {item.summary || item.story_key}
                    </span>
                    <span className={`q-pill ${meta.cls}`}>
                      <Icon size={11} /> {meta.label}
                    </span>
                  </div>

                  <div className="q-meta">
                    {item.story_key} · {item.step_count} steps · iter{" "}
                    {item.iteration} ·{" "}
                    {ago(item.submitted_at || item.created_at)}
                  </div>

                  <div className="tcs-panel__signals">
                    <ConfidenceBadge
                      band={item.confidence_band}
                      score={item.confidence}
                      compact
                    />
                    {item.edited && (
                      <span className="tcs-chip tcs-chip--edit">edited</span>
                    )}
                    {lead && item.requested_by && (
                      <span className="tcs-chip">
                        <UserIcon size={9} /> {item.requested_by}
                      </span>
                    )}
                  </div>

                  {item.status === "changes_requested" && item.feedback && (
                    <div className="q-feedback" title={item.feedback}>
                      “{item.feedback}”
                    </div>
                  )}

                  {item.test_key && (
                    <div className="q-meta approved-by">
                      Created as <b>{item.test_key}</b>
                    </div>
                  )}

                  <div className="q-actions">
                    {openable && (
                      <button
                        className="q-pull"
                        onClick={() => onOpen(item.draft_id)}
                        disabled={isActive}
                      >
                        <ArrowRightToLine size={13} />
                        {isActive
                          ? "In workspace"
                          : lead
                            ? "Pull into review"
                            : item.status === "changes_requested"
                              ? "Open & revise"
                              : "Open"}
                      </button>
                    )}
                    {!lead && item.status === "pending" && (
                      <button
                        className="q-withdraw"
                        onClick={() => onWithdraw(item.draft_id)}
                        title="Pull back before the Test Lead decides"
                      >
                        <Undo2 size={13} /> Withdraw
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
