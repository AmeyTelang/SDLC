import { ShieldCheck, ShieldAlert, ShieldQuestion } from "lucide-react";

const BANDS = {
  high: { label: "High confidence", icon: ShieldCheck, cls: "high" },
  medium: { label: "Needs review", icon: ShieldQuestion, cls: "medium" },
  low: { label: "Low confidence", icon: ShieldAlert, cls: "low" },
};

/**
 * Surfaces how much of a generated artefact rests on inference.
 *
 * This is deliberately prominent: a reviewer approving a low-confidence test
 * case should be making that choice knowingly, not discovering it later.
 */
export default function ConfidenceBadge({
  band = "low",
  score = 0,
  compact = false,
  title,
}) {
  const meta = BANDS[band] || BANDS.low;
  const Icon = meta.icon;
  const pct = Math.round((Number(score) || 0) * 100);

  return (
    <span
      className={`tcs-conf tcs-conf--${meta.cls} ${compact ? "tcs-conf--compact" : ""}`}
      title={title || `${meta.label} - model and coverage score ${pct}%`}
    >
      <Icon size={compact ? 11 : 13} />
      <b>{pct}%</b>
      {!compact && <span>{meta.label}</span>}
    </span>
  );
}

export function QualityPanel({ quality }) {
  if (!quality) return null;

  const rows = [
    {
      key: "Scenario coverage",
      value: `${Math.round((quality.scenario_coverage || 0) * 100)}%`,
      detail: `${(quality.covered_scenarios || []).length} of ${
        (quality.covered_scenarios || []).length +
        (quality.missing_scenarios || []).length
      } acceptance scenarios`,
    },
    {
      key: "Step completeness",
      value: `${Math.round((quality.completeness || 0) * 100)}%`,
      detail: "Steps with both an action and an observable expected result",
    },
    {
      key: "Grounding in criteria",
      value: `${Math.round((quality.grounding || 0) * 100)}%`,
      detail: "Step vocabulary traceable to the story text",
    },
    {
      key: "Model self-report",
      value: `${Math.round((quality.model_self_report || 0) * 100)}%`,
      detail: `Engine: ${quality.generated_by}${
        quality.repair_attempts
          ? ` · ${quality.repair_attempts} repair pass`
          : ""
      }`,
    },
  ];

  return (
    <div className="tcs-quality">
      <div className="tcs-quality__grid">
        {rows.map((row) => (
          <div className="tcs-quality__item" key={row.key}>
            <span className="tcs-quality__k">{row.key}</span>
            <span className="tcs-quality__v">{row.value}</span>
            <span className="tcs-quality__d">{row.detail}</span>
          </div>
        ))}
      </div>

      {(quality.missing_scenarios || []).length > 0 && (
        <div className="tcs-quality__miss">
          <b>Not covered by any step:</b>
          <ul>
            {quality.missing_scenarios.map((name) => (
              <li key={name}>{name}</li>
            ))}
          </ul>
        </div>
      )}

      {(quality.warnings || []).length > 0 && (
        <ul className="tcs-quality__warn">
          {quality.warnings.map((warning, i) => (
            <li key={i}>{warning}</li>
          ))}
        </ul>
      )}
    </div>
  );
}
