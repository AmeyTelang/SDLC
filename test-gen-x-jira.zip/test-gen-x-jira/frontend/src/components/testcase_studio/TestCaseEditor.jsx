import { useEffect, useMemo, useState } from "react";
import {
  Save,
  Loader2,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  Send,
  RotateCcw,
  PencilRuler,
  MessageSquareWarning,
  CheckCheck,
  AlertTriangle,
} from "lucide-react";
import ConfidenceBadge, { QualityPanel } from "./ConfidenceBadge.jsx";

const BLANK_STEP = {
  action: "",
  data: "",
  expected_result: "",
  source_scenario: "",
  confidence: 0,
  rationale: "Added manually.",
};

function reindex(steps) {
  return steps.map((step, i) => ({ ...step, index: i + 1 }));
}

const filled = (value) => Boolean((value || "").trim());

function listNumbers(numbers) {
  if (numbers.length === 1) return `Step ${numbers[0]}`;
  return `Steps ${numbers.slice(0, -1).join(", ")} and ${numbers[numbers.length - 1]}`;
}

/**
 * Step 2 of the authoring workflow: the editable test case.
 *
 * The generated content is a *proposal*. Everything is editable, and any edit
 * is recorded in the audit trail as a human intervention, so a published test
 * is always attributable to both the agent and the person who changed it.
 *
 * Validation mirrors the server contract exactly (`PUT /api/testcase/drafts/{id}`):
 * a step is only INVALID when it has no action, because that is the one field
 * Xray cannot store a step without. A missing expected result is a *warning*,
 * not a block - setup and navigation steps legitimately have an empty Result
 * column, and the quality score already penalises thin verification. Blocking
 * on it stranded the engineer with no way to submit and no way to tell which
 * row was at fault.
 */
export default function TestCaseEditor({
  record,
  onSave,
  onSubmit,
  onRegenerate,
  onDiscard,
  saving = false,
  busy = false,
  readOnly = false,
}) {
  const testCase = record?.test_case;
  const [draft, setDraft] = useState(testCase);
  const [note, setNote] = useState("");
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    setDraft(record?.test_case);
    setDirty(false);
    setNote("");
  }, [record?.draft_id, record?.iteration, record?.test_case]);

  const returned = record?.status === "changes_requested";
  const steps = draft?.steps || [];

  /* ----------------------------------------------------------------
     Blocking vs. advisory. Only a missing action can block, because
     only that breaks the server contract.
  ---------------------------------------------------------------- */
  const missingAction = useMemo(
    () =>
      steps.reduce(
        (acc, step, i) => (filled(step.action) ? acc : [...acc, i + 1]),
        [],
      ),
    [steps],
  );

  const missingResult = useMemo(
    () =>
      steps.reduce(
        (acc, step, i) =>
          filled(step.expected_result) ? acc : [...acc, i + 1],
        [],
      ),
    [steps],
  );

  const noSteps = steps.length === 0;
  const blocked = noSteps || missingAction.length > 0;
  const noVerification =
    steps.length > 0 && missingResult.length === steps.length;

  if (!record || !draft) return null;

  const patch = (changes) => {
    setDraft((prev) => ({ ...prev, ...changes }));
    setDirty(true);
  };

  const patchStep = (position, changes) => {
    setDraft((prev) => ({
      ...prev,
      steps: prev.steps.map((step, i) =>
        i === position ? { ...step, ...changes } : step,
      ),
    }));
    setDirty(true);
  };

  const addStep = () => {
    setDraft((prev) => ({
      ...prev,
      steps: reindex([...(prev.steps || []), { ...BLANK_STEP }]),
    }));
    setDirty(true);
  };

  const removeStep = (position) => {
    setDraft((prev) => ({
      ...prev,
      steps: reindex(prev.steps.filter((_, i) => i !== position)),
    }));
    setDirty(true);
  };

  const moveStep = (position, delta) => {
    const target = position + delta;
    if (target < 0 || target >= steps.length) return;
    setDraft((prev) => {
      const next = [...prev.steps];
      [next[position], next[target]] = [next[target], next[position]];
      return { ...prev, steps: reindex(next) };
    });
    setDirty(true);
  };

  const payload = () => ({
    summary: draft.summary,
    description: draft.description,
    precondition: draft.precondition,
    priority: draft.priority,
    labels: draft.labels,
    steps: reindex(draft.steps),
  });

  const save = async () => {
    await onSave(payload());
    setDirty(false);
  };

  /* Unsaved edits no longer disable Submit - they are saved first, then
     submitted, so there is no state where the button is inert with no
     explanation. */
  const submit = async () => {
    if (blocked) return;
    if (dirty) {
      await onSave(payload());
      setDirty(false);
    }
    await onSubmit(record.draft_id, note);
  };

  const focusStep = (n) => {
    const el = document.getElementById(`tcs-step-${n}`);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.querySelector("textarea")?.focus();
  };

  return (
    <div
      className={`card tcs-editor ${returned ? "returned" : ""}`}
      id="tcs-editor"
    >
      <div className="card-head">
        <span className={`icon tcs-editor__ico ${returned ? "returned" : ""}`}>
          {returned ? (
            <MessageSquareWarning size={18} />
          ) : (
            <PencilRuler size={18} />
          )}
        </span>
        <h2>{returned ? "Changes Requested" : "Generated Test Case"}</h2>
        <span className="spacer" />
        <ConfidenceBadge
          band={testCase?.quality?.band}
          score={testCase?.quality?.score}
        />
        <span className="badge tcs-iter">iteration {record.iteration}</span>
      </div>

      <div className="card-body tcs-editor__body">
        {returned && (
          <div className="tcs-rework">
            <b>{record.approver || "Test Lead"} asked for changes:</b>
            <p>{record.feedback}</p>
            <span>
              Edit the steps below and resubmit, or regenerate to let the agent
              address the feedback from the criteria again.
            </span>
          </div>
        )}

        {!returned && record.addressed_feedback && (
          <div className="tcs-resolved">
            <CheckCheck size={13} /> Previous feedback addressed in this
            revision.
          </div>
        )}

        <QualityPanel quality={testCase?.quality} />

        <div className="tcs-meta-grid">
          <label className="tcs-field">
            <span className="tcs-label">Test case summary</span>
            <input
              className="tcs-input"
              value={draft.summary || ""}
              onChange={(e) => patch({ summary: e.target.value })}
              disabled={readOnly}
            />
          </label>
          <label className="tcs-field tcs-field--narrow">
            <span className="tcs-label">Priority</span>
            <select
              className="tcs-input"
              value={draft.priority || "Medium"}
              onChange={(e) => patch({ priority: e.target.value })}
              disabled={readOnly}
            >
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </label>
        </div>

        <label className="tcs-field">
          <span className="tcs-label">Precondition</span>
          <input
            type="text"
            className="tcs-input"
            rows={2}
            value={draft.precondition || ""}
            onChange={(e) => patch({ precondition: e.target.value })}
            disabled={readOnly}
          />
        </label>

        <div className="tcs-steps-head">
          <span className="tcs-label">
            Test steps · {steps.length} step{steps.length === 1 ? "" : "s"}
            {missingResult.length > 0 && (
              <i className="tcs-label__sub">
                {" "}
                · {missingResult.length} without a verification
              </i>
            )}
          </span>
          {!readOnly && (
            <button className="tcs-mini" onClick={addStep}>
              <Plus size={13} /> Add step
            </button>
          )}
        </div>

        <div className="tcs-steps">
          <div className="tcs-steps__header">
            <span>#</span>
            <span>Action</span>
            <span>Data</span>
            <span>Expected result</span>
            <span />
          </div>

          {steps.map((step, position) => {
            const badAction = !filled(step.action);
            const softResult = !filled(step.expected_result);
            return (
              <div
                className={`tcs-step ${badAction ? "is-blocking" : ""} ${
                  !badAction && softResult ? "is-advisory" : ""
                }`}
                id={`tcs-step-${position + 1}`}
                key={position}
              >
                <div className="tcs-step__n">
                  <b>{position + 1}</b>
                  {/* <ConfidenceBadge
                    band={
                      step.confidence >= 0.85
                        ? "high"
                        : step.confidence >= 0.6
                          ? "medium"
                          : "low"
                    }
                    score={step.confidence}
                    compact
                    title={step.rationale || "Model confidence for this step"}
                  /> */}
                </div>

                <textarea
                  className={`tcs-cell ${badAction ? "tcs-cell--bad" : ""}`}
                  rows={2}
                  value={step.action || ""}
                  placeholder="Imperative instruction (required)"
                  onChange={(e) =>
                    patchStep(position, { action: e.target.value })
                  }
                  disabled={readOnly}
                />
                <textarea
                  className="tcs-cell"
                  rows={2}
                  value={step.data || ""}
                  placeholder="—"
                  onChange={(e) =>
                    patchStep(position, { data: e.target.value })
                  }
                  disabled={readOnly}
                />
                <textarea
                  className={`tcs-cell ${softResult ? "tcs-cell--soft" : ""}`}
                  rows={2}
                  value={step.expected_result || ""}
                  placeholder="Observable outcome (optional for setup steps)"
                  onChange={(e) =>
                    patchStep(position, { expected_result: e.target.value })
                  }
                  disabled={readOnly}
                />

                <div className="tcs-step__actions">
                  {!readOnly && (
                    <>
                      <button
                        onClick={() => moveStep(position, -1)}
                        disabled={position === 0}
                        aria-label="Move step up"
                      >
                        <ArrowUp size={12} />
                      </button>
                      <button
                        onClick={() => moveStep(position, 1)}
                        disabled={position === steps.length - 1}
                        aria-label="Move step down"
                      >
                        <ArrowDown size={12} />
                      </button>
                      <button
                        className="danger"
                        onClick={() => removeStep(position)}
                        aria-label="Delete step"
                      >
                        <Trash2 size={12} />
                      </button>
                    </>
                  )}
                  {step.source_scenario && (
                    <span className="tcs-src" title={step.source_scenario}>
                      {step.source_scenario}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Blocking: names the exact rows and jumps to them. */}
        {blocked && (
          <p className="tcs-invalid">
            <AlertTriangle size={13} />
            {noSteps ? (
              <span>Add at least one step before submitting.</span>
            ) : (
              <span>
                {listNumbers(missingAction)}{" "}
                {missingAction.length === 1 ? "has" : "have"} no action.
                {missingAction.map((n) => (
                  <button
                    className="tcs-jump"
                    key={n}
                    onClick={() => focusStep(n)}
                  >
                    Go to step {n}
                  </button>
                ))}
              </span>
            )}
          </p>
        )}

        {/* Advisory: never blocks. */}
        {!blocked && missingResult.length > 0 && (
          <p className="tcs-advisory">
            <AlertTriangle size={13} />
            <span>
              {listNumbers(missingResult)}{" "}
              {missingResult.length === 1 ? "has" : "have"} no expected result.
              That is valid for setup or navigation steps, but it lowers the
              verification score the Test Lead sees.
              {noVerification && (
                <b> No step verifies anything yet — add at least one.</b>
              )}
            </span>
          </p>
        )}

        {!readOnly && (
          <>
            <input
              className="tcs-input tcs-note"
              placeholder="Note for the reviewer (optional)…"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />

            <div className="tcs-actions">
              <button
                className="btn btn-ghost"
                onClick={save}
                disabled={saving || busy || !dirty}
              >
                {saving ? (
                  <Loader2 size={15} className="spin" />
                ) : (
                  <Save size={15} />
                )}
                {dirty ? "Save edits" : "Saved"}
              </button>

              <button
                className="btn btn-primary"
                onClick={submit}
                disabled={busy || saving || blocked}
                title={
                  blocked
                    ? "Every step needs an action before this can be submitted."
                    : dirty
                      ? "Your edits are saved automatically, then submitted."
                      : "Send to the Test Lead"
                }
              >
                {busy || saving ? (
                  <Loader2 size={15} className="spin" />
                ) : (
                  <Send size={15} />
                )}
                {dirty ? "Save & Submit for Approval" : "Submit for Approval"}
              </button>

              <button
                className="btn btn-ghost tcs-regen"
                onClick={() => onRegenerate(record.draft_id)}
                disabled={busy || saving}
              >
                <RotateCcw size={14} /> Regenerate
              </button>

              <button
                className="btn btn-ghost tcs-discard"
                onClick={() => onDiscard(record.draft_id)}
                disabled={busy || saving}
              >
                <Trash2 size={14} /> Discard
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
