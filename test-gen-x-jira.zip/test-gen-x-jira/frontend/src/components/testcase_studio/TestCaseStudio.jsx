import { useCallback, useEffect, useState } from "react";
import {
  FileText,
  ShieldCheck,
  Inbox,
  Ticket,
  AlertTriangle,
} from "lucide-react";

import StoryImportCard from "./StoryImportCard.jsx";
import TestCaseEditor from "./TestCaseEditor.jsx";
import TestCaseReviewGate from "./TestCaseReviewGate.jsx";
import MyTestCasesPanel from "./MyTestCasesPanel.jsx";
import { useAuth } from "../../context/AuthContext.jsx";
import { useNotifications } from "../../context/NotificationsContext.jsx";
import {
  approveTestCase,
  discardTestCase,
  fetchDraft,
  fetchQueueItem,
  generateTestCase,
  importStory,
  listMyTestCases,
  listTestCaseQueue,
  publishTestCase,
  rejectTestCase,
  saveDraft,
  sendBackTestCase,
  submitTestCase,
  testcaseHealth,
  withdrawTestCase,
} from "../../services/testcaseApi.js";

const POLL_MS = 20000;

/**
 * Test Case Studio - Story -> Xray test case authoring.
 *
 * One component serves both roles because the artefact and its audit story are
 * the same; what differs is which half of the workflow you are permitted to
 * drive. Capability checks come from the server-issued capability set, and
 * every action is re-authorised server-side.
 *
 *   Test Engineer : import story -> generate -> edit -> submit
 *   Test Lead     : pull -> approve | send back | reject -> create in JIRA
 *
 * Once created, the Xray test is pulled into the Web Studio through the
 * existing JIRA import flow, which is unchanged.
 */
export default function TestCaseStudio() {
  const { user, can, isLead } = useAuth();
  const { push: notify } = useNotifications();

  const [health, setHealth] = useState(null);
  const [projectKey, setProjectKey] = useState("");
  const [storyKey, setStoryKey] = useState("");
  const [story, setStory] = useState(null);

  const [record, setRecord] = useState(null);
  const [items, setItems] = useState([]);
  const [listLoading, setListLoading] = useState(false);

  const [importing, setImporting] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [busy, setBusy] = useState(false);
  const [publishing, setPublishing] = useState(false);

  const [error, setError] = useState(null);
  const [banner, setBanner] = useState(null);
  const [seen, setSeen] = useState(() => new Set());

  const canAuthor = can("testcase.generate");
  const canReview = can("testcase.review");
  const canPublish = can("testcase.publish");

  /* ---------------- data loading ---------------- */

  const refresh = useCallback(async () => {
    setListLoading(true);
    try {
      const next = isLead ? await listTestCaseQueue() : await listMyTestCases();
      setItems(Array.isArray(next) ? next : []);
    } finally {
      setListLoading(false);
    }
  }, [isLead]);

  useEffect(() => {
    testcaseHealth().then(setHealth);
    refresh();
    const timer = setInterval(refresh, POLL_MS);
    return () => clearInterval(timer);
  }, [refresh]);

  // Notify the lead about newly submitted test cases.
  useEffect(() => {
    if (!isLead) return;
    const fresh = items.filter(
      (i) => i.status === "pending" && !seen.has(i.draft_id),
    );
    if (fresh.length === 0) return;

    fresh.forEach((item) =>
      notify({
        kind: "approval_required",
        title:
          item.iteration > 1
            ? "Revised test case submitted"
            : "Test case submitted for approval",
        body: `“${item.summary}” · ${item.story_key} · ${item.step_count} steps · from ${
          item.requested_by || "a Test Engineer"
        }`,
        testId: item.draft_id,
      }),
    );

    setSeen((prev) => {
      const next = new Set(prev);
      fresh.forEach((item) => next.add(item.draft_id));
      return next;
    });
  }, [items, seen, isLead, notify]);

  const scrollTo = (elementId) =>
    setTimeout(
      () =>
        document
          .getElementById(elementId)
          ?.scrollIntoView({ behavior: "smooth", block: "center" }),
      80,
    );

  const guard = async (setFlag, fn) => {
    setFlag(true);
    setError(null);
    try {
      return await fn();
    } catch (e) {
      setError(e.message || "Something went wrong.");
      return null;
    } finally {
      setFlag(false);
    }
  };

  /* ---------------- engineer: import + generate ---------------- */

  const onImport = () =>
    guard(setImporting, async () => {
      setBanner(null);
      setRecord(null);
      const imported = await importStory({
        storyKey: storyKey.trim().toUpperCase(),
        projectKey: projectKey.trim().toUpperCase(),
      });
      setStory(imported);
      if (imported.project_key) setProjectKey(imported.project_key);
      return imported;
    });

  const runGeneration = (draftId = null, feedback = "") =>
    guard(setGenerating, async () => {
      if (!story) return null;
      const detail = await generateTestCase({
        storyKey: story.story_key,
        projectKey: story.project_key || projectKey,
        summary: story.summary,
        acceptanceCriteria: story.acceptance_criteria,
        rawDescription: story.raw_description,
        scenarioNames: (story.scenarios || []).map((s) => s.name),
        draftId,
        feedback,
      });
      setRecord(detail);
      await refresh();
      // scrollTo("tcs-editor");

      const band = detail.test_case?.quality?.band;
      if (band === "low") {
        setBanner({
          kind: "warn",
          text: "The generated test case scored low against the acceptance criteria. Review every step and edit before submitting.",
        });
      }
      return detail;
    });

  const onRegenerate = async (draftId) => {
    const current = record;
    if (!story && current?.story_key) {
      // Re-import so regeneration is grounded in the live story text.
      const imported = await guard(setImporting, () =>
        importStory({
          storyKey: current.story_key,
          projectKey: current.project_key,
        }),
      );
      if (!imported) return;
      setStory(imported);
    }
    await runGeneration(draftId, current?.feedback || "");
  };

  /* ---------------- engineer: edit / submit ---------------- */

  const onSave = (patch) =>
    guard(setSaving, async () => {
      const updated = await saveDraft(record.draft_id, patch);
      setRecord(updated);
      await refresh();
      setBanner({
        kind: "ok",
        text: "Your edits were saved and recorded in the audit trail.",
      });
      return updated;
    });

  const onSubmit = (draftId, note) =>
    guard(setBusy, async () => {
      await submitTestCase(draftId, note);
      setRecord(null);
      setStory(null);
      await refresh();
      setBanner({
        kind: "ok",
        text: "Submitted to the Test Lead. You will see it here again if changes are requested.",
      });
      return true;
    });

  const onWithdraw = (draftId) =>
    guard(setBusy, async () => {
      await withdrawTestCase(draftId);
      await refresh();
      setBanner({
        kind: "ok",
        text: "Submission withdrawn - it is a draft again.",
      });
      return true;
    });

  const onDiscard = (draftId) =>
    guard(setBusy, async () => {
      await discardTestCase(draftId);
      setRecord(null);
      await refresh();
      setBanner({ kind: "ok", text: "Draft discarded." });
      return true;
    });

  /* ---------------- open from the list ---------------- */

  const onOpen = (draftId) =>
    guard(setBusy, async () => {
      const detail = isLead
        ? await fetchQueueItem(draftId)
        : await fetchDraft(draftId);
      setRecord(detail);
      setStoryKey(detail.story_key);
      if (detail.project_key) setProjectKey(detail.project_key);
      scrollTo(isLead ? "tcs-gate" : "tcs-editor");
      return detail;
    });

  /* ---------------- lead: decisions ---------------- */

  const onApprove = (draftId, comment) =>
    guard(setBusy, async () => {
      await approveTestCase(draftId, comment);
      const detail = await fetchQueueItem(draftId);
      setRecord(detail);
      await refresh();
      setBanner({
        kind: "ok",
        text: "Approved. Create the Xray test in JIRA to complete the workflow.",
      });
      return detail;
    });

  const onSendBack = (draftId, feedback) =>
    guard(setBusy, async () => {
      await sendBackTestCase(draftId, feedback);
      setRecord(null);
      setSeen((prev) => {
        const next = new Set(prev);
        next.delete(draftId);
        return next;
      });
      await refresh();
      setBanner({
        kind: "warn",
        text: "Sent back to the Test Engineer. It will return here once resubmitted.",
      });
      return true;
    });

  const onReject = (draftId, comment) =>
    guard(setBusy, async () => {
      await rejectTestCase(draftId, comment);
      setRecord(null);
      await refresh();
      setBanner({
        kind: "warn",
        text: "Test case rejected and removed from the queue.",
      });
      return true;
    });

  const onPublish = (draftId) =>
    guard(setPublishing, async () => {
      const result = await publishTestCase(draftId, { projectKey });
      const detail = await fetchQueueItem(draftId);
      setRecord(detail);
      await refresh();

      notify({
        kind: "approved",
        title: `Xray test ${result.test_key} created`,
        body: `Created under ${result.story_key}. Pull it into the Web Studio via JIRA import.`,
        testId: draftId,
      });

      setBanner({
        kind: "ok",
        text: `${result.test_key} created under ${result.story_key} with ${result.steps_pushed} step(s).${
          result.linked
            ? ""
            : " It could not be linked to the story automatically - link it manually so the Web Studio import can find it."
        }`,
      });
      return result;
    });

  /* ---------------- render ---------------- */

  const notConfigured = health && health.configured === false;
  const showEditor =
    record && !isLead && ["draft", "changes_requested"].includes(record.status);
  const showGate = record && isLead;
  const showReadOnly =
    record &&
    !isLead &&
    !["draft", "changes_requested"].includes(record.status);

  return (
    <div className="container tcs">
      {/* <div className="tcs-head">
        <span className="tcs-head__ico">
          <Ticket size={20} />
        </span>
        <div>
          <h2>Test Case Studio</h2>
          <p>
            Turn a JIRA story&apos;s BDD acceptance criteria into a reviewed
            Xray test case.{" "}
            {isLead
              ? "Approve a submitted test case, then create it in JIRA under its story."
              : "Generate, refine and submit it for Test Lead approval."}{" "}
            Created tests are pulled into the Web Studio through the existing
            JIRA import.
          </p>
        </div>
      </div> */}

      {notConfigured && (
        <div className="tcs-warn tcs-warn--strong">
          <AlertTriangle size={15} />
          <span>
            <b>JIRA is not configured.</b> Set <code>JIRA_BASE_URL</code>,{" "}
            <code>JIRA_EMAIL</code> and <code>JIRA_API_TOKEN</code> (plus{" "}
            <code>XRAY_CLIENT_ID</code>/<code>XRAY_CLIENT_SECRET</code> to push
            manual steps), then restart the backend.
          </span>
        </div>
      )}

      {error && (
        <div className="card">
          <div className="card-body" style={{ color: "var(--fail)" }}>
            {error}
          </div>
        </div>
      )}

      {banner && (
        <div
          className={`ws-banner ${banner.kind === "warn" ? "rejected" : "queued"}`}
        >
          <Inbox size={15} />
          <span>{banner.text}</span>
          <button onClick={() => setBanner(null)} aria-label="Dismiss">
            ×
          </button>
        </div>
      )}

      <div className="grid-2">
        <aside className="col-left">
          {canAuthor && (
            <StoryImportCard
              projectKey={projectKey}
              setProjectKey={setProjectKey}
              storyKey={storyKey}
              setStoryKey={setStoryKey}
              story={story}
              onImport={onImport}
              onGenerate={() => runGeneration(record?.draft_id || null)}
              importing={importing}
              generating={generating}
              disabled={notConfigured}
            />
          )}

          <MyTestCasesPanel
            items={items}
            activeDraftId={record?.draft_id || null}
            loading={listLoading}
            lead={isLead}
            onOpen={onOpen}
            onWithdraw={onWithdraw}
            onRefresh={refresh}
          />
        </aside>

        <main className="col-mid tcs-main">
          {!record && (
            <div className="card">
              <div className="empty">
                <div className="ico">
                  {isLead ? <ShieldCheck size={28} /> : <FileText size={28} />}
                </div>
                <h3>{isLead ? "Nothing in review" : "Start from a story"}</h3>
                <p>
                  {isLead ? (
                    <>
                      Test cases appear in the queue once a Test Engineer
                      submits one. Pull it in to read every step, then{" "}
                      <b>approve</b> to release creation in JIRA or{" "}
                      <b>send it back</b> with feedback.
                    </>
                  ) : (
                    <>
                      Enter a <b>Story ID</b> to pull its acceptance criteria.
                      The parser shows exactly which scenarios it found, then
                      the Story Agent turns each one into Xray{" "}
                      <b>Action / Data / Expected Result</b> steps you can edit
                      before submitting.
                    </>
                  )}
                </p>
              </div>
            </div>
          )}

          {showEditor && (
            <TestCaseEditor
              record={record}
              onSave={onSave}
              onSubmit={onSubmit}
              onRegenerate={onRegenerate}
              onDiscard={onDiscard}
              saving={saving}
              busy={busy || generating}
            />
          )}

          {showReadOnly && (
            <TestCaseEditor record={record} readOnly onSave={() => {}} />
          )}

          {showGate && canReview && (
            <TestCaseReviewGate
              record={record}
              onApprove={onApprove}
              onSendBack={onSendBack}
              onReject={onReject}
              onPublish={canPublish ? onPublish : undefined}
              onClose={() => setRecord(null)}
              busy={busy}
              publishing={publishing}
            />
          )}
        </main>
      </div>
    </div>
  );
}
