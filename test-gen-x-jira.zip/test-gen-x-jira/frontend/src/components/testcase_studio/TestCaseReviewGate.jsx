import { useState } from "react";
import {
  ShieldCheck,
  ThumbsUp,
  RotateCcw,
  XCircle,
  Loader2,
  Ticket,
  ExternalLink,
  History,
  PauseCircle,
  X,
  AlertTriangle,
  ListChecks,
  FileText,
  CheckCircle2,
} from "lucide-react";
import ConfidenceBadge from "./ConfidenceBadge.jsx";

const ACTION_LABEL = {
  generated: "generated the test case",
  revised: "regenerated the test case",
  edited: "edited the test case",
  submitted: "submitted it for approval",
  sent_back: "sent it back for rework",
  approved: "approved it",
  rejected: "rejected it",
  withdrawn: "withdrew the submission",
  published: "created the Xray test in JIRA",
};

/* The generator and the editor are tolerant about field names; the review
 * screen has to be too, otherwise a lead silently reviews a blank table. */
const stepAction = (s) => s?.action ?? s?.step ?? s?.description ?? "";
const stepData = (s) => s?.data ?? s?.test_data ?? s?.input ?? "";
const stepExpected = (s) =>
  s?.expected_result ?? s?.expected ?? s?.result ?? s?.outcome ?? "";

/**
 * TEST LEAD - review gate for a submitted test case.
 *
 * Approval and creation are two distinct acts. Approving records the decision;
 * only then does "Create in JIRA" appear. The server enforces the same order,
 * so the button's absence is a convenience, not the control.
 *
 * The lead must be able to read what they are signing off on, so the full test
 * case - title, description, acceptance criteria and every Action / Data /
 * Expected Result step - is rendered above the decision controls. If the
 * payload carries no steps, the decision controls are withheld rather than
 * inviting a blind approval.
 */
export default function TestCaseReviewGate({
  record,
  onApprove,
  onSendBack,
  onReject,
  onPublish,
  onClose,
  busy = false,
  publishing = false,
}) {
  const [comment, setComment] = useState("");
  const [mode, setMode] = useState(null); // null | "sendback" | "reject"
  const [showHistory, setShowHistory] = useState(false);

  if (!record) return null;

  const testCase = record.test_case || {};
  const quality = testCase.quality;
  const history = record.history || [];
  const steps = Array.isArray(testCase.steps) ? testCase.steps : [];
  const criteria = Array.isArray(record.acceptance_criteria)
    ? record.acceptance_criteria
    : Array.isArray(testCase.acceptance_criteria)
      ? testCase.acceptance_criteria
      : [];
  const missing = quality?.missing_scenarios || [];

  const approved = record.status === "approved";
  const published = record.status === "published";
  const lowConfidence = quality?.band === "low";
  const needsComment = mode === "sendback" && !comment.trim();

  /* No steps means nothing reviewable arrived - the lead is told plainly and
   * approval is blocked; send back and reject stay available. */
  const noSteps = steps.length === 0;
  const title = testCase.title || record.summary || record.story_key;

  return (
    <div className="card tcs-gate" id="tcs-gate">
      <div className="card-head">
        <span className="icon tcs-gate__ico">
          <ShieldCheck size={18} />
        </span>
        <h2>{published ? "Created in JIRA" : "Review & Approve Test Case"}</h2>
        <span className="spacer" />
        {!published && (
          <span className="badge gate-badge">
            <PauseCircle size={12} />{" "}
            {approved ? "Ready to create" : "Awaiting decision"}
          </span>
        )}
        <button
          className="gate-close"
          onClick={onClose}
          aria-label="Return to queue"
        >
          <X size={14} />
        </button>
      </div>

      <div className="card-body tcs-gate__body">
        <p className="tcs-gate__note">
          Reviewing <b>{record.summary || record.story_key}</b> ·{" "}
          {record.step_count} step{record.step_count === 1 ? "" : "s"} ·
          iteration {record.iteration} · submitted by{" "}
          <b>{record.requested_by}</b> from story <b>{record.story_key}</b>.
        </p>

        <div className="tcs-gate__signals">
          <ConfidenceBadge band={quality?.band} score={quality?.score} />
          {record.edited && (
            <span className="tcs-chip tcs-chip--edit">manually edited</span>
          )}
          {missing.length > 0 && (
            <span className="tcs-chip tcs-chip--warn">
              {missing.length} scenario(s) uncovered
            </span>
          )}
        </div>

        {lowConfidence && !published && (
          <div className="tcs-warn tcs-warn--strong">
            <AlertTriangle size={14} />
            <span>
              This test case scored low against its acceptance criteria. Read
              every step before approving - approval is recorded against your
              name and releases creation in JIRA.
            </span>
          </div>
        )}

        {/* ------------- acceptance criteria (what it must cover) ------------- */}
        {criteria.length > 0 && (
          <section className="tcs-review-block">
            <h3 className="tcs-review-block__head">
              <ListChecks size={14} /> Acceptance criteria
              <span className="tcs-review-block__count">{criteria.length}</span>
            </h3>
            <ul className="tcs-ac-list">
              {criteria.map((ac, i) => (
                <li key={i}>
                  {typeof ac === "string" ? ac : ac?.text || ac?.name}
                </li>
              ))}
            </ul>
            {missing.length > 0 && (
              <p className="tcs-uncovered">
                <AlertTriangle size={12} /> Not covered by any step:{" "}
                {missing.join(", ")}
              </p>
            )}
          </section>
        )}

        {/* ------------- the test case itself ------------- */}
        <section className="tcs-review-block">
          <h3 className="tcs-review-block__head">
            <FileText size={14} /> Test case
            {record.test_key && (
              <span className="tcs-review-block__count">{record.test_key}</span>
            )}
          </h3>
          <p className="tcs-tc-title">{title}</p>
          {testCase.description && (
            <p className="tcs-tc-desc">{testCase.description}</p>
          )}
          {testCase.precondition && (
            <p className="tcs-tc-pre">
              <b>Precondition:</b> {testCase.precondition}
            </p>
          )}
        </section>

        {/* ------------- steps under review ------------- */}
        <section className="tcs-review-block">
          <h3 className="tcs-review-block__head">
            <CheckCircle2 size={14} /> Test steps
            {!noSteps && (
              <span className="tcs-review-block__count">{steps.length}</span>
            )}
          </h3>

          {noSteps ? (
            <div className="tcs-steps-empty">
              <AlertTriangle size={20} />
              <div>
                <b>No steps arrived with this submission.</b>
                <span>
                  There is nothing to review, so approval is disabled. Send it
                  back to <b>{record.requested_by || "the Test Engineer"}</b> to
                  regenerate, or reject it. If the engineer can see steps on
                  their draft, the queue payload is dropping{" "}
                  <code>test_case.steps</code> - check the queue endpoint before
                  deciding.
                </span>
              </div>
            </div>
          ) : (
            <div className="tcs-steps-wrap">
              <table className="tcs-steps-table">
                <thead>
                  <tr>
                    <th className="tcs-col-n">#</th>
                    <th>Action</th>
                    <th>Data</th>
                    <th>Expected result</th>
                  </tr>
                </thead>
                <tbody>
                  {steps.map((step, i) => {
                    const expected = stepExpected(step);
                    return (
                      <tr
                        key={step.id || i}
                        className={expected ? "" : "tcs-row--gap"}
                      >
                        <td className="tcs-col-n">{i + 1}</td>
                        <td>
                          {stepAction(step) || <i className="tcs-muted">—</i>}
                        </td>
                        <td>
                          {stepData(step) || <i className="tcs-muted">—</i>}
                        </td>
                        <td>
                          {expected || (
                            <span className="tcs-missing-exp">
                              <AlertTriangle size={11} /> no expected result
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        {history.length > 0 && (
          <>
            <button
              className="tcs-toggle"
              onClick={() => setShowHistory((v) => !v)}
              aria-expanded={showHistory}
            >
              <History size={13} />
              {showHistory ? "Hide" : "Show"} review history ({history.length})
            </button>
            {showHistory && (
              <ul className="tcs-history">
                {history.map((event, i) => (
                  <li key={i}>
                    <span className={`tcs-dot ${event.action}`} />
                    <span>
                      <b>{event.actor}</b>{" "}
                      {ACTION_LABEL[event.action] || event.action}
                      <i> · iteration {event.iteration}</i>
                      {event.comment && <em>“{event.comment}”</em>}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}

        {published ? (
          <div className="tcs-published">
            <Ticket size={16} />
            <div>
              <b>
                <a href={record.test_url} target="_blank" rel="noreferrer">
                  {record.test_key} <ExternalLink size={11} />
                </a>
              </b>
              <span>
                Created under {record.story_key}. It can now be pulled into the
                Web Studio through the existing JIRA import.
              </span>
            </div>
          </div>
        ) : (
          <>
            <input
              className="tcs-input"
              value={comment}
              placeholder={
                mode === "sendback"
                  ? "What needs to change? (required)"
                  : mode === "reject"
                    ? "Why is this being rejected? (optional)"
                    : "Reviewer comment (optional)…"
              }
              onChange={(e) => setComment(e.target.value)}
            />
            {needsComment && (
              <p className="tcs-invalid">
                Tell the engineer what to fix - it is sent back with the test
                case.
              </p>
            )}

            <div className="tcs-actions">
              {mode === "sendback" ? (
                <>
                  <button
                    className="btn tcs-sendback"
                    disabled={busy || needsComment}
                    onClick={() => onSendBack(record.draft_id, comment.trim())}
                  >
                    {busy ? (
                      <Loader2 size={15} className="spin" />
                    ) : (
                      <RotateCcw size={15} />
                    )}
                    Send back for rework
                  </button>
                  <button
                    className="btn btn-ghost"
                    disabled={busy}
                    onClick={() => setMode(null)}
                  >
                    Cancel
                  </button>
                </>
              ) : mode === "reject" ? (
                <>
                  <button
                    className="btn tcs-reject"
                    disabled={busy}
                    onClick={() => onReject(record.draft_id, comment.trim())}
                  >
                    {busy ? (
                      <Loader2 size={15} className="spin" />
                    ) : (
                      <XCircle size={15} />
                    )}
                    Confirm rejection
                  </button>
                  <button
                    className="btn btn-ghost"
                    disabled={busy}
                    onClick={() => setMode(null)}
                  >
                    Cancel
                  </button>
                </>
              ) : approved ? (
                <>
                  <button
                    className="btn btn-primary tcs-publish"
                    disabled={publishing}
                    onClick={() => onPublish(record.draft_id)}
                  >
                    {publishing ? (
                      <Loader2 size={16} className="spin" />
                    ) : (
                      <Ticket size={16} />
                    )}
                    {publishing
                      ? "Creating in JIRA…"
                      : `Create Xray Test under ${record.story_key}`}
                  </button>
                  <span className="tcs-approved-by">
                    Approved by {record.approver}
                  </span>
                </>
              ) : (
                <>
                  <button
                    className="btn btn-primary tcs-approve"
                    disabled={busy || noSteps}
                    title={
                      noSteps
                        ? "There are no steps to approve"
                        : "Record your approval"
                    }
                    onClick={() => onApprove(record.draft_id, comment)}
                  >
                    {busy ? (
                      <Loader2 size={16} className="spin" />
                    ) : (
                      <ThumbsUp size={16} />
                    )}
                    Approve
                  </button>
                  <button
                    className="btn btn-ghost tcs-sendback-toggle"
                    disabled={busy}
                    onClick={() => setMode("sendback")}
                  >
                    <RotateCcw size={15} /> Send back
                  </button>
                  <button
                    className="btn btn-ghost tcs-reject-toggle"
                    disabled={busy}
                    onClick={() => setMode("reject")}
                  >
                    <XCircle size={15} /> Reject
                  </button>
                </>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
