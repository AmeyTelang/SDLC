import { useState } from "react";
import {
  Search,
  Loader2,
  AlertTriangle,
  ExternalLink,
  FileText,
  ListTree,
  Sparkles,
} from "lucide-react";

/**
 * Step 1 of the authoring workflow: pull the story and show exactly what the
 * deterministic parser found in its acceptance criteria.
 *
 * The parse is shown BEFORE generation on purpose - if the parser missed a
 * scenario, the engineer sees it here rather than discovering a gap in the
 * generated test case.
 */
export default function StoryImportCard({
  projectKey,
  setProjectKey,
  storyKey,
  setStoryKey,
  story,
  onImport,
  onGenerate,
  importing = false,
  generating = false,
  disabled = false,
}) {
  const [expanded, setExpanded] = useState(true);
  const canImport = storyKey.trim().length > 0 && !importing && !disabled;
  const scenarios = story?.scenarios || [];

  return (
    <div className="card tcs-import">
      <div className="card-head">
        <span className="icon tcs-import__ico">
          <FileText size={18} />
        </span>
        <h2>Import Story</h2>
        <span className="spacer" />
        {story?.status && <span className="tcs-chip">{story.status}</span>}
      </div>

      <div className="card-body">
        <div className="tcs-fields">
          <div className="tcs-field">
            <label className="tcs-label" htmlFor="tcs-project">
              Project ID <span className="tcs-opt">(optional)</span>
            </label>
            <input
              id="tcs-project"
              className="tcs-input"
              placeholder="e.g. DP"
              value={projectKey}
              onChange={(e) => setProjectKey(e.target.value)}
              disabled={disabled}
            />
          </div>
          <div className="tcs-field">
            <label className="tcs-label" htmlFor="tcs-story">
              Story ID
            </label>
            <input
              id="tcs-story"
              className="tcs-input"
              placeholder="e.g. DP-14"
              value={storyKey}
              onChange={(e) => setStoryKey(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && canImport && onImport()}
              disabled={disabled}
            />
          </div>
        </div>

        <button
          className="btn btn-primary"
          onClick={onImport}
          disabled={!canImport}
        >
          {importing ? (
            <Loader2 size={16} className="spin" />
          ) : (
            <Search size={16} />
          )}
          {importing ? "Reading story…" : "Import Story"}
        </button>

        {story && (
          <div className="tcs-story">
            <div className="tcs-story__head">
              <a href={story.url} target="_blank" rel="noreferrer">
                {story.story_key} <ExternalLink size={11} />
              </a>
              {/* <span className="tcs-story__summary">{story.summary}</span> */}
            </div>

            {/* {(story.parse_warnings || []).map((warning, i) => (
              <div className="tcs-warn" key={i}>
                <AlertTriangle size={14} />
                <span>{warning}</span>
              </div>
            ))} */}

            {/* <button
              className="tcs-toggle"
              onClick={() => setExpanded((v) => !v)}
              aria-expanded={expanded}
            >
              <ListTree size={13} />
              {expanded ? "Hide" : "Show"} parsed acceptance criteria (
              {story.scenario_count} scenario
              {story.scenario_count === 1 ? "" : "s"})
            </button> */}

            {expanded && (
              <div className="tcs-scenarios">
                {(story.background || []).length > 0 && (
                  <div className="tcs-scenario tcs-scenario--bg">
                    <b>Background</b>
                    <ul>
                      {story.background.map((step, i) => (
                        <li key={i}>
                          <em>{step.raw_keyword}</em> {step.text}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {scenarios.length === 0 ? (
                  <p className="tcs-empty-note">
                    No Given/When/Then scenarios were found. Generation will
                    interpret the criteria as free text and report lower
                    confidence.
                  </p>
                ) : (
                  scenarios.map((scenario, i) => (
                    <div className="tcs-scenario" key={`${scenario.name}-${i}`}>
                      <b>{scenario.name}</b>
                      {scenario.example && (
                        <span className="tcs-example">
                          {Object.entries(scenario.example)
                            .map(([k, v]) => `${k}=${v}`)
                            .join(", ")}
                        </span>
                      )}
                      <ul>
                        {scenario.steps.map((step, j) => (
                          <li key={j} className={`kw-${step.keyword}`}>
                            <em>{step.raw_keyword}</em> {step.text}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))
                )}
              </div>
            )}

            <button
              className="btn btn-primary tcs-generate"
              onClick={onGenerate}
              disabled={generating || disabled || !story.acceptance_criteria}
            >
              {generating ? (
                <Loader2 size={16} className="spin" />
              ) : (
                <Sparkles size={16} />
              )}
              {generating
                ? "Synthesising test case…"
                : "Generate Xray Test Case"}
            </button>

            {!story.acceptance_criteria && (
              <p className="tcs-empty-note">
                This story has no acceptance criteria to derive a test case
                from.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
