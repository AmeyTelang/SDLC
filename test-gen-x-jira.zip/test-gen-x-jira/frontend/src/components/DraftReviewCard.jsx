import { useState } from "react";
import {
  ClipboardCheck,
  Send,
  Trash2,
  Loader2,
  PencilRuler,
  MessageSquareWarning,
} from "lucide-react";

/**
 * TEST ENGINEER · self-review card.
 *
 * Delta: when the Test Lead has sent the script back, the primary action is
 * **Revise & Regenerate** — it does NOT re-run generation directly. It opens
 * the test-steps popup pre-filled with the original steps so the engineer can
 * edit them first, with the Lead's feedback pinned above the steps box.
 */
export default function DraftReviewCard({
  draft, // { test_id, title, step_count, iteration, status, feedback, approver }
  onSubmit,
  onReviseAndRegenerate,
  onDiscard,
  busy = false,
}) {
  const [note, setNote] = useState("");
  if (!draft) return null;

  const returned = draft.status === "changes_requested";

  return (
    <div
      className={`card draft-card ${returned ? "returned" : ""}`}
      id="draft-review"
    >
      <div className="card-head">
        <span className={`icon draft-icon ${returned ? "returned" : ""}`}>
          {returned ? (
            <MessageSquareWarning size={18} />
          ) : (
            <ClipboardCheck size={18} />
          )}
        </span>
        <h2>{returned ? "Changes Requested" : "Your Review"}</h2>
        <span className="spacer" />
        <span
          className={`badge ${returned ? "returned-badge" : "draft-badge"}`}
        >
          {returned ? "sent back" : "draft"} · iteration {draft.iteration}
        </span>
      </div>

      <div className="card-body draft-body">
        {returned && (
          <div className="rework-note">
            <b>{draft.approver || "Test Lead"} asked for changes:</b>
            <p>{draft.feedback}</p>
          </div>
        )}

        <p className="draft-hint">
          {returned ? (
            <>
              Reopen the test steps to edit them, then regenerate. The new draft
              starts at iteration {(draft.iteration || 1) + 1} and goes back to
              the Test Lead only when you submit it.
            </>
          ) : (
            <>
              Review the generated script above. When you&apos;re satisfied,
              submit it to the <b>Test Lead</b> for approval — it isn&apos;t
              visible to them until you do.
            </>
          )}
        </p>

        {!returned && (
          <input
            className="draft-note"
            type="text"
            value={note}
            placeholder="Note for the reviewer (optional)…"
            onChange={(e) => setNote(e.target.value)}
          />
        )}

        <div className="draft-actions">
          {returned ? (
            <button
              className="btn btn-primary revise-btn"
              disabled={busy}
              onClick={() => onReviseAndRegenerate(draft.test_id)}
            >
              {busy ? (
                <Loader2 size={16} className="spin" />
              ) : (
                <PencilRuler size={15} />
              )}
              Revise & Regenerate
            </button>
          ) : (
            <button
              className="btn btn-primary submit-btn"
              disabled={busy}
              onClick={() => onSubmit(draft.test_id, note)}
            >
              {busy ? (
                <Loader2 size={16} className="spin" />
              ) : (
                <Send size={15} />
              )}
              {busy ? "Submitting…" : "Submit for Review"}
            </button>
          )}

          <button
            className="btn btn-ghost discard-btn"
            disabled={busy}
            onClick={() => onDiscard(draft.test_id)}
          >
            <Trash2 size={14} /> Discard
          </button>

          <span className="draft-meta">
            {returned
              ? "Opens the test steps for editing"
              : `${draft.step_count} steps · ${draft.file_name || draft.test_id}`}
          </span>
        </div>
      </div>
    </div>
  );
}
