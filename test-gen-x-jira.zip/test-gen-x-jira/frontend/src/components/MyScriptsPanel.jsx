import {
  FolderGit2,
  FileEdit,
  Clock3,
  BadgeCheck,
  MessageSquareWarning,
  RefreshCw,
  Undo2,
  ArrowRightToLine,
  FileCode2,
  CheckCheck,
} from "lucide-react";

function ago(iso) {
  if (!iso) return "";
  const s = Math.max(
    1,
    Math.round((Date.now() - new Date(iso).getTime()) / 1000),
  );
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

const STATE = {
  draft: { label: "draft", icon: FileEdit, cls: "draft" },
  pending: { label: "in review", icon: Clock3, cls: "" },
  changes_requested: {
    label: "changes requested",
    icon: MessageSquareWarning,
    cls: "returned",
  },
  approved: { label: "approved", icon: BadgeCheck, cls: "ok" },
};

/**
 * TEST ENGINEER · "My Scripts".
 *
 * Delta: an OPEN change request is shown only while `status ===
 * "changes_requested"`. Once the engineer regenerates, the backend clears
 * `feedback` and the card reverts to a plain draft — the amber quote strip
 * disappears. A small "feedback addressed" chip replaces it so the request
 * looks resolved rather than silently vanished.
 */
export default function MyScriptsPanel({
  items = [],
  activeTestId = null,
  loading = false,
  onOpen,
  onWithdraw,
  onRefresh,
}) {
  // Badge counts OPEN change requests first, then drafts needing attention.
  const returned = items.filter((i) => i.status === "changes_requested").length;
  const drafts = items.filter((i) => i.status === "draft").length;
  const badge = returned || drafts;

  return (
    <div className="card queue-card my-scripts-card">
      <div className="card-head">
        <span className="icon queue-icon">
          <FolderGit2 size={17} />
        </span>
        <h2>My Scripts</h2>
        <span className="spacer" />
        {badge > 0 && (
          <span
            className={`badge queue-count ${returned ? "returned-count" : ""}`}
          >
            {badge}
          </span>
        )}
        <button
          className="queue-refresh"
          onClick={onRefresh}
          title="Refresh"
          aria-label="Refresh my scripts"
        >
          <RefreshCw size={13} className={loading ? "spin" : ""} />
        </button>
      </div>

      <div className="card-body queue-body">
        {items.length === 0 ? (
          <div className="queue-empty">
            <FileCode2 size={22} />
            <p>
              Nothing yet. Generated scripts stay here as drafts until you
              submit them for review.
            </p>
          </div>
        ) : (
          <ul className="queue-list">
            {items.map((it) => {
              const meta = STATE[it.status] || STATE.pending;
              const Icon = meta.icon;
              const isActive = it.test_id === activeTestId;
              const openable =
                it.status === "draft" || it.status === "changes_requested";

              // An OPEN request only — cleared the moment it's regenerated.
              const openRequest =
                it.status === "changes_requested" && it.feedback;
              // A RESOLVED request, shown as a quiet confirmation.
              const resolved =
                it.status !== "changes_requested" && it.addressed_feedback;

              return (
                <li
                  key={it.test_id}
                  className={`queue-item ${isActive ? "active" : ""} ${meta.cls}`}
                >
                  <div className="q-top">
                    <span className="q-title" title={it.title}>
                      {it.title || it.file_name}
                    </span>
                    <span className={`q-pill ${meta.cls}`}>
                      <Icon size={11} /> {meta.label}
                    </span>
                  </div>

                  <div className="q-meta">
                    {it.project_name ? `${it.project_name} · ` : ""}
                    {it.step_count} steps · iter {it.iteration} ·{" "}
                    {ago(it.submitted_at || it.created_at)}
                  </div>

                  {openRequest && (
                    <div className="q-feedback" title={it.feedback}>
                      “{it.feedback}”
                    </div>
                  )}

                  {resolved && (
                    <div
                      className="q-resolved"
                      title={`Addressed: ${it.addressed_feedback}`}
                    >
                      <CheckCheck size={11} /> feedback addressed · revision{" "}
                      {it.iteration}
                    </div>
                  )}

                  {it.status === "approved" && it.approver && (
                    <div className="q-meta approved-by">
                      Approved by {it.approver}
                    </div>
                  )}

                  <div className="q-actions">
                    {openable && (
                      <button
                        className="q-pull"
                        onClick={() => onOpen(it.test_id)}
                        disabled={isActive}
                      >
                        <ArrowRightToLine size={13} />
                        {isActive
                          ? "In workspace"
                          : it.status === "changes_requested"
                            ? "Open & revise"
                            : "Open & review"}
                      </button>
                    )}
                    {it.status === "pending" && (
                      <button
                        className="q-withdraw"
                        onClick={() => onWithdraw(it.test_id)}
                        title="Pull back before the Test Lead decides"
                      >
                        <Undo2 size={13} /> Withdraw
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
