import { AlertTriangle } from "lucide-react";
export default function EvidenceModeBadge() {
  return (
    <div className="mode-badge">
      <AlertTriangle size={16} style={{ marginTop: 1, flexShrink: 0 }} />
      <div>
        <b>Simulated screenshots.</b> No live browser was available, so these
        are placeholder images — not captures of the real application. Install
        the browser runtime (<code>playwright install chromium</code>) and
        re-run to capture genuine evidence from the AUT.
      </div>
    </div>
  );
}
