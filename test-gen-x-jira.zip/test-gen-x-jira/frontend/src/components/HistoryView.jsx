import { useCallback, useEffect, useMemo, useState } from "react";
import {
  History,
  FolderKanban,
  Globe,
  FileArchive,
  Camera,
  FileText,
  Loader2,
  Search,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Code2,
} from "lucide-react";
import { listRuns, downloads, download } from "../services/api.js";
import RunDetailDrawer from "./RunDetailDrawer.jsx";

/**
 * Execution history.
 *
 * Delta alongside the drawer fix:
 *  - `openRun` now stores the test_id (a stable string) instead of a row
 *    object, and the placeholder row is looked up in a memo. Previously the
 *    `mergedRuns.find(...)` in the render body produced a NEW object every
 *    render, which re-fired the drawer's effect on each parent re-render.
 *  - ETL rows are tagged `__local` so the drawer knows there is no backend
 *    record to fetch for them.
 */
export default function HistoryView({ projects, etlRuns = [] }) {
  const [projectId, setProjectId] = useState("all");
  const [runs, setRuns] = useState(null);
  const [q, setQ] = useState("");
  const [openId, setOpenId] = useState(null);
  const [busy, setBusy] = useState(null);

  const mergedRuns = useMemo(() => {
    const backendRuns = runs || [];
    const etlNormalized = etlRuns.map((r) => ({
      ...r,
      status: String(r.status || "failed").toLowerCase(),
      created_at: r.created_at || new Date().toISOString(),
      finished_at: r.finished_at || r.created_at || new Date().toISOString(),
      // Client-side only: never try to fetch a backend detail record.
      __local: true,
    }));
    return [...backendRuns, ...etlNormalized].sort(
      (a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0),
    );
  }, [runs, etlRuns]);

  const refresh = useCallback(() => {
    setRuns(null);
    listRuns(projectId === "all" ? null : projectId)
      .then(setRuns)
      .catch(() => setRuns([]));
  }, [projectId]);

  useEffect(refresh, [refresh]);

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t
      ? mergedRuns.filter(
          (r) =>
            (r.title || "").toLowerCase().includes(t) ||
            (r.project_name || "").toLowerCase().includes(t),
        )
      : mergedRuns;
  }, [mergedRuns, q]);

  const stats = useMemo(() => {
    const l = filtered || [];
    return {
      total: l.length,
      passed: l.filter((r) => r.status === "passed").length,
      failed: l.filter((r) => r.status === "failed").length,
      evidence: l.reduce((a, r) => a + (r.evidence_count || 0), 0),
    };
  }, [filtered]);

  // Stable placeholder for the drawer — recomputed only when the selection
  // or the underlying list actually changes.
  const openRow = useMemo(
    () =>
      openId ? mergedRuns.find((r) => r.test_id === openId) || null : null,
    [openId, mergedRuns],
  );

  const proj = projects.find((p) => p.id === projectId);

  const bulk = async (key, url, filename) => {
    setBusy(key);
    try {
      await download(url, filename);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="history">
      <div className="history-toolbar">
        <div className="history-title">
          <History size={20} /> <h2>Execution History</h2>
        </div>
        <div className="history-filters">
          <div className="search-box">
            <Search size={15} />
            <input
              placeholder="Search by title or project…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <select
            className="proj-dd"
            value={projectId}
            onChange={(e) => setProjectId(e.target.value)}
          >
            <option value="all">All projects</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {projectId !== "all" && proj && (
        <div className="bulk-bar">
          <div className="bulk-info">
            <FolderKanban size={16} />
            <div>
              <b>{proj.name}</b>
              <span>
                <Globe size={11} /> {proj.aut_url}
              </span>
            </div>
          </div>
          <div className="bulk-actions">
            <button
              className="dl-btn primary"
              disabled={busy}
              onClick={() =>
                bulk(
                  "s",
                  downloads.projectScripts(projectId),
                  `${proj.name}_scripts.zip`,
                )
              }
            >
              {busy === "s" ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <Code2 size={15} />
              )}{" "}
              All scripts
            </button>
            <button
              className="dl-btn"
              disabled={busy}
              onClick={() =>
                bulk(
                  "e",
                  downloads.projectEvidence(projectId),
                  `${proj.name}_evidence.zip`,
                )
              }
            >
              {busy === "e" ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <Camera size={15} />
              )}{" "}
              All evidence
            </button>
            <button
              className="dl-btn"
              disabled={busy}
              onClick={() =>
                bulk(
                  "r",
                  downloads.projectResults(projectId),
                  `${proj.name}_results.zip`,
                )
              }
            >
              {busy === "r" ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <FileArchive size={15} />
              )}{" "}
              All results
            </button>
            <button
              className="dl-btn"
              disabled={busy}
              onClick={() =>
                bulk(
                  "p",
                  downloads.projectReports(projectId, "pdf"),
                  `${proj.name}_reports.zip`,
                )
              }
            >
              {busy === "p" ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <FileText size={15} />
              )}{" "}
              All reports (PDF)
            </button>
          </div>
        </div>
      )}

      <div className="metrics history-metrics">
        <div className="metric">
          <div className="n">{stats.total}</div>
          <div className="l">Runs</div>
        </div>
        <div className="metric ok">
          <div className="n">{stats.passed}</div>
          <div className="l">Passed</div>
        </div>
        <div className="metric bad">
          <div className="n">{stats.failed}</div>
          <div className="l">Failed</div>
        </div>
        <div className="metric">
          <div className="n">{stats.evidence}</div>
          <div className="l">Screenshots</div>
        </div>
      </div>

      <div className="card">
        {runs === null && mergedRuns.length === 0 ? (
          <div className="drawer-loading">
            <Loader2 size={22} className="spin" /> Loading history…
          </div>
        ) : filtered.length === 0 ? (
          <div className="empty">
            <div className="ico">
              <History size={28} />
            </div>
            <h3>No runs yet</h3>
            <p>
              Head to the <b>Studio</b> or <b>Backend ETL Studio</b> tab and run
              your first test.
            </p>
          </div>
        ) : (
          <table className="run-table">
            <thead>
              <tr>
                <th>Status</th>
                <th>Title</th>
                <th>Project</th>
                <th>Lang</th>
                <th>Checks</th>
                <th>Evidence</th>
                <th>When</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.test_id} onClick={() => setOpenId(r.test_id)}>
                  <td>
                    <span className={`status-pill ${r.status}`}>
                      {r.status === "passed" || r.status === "pass" ? (
                        <CheckCircle2 size={12} />
                      ) : (
                        <XCircle size={12} />
                      )}{" "}
                      {r.status}
                    </span>
                  </td>
                  <td className="cell-title">{r.title}</td>
                  <td className="cell-muted">{r.project_name || "—"}</td>
                  <td>
                    <span className="lang-pill">{r.language}</span>
                  </td>
                  <td className="cell-muted">
                    {r.passed}/{r.total}
                  </td>
                  <td className="cell-muted">{r.evidence_count}</td>
                  <td className="cell-muted">
                    {new Date(r.created_at).toLocaleString()}
                  </td>
                  <td className="cell-arrow">
                    <ChevronRight size={16} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {openId && (
        <RunDetailDrawer
          key={openId}
          testId={openId}
          initialRun={openRow}
          onClose={() => setOpenId(null)}
        />
      )}
    </div>
  );
}
