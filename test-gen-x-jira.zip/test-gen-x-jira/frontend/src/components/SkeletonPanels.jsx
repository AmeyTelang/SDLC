import { Code2, ClipboardCheck, Loader2, Cpu } from "lucide-react";

function Line({ w = "100%" }) {
  return <div className="skel skel-line" style={{ width: w }} />;
}

export function GenerationSkeleton() {
  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Cpu size={18} />
        </span>
        <h2>Agent X · Test Script Generator</h2>
        <span className="skel-head-spin">
          <Loader2 size={14} className="spin" /> generating test script…
        </span>
      </div>
      <div className="card-body">
        <div className="skel skel-code" />
        <div style={{ marginTop: 14 }}>
          <Line w="40%" />
          <Line w="85%" />
          <Line w="70%" />
        </div>
      </div>
    </div>
  );
}

export function ExecutionSkeleton() {
  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Cpu size={18} />
        </span>
        <h2>Agent Y · Test Script Executor & Validator</h2>
        <span className="skel-head-spin">
          <Loader2 size={14} className="spin" /> executing test…
        </span>
      </div>
      <div className="card-body">
        <div className="skel skel-verdict" />
        <div className="skel-metrics">
          <div className="skel skel-metric" />
          <div className="skel skel-metric" />
          <div className="skel skel-metric" />
          <div className="skel skel-metric" />
        </div>
        {[0, 1, 2].map((i) => (
          <div className="skel-row" key={i}>
            <div className="skel skel-dot" />
            <div className="skel-flex">
              <Line w={`${80 - i * 12}%`} />
            </div>
          </div>
        ))}
        <div style={{ marginTop: 14 }}>
          <Line w="30%" />
          <Line w="95%" />
          <Line w="88%" />
        </div>
      </div>
    </div>
  );
}
