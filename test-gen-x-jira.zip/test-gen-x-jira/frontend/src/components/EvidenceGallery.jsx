import { useEffect, useState, useCallback } from "react";
import { createPortal } from "react-dom";
import {
  Camera,
  CheckCircle2,
  XCircle,
  X,
  Download,
  ImageOff,
  AlertTriangle,
} from "lucide-react";
import { evidenceImg } from "../services/api.js";

export default function EvidenceGallery({ evidence = [], mode }) {
  const [active, setActive] = useState(null);
  const open = active !== null;

  const close = useCallback(() => setActive(null), []);
  const prev = useCallback(() => setActive((a) => (a > 0 ? a - 1 : a)), []);
  const next = useCallback(
    () => setActive((a) => (a < evidence.length - 1 ? a + 1 : a)),
    [evidence.length],
  );

  // Lock page scroll + keyboard nav while the lightbox is open.
  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") close();
      else if (e.key === "ArrowLeft") prev();
      else if (e.key === "ArrowRight") next();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKey);
    };
  }, [open, close, prev, next]);

  if (!evidence.length) {
    return (
      <div className="evidence-empty">
        <ImageOff size={18} /> No screenshots were captured for this run.
      </div>
    );
  }
  const src = (e) => evidenceImg(e.url);
  const cur = open ? evidence[active] : null;

  const lightbox = open ? (
    <div className="lightbox" onClick={close} role="dialog" aria-modal="true">
      <div className="lightbox-inner" onClick={(e) => e.stopPropagation()}>
        <div className="lightbox-bar">
          <span>
            Step {cur.step_index} · {cur.step_name}
            <span
              className={`shot-badge ${cur.status}`}
              style={{ marginLeft: 10 }}
            >
              {cur.status}
            </span>
          </span>
          <div style={{ display: "flex", gap: 8 }}>
            <a className="lb-btn" href={src(cur)} download={cur.file_name}>
              <Download size={15} /> Download
            </a>
            <button className="lb-btn" onClick={close}>
              <X size={15} />
            </button>
          </div>
        </div>
        <div className="lightbox-stage">
          {/* key forces a clean swap between images (no half-loaded flash) */}
          <img
            key={cur.file_name}
            src={src(cur)}
            alt={cur.step_name}
            draggable={false}
          />
        </div>
        <div className="lightbox-nav">
          <button disabled={active === 0} onClick={prev}>
            ← Prev
          </button>
          <span>
            {active + 1} / {evidence.length}
          </span>
          <button disabled={active === evidence.length - 1} onClick={next}>
            Next →
          </button>
        </div>
      </div>
    </div>
  ) : null;

  return (
    <div className="evidence">
      {mode === "simulated" && (
        <div className="mode-warn">
          <AlertTriangle size={16} style={{ flexShrink: 0, marginTop: 1 }} />
          <div>
            <b>Simulated screenshots.</b> No live browser was available, so
            these are placeholders — not the real app. Install the browser
            runtime (<code>playwright install chromium</code>) and re-run to
            capture genuine AUT evidence.
          </div>
        </div>
      )}
      <div className="evidence-head">
        <Camera size={15} />
        <span>
          Test Evidence · {evidence.length} screenshot
          {evidence.length > 1 ? "s" : ""}
        </span>
        <span className="evidence-hint">click a thumbnail to enlarge</span>
      </div>
      <div className="evidence-grid">
        {evidence.map((e, i) => (
          <figure
            key={e.file_name}
            className={`shot ${e.status}`}
            onClick={() => setActive(i)}
          >
            <div className="shot-img">
              <img
                src={src(e)}
                alt={e.step_name}
                loading="lazy"
                draggable={false}
              />
              <span className={`shot-badge ${e.status}`}>
                {e.status === "passed" ? (
                  <CheckCircle2 size={12} />
                ) : (
                  <XCircle size={12} />
                )}
                {e.status}
              </span>
            </div>
            <figcaption>
              <b>Step {e.step_index}</b> · {e.step_name}
            </figcaption>
          </figure>
        ))}
      </div>
      {/* Portal to <body> so the overlay escapes transformed/blurred ancestors. */}
      {open && createPortal(lightbox, document.body)}
    </div>
  );
}
