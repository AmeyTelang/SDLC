import { useState } from "react";
import {
  Code2,
  Copy,
  Check,
  ShieldCheck,
  Download,
  Bot,
  Cpu,
} from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { atomDark } from "react-syntax-highlighter/dist/esm/styles/prism";

export default function ScriptViewer({ gen }) {
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState("steps");

  const copy = async () => {
    await navigator.clipboard.writeText(gen.script);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const download = () => {
    const blob = new Blob([gen.script], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = gen.file_name;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Cpu size={18} />
        </span>
        <h2>Agent X · Test Script Generated</h2>
        <span className="sub">
          <span
            className="agent-tag"
            style={{ background: "rgba(110,168,255,.16)", color: "#6ea8ff" }}
          >
            <Bot size={11} style={{ verticalAlign: "-1px" }} />
            {gen.generated_by === "llm" ? "LLM" : "LLM"}
          </span>
        </span>
      </div>
      <div className="tabs">
        <button
          className={tab === "steps" ? "active" : ""}
          onClick={() => setTab("steps")}
        >
          Structured Steps
        </button>
        <button
          className={tab === "script" ? "active" : ""}
          onClick={() => setTab("script")}
        >
          Playwright Script
        </button>
      </div>
      <div className="card-body" style={{ height: "500px", overflow: "auto" }}>
        {tab === "script" ? (
          <div className="code-wrap">
            <SyntaxHighlighter
              language="python"
              style={atomDark}
              customStyle={{ margin: 0, padding: "1rem" }}
            >
              {gen.script}
            </SyntaxHighlighter>
            <div
              style={{
                position: "absolute",
                top: 10,
                right: 10,
                display: "flex",
                gap: 8,
              }}
            >
              <button className="copy-btn" onClick={copy}>
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? "Copied" : "Copy"}
              </button>
              <button className="copy-btn" onClick={download}>
                <Download size={14} /> {gen.file_name.split(".").pop()}
              </button>
            </div>
          </div>
        ) : (
          <ul className="steps">
            {gen.structured_steps.map((s) => (
              <li key={s.index} className="step-item">
                <span className="step-num">{s.index}</span>
                <div>
                  <div className="txt">{s.action}</div>
                  {s.expectation && (
                    <span className="exp">
                      <ShieldCheck size={13} /> assertion: {s.expectation}
                    </span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
