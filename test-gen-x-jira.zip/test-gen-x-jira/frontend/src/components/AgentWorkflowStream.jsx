import {
  Bot,
  PlayCircle,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  FileSearch,
  ListChecks,
  FileCode2,
  Rocket,
  Network,
  Camera,
  Gauge,
  Flag,
  XCircle,
  ShieldCheck,
  PauseCircle,
  UserCheck,
  ClipboardCheck,
  ArrowRightToLine,
  RotateCcw,
  Send,
} from "lucide-react";

const AGENT_LABEL = {
  generation: "Gen Agent",
  execution: "Exec Agent",
  orchestrator: "Orchestrator",
  approval: "Review",
};

const AGENT_COLOR = {
  generation: "#6ea8ff",
  execution: "#b78cff",
  orchestrator: "#ff8fa3",
  approval: "#fbbf24",
};

const FAIL_COLOR = "#ff6b81";
const HOLD_COLOR = "#fbbf24";
const DARK_ICON = "#0a0e1a";

// Phases that pause the pipeline awaiting a human.
const HOLD_PHASES = ["draft", "await", "review", "submitted"];
// Phases that end the run without executing.
const STOP_PHASES = ["sent_back", "rejected"];

function eventIcon(ev) {
  const m = (ev.message || "").toLowerCase();
  if (ev.phase === "error") return AlertTriangle;
  if (ev.agent === "approval") {
    if (ev.phase === "approved") return UserCheck;
    if (ev.phase === "sent_back") return RotateCcw;
    if (ev.phase === "rejected") return XCircle;
    if (ev.phase === "draft") return ClipboardCheck;
    if (ev.phase === "submitted") return Send;
    if (ev.phase === "review") return ArrowRightToLine;
    return ShieldCheck;
  }
  if (ev.phase === "rework") return RotateCcw;
  if (m.includes("withheld") || m.includes("paused")) return PauseCircle;
  if (m.includes("parsing")) return FileSearch;
  if (m.includes("distilling") || m.includes("structured")) return ListChecks;
  if (m.includes("produced") || m.includes("script")) return FileCode2;
  if (m.includes("writing") || m.includes("launching")) return Rocket;
  if (m.includes("capturing") || m.includes("screenshot")) return Camera;
  if (m.includes("analysis") || m.includes("verdict")) return Gauge;
  if (m.includes("finished")) return Flag;
  if (ev.phase === "done") return CheckCircle2;
  if (ev.phase === "start") return PlayCircle;
  return Bot;
}

function hexToRgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
}

export default function AgentWorkflowStream({
  events,
  progress,
  running = false,
  awaitingApproval = false,
}) {
  const finished = events.some(
    (e) => e.agent === "orchestrator" && e.phase === "end",
  );
  const failedRun = events.some(
    (e) =>
      e.agent === "orchestrator" &&
      e.phase === "end" &&
      /FAILED/i.test(e.message || ""),
  );
  const isDraft = events.some(
    (e) => e.agent === "approval" && e.phase === "draft",
  );
  const sentBack = events.some(
    (e) => e.agent === "approval" && e.phase === "sent_back",
  );

  const badge = sentBack
    ? { label: "Sent back", hold: true, icon: RotateCcw }
    : awaitingApproval
      ? { label: "Awaiting review", hold: true, icon: PauseCircle }
      : isDraft && !running
        ? { label: "Draft", hold: true, icon: ClipboardCheck }
        : { label: "Live", hold: false, icon: null };

  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <Network size={18} />
        </span>
        <h2>Agent Workflow Stream</h2>
        <span className="spacer" />
        {badge.hold ? (
          <span className="badge gate-badge">
            {badge.icon ? <badge.icon size={12} /> : null} {badge.label}
          </span>
        ) : (
          <span className="badge live">Live</span>
        )}
      </div>

      <div className="card-body">
        <div className="wf-progress">
          <span
            style={{ width: `${progress}%` }}
            className={badge.hold ? "hold" : "done"}
          />
        </div>

        <div className="wf-timeline">
          {events.length === 0 && (
            <div className="wf-empty">
              Waiting to start… run the agents to watch generation, review and
              execution live.
            </div>
          )}

          {events.map((ev, i) => {
            const Icon = eventIcon(ev);
            const isLast = i === events.length - 1;
            const isError = ev.phase === "error";
            const isHold =
              ev.agent === "approval" && HOLD_PHASES.includes(ev.phase);
            const isStop =
              ev.agent === "approval" && STOP_PHASES.includes(ev.phase);
            const active =
              isLast && running && !finished && !isError && !isHold;
            const terminalFail =
              isLast && finished && failedRun && ev.agent === "orchestrator";
            const base = AGENT_COLOR[ev.agent] || "#8a93ad";

            // A send-back is a routing outcome, not a failure — amber, not red.
            const showFail = isError || terminalFail || ev.phase === "rejected";

            const color = showFail
              ? FAIL_COLOR
              : isHold || isStop
                ? HOLD_COLOR
                : active
                  ? "#22d3ee"
                  : "#34d399";

            const dotStyle =
              isHold || isStop
                ? {
                    background: HOLD_COLOR,
                    borderColor: HOLD_COLOR,
                    color: DARK_ICON,
                    boxShadow: `0 0 0 5px ${hexToRgba(HOLD_COLOR, 0.18)}`,
                  }
                : active
                  ? {
                      background: color,
                      borderColor: color,
                      color: DARK_ICON,
                      boxShadow: `0 0 0 5px ${hexToRgba(color, 0.16)}`,
                    }
                  : showFail
                    ? {
                        background: FAIL_COLOR,
                        borderColor: FAIL_COLOR,
                        color: "#fff",
                      }
                    : {
                        background: color,
                        borderColor: color,
                        color: DARK_ICON,
                      };

            return (
              <div
                key={i}
                className={`wf-node ${active ? "active" : ""} ${
                  isHold || isStop ? "hold" : ""
                }`}
              >
                <div className="wf-rail">
                  <span className="wf-dot" style={dotStyle}>
                    {isStop ? (
                      <RotateCcw size={13} />
                    ) : isHold ? (
                      <PauseCircle size={14} />
                    ) : active ? (
                      <Loader2 size={13} className="spin" />
                    ) : showFail ? (
                      <XCircle size={13} />
                    ) : (
                      <CheckCircle2 size={14} />
                    )}
                  </span>
                  {!isLast && (
                    <span
                      className="wf-connector"
                      style={{ background: hexToRgba(color, 0.35) }}
                    />
                  )}
                </div>

                <div className="wf-content">
                  <div className="wf-row">
                    <span
                      className="agent-tag"
                      style={{ background: hexToRgba(base, 0.16), color: base }}
                    >
                      {AGENT_LABEL[ev.agent] || ev.agent}
                    </span>
                    <span className={`wf-phase ${ev.phase}`}>{ev.phase}</span>
                  </div>
                  <div className="wf-msg">
                    <Icon size={15} className="wf-msg-ico" />
                    <span>{ev.message}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
