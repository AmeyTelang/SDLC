import { Send, Clock3, BadgeCheck, RefreshCw, FileCode2 } from "lucide-react";

function ago(iso) {
  if (!iso) return "";
  const s = Math.max(
    1,
    Math.round((Date.now() - new Date(iso).getTime()) / 1000),
  );
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

/**
 * TEST ENGINEER · read-only list of scripts sent for Test Lead review.
 * Deliberately has no pull / approve / discard actions.
 */
export default function SubmittedPanel({ items = [], onRefresh }) {
  const pending = items.filter((i) => i.status === "pending").length;

  return (
    <div className="card queue-card submitted-card">
      <div className="card-head">
        <span className="icon queue-icon">
          <Send size={17} />
        </span>
        <h2>Sent for Review</h2>
        <span className="spacer" />
        {pending > 0 && <span className="badge queue-count">{pending}</span>}
        <button
          className="queue-refresh"
          onClick={onRefresh}
          aria-label="Refresh"
        >
          <RefreshCw size={13} />
        </button>
      </div>

      <div className="card-body queue-body">
        {items.length === 0 ? (
          <div className="queue-empty">
            <FileCode2 size={22} />
            <p>
              Nothing submitted yet. Generated scripts are sent to your Test
              Lead for approval.
            </p>
          </div>
        ) : (
          <ul className="queue-list">
            {items.map((it) => {
              const approved = it.status === "approved";
              return (
                <li key={it.test_id} className="queue-item readonly">
                  <div className="q-top">
                    <span className="q-title" title={it.title}>
                      {it.title || it.file_name}
                    </span>
                    <span className={`q-pill ${approved ? "ok" : ""}`}>
                      {approved ? (
                        <>
                          <BadgeCheck size={11} /> approved
                        </>
                      ) : (
                        <>
                          <Clock3 size={11} /> in review
                        </>
                      )}
                    </span>
                  </div>
                  <div className="q-meta">
                    {it.project_name ? `${it.project_name} · ` : ""}
                    {it.step_count} steps · iter {it.iteration} ·{" "}
                    {ago(it.requested_at)}
                  </div>
                  <div className="q-meta">
                    {approved && it.approver
                      ? `Approved by ${it.approver}`
                      : "Awaiting Test Lead"}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
