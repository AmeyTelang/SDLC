// API helper for the Xray Validation tab.
// Point API_BASE at wherever the router is mounted in TestGenX.
const API_BASE = import.meta?.env?.VITE_XRAY_API_BASE || "/api/xray-validation";

async function post(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok)
    throw new Error(data?.detail || `Request failed (${res.status})`);
  return data;
}

export const xrayApi = {
  health: async () => {
    const res = await fetch(`${API_BASE}/health`);
    return res.json();
  },
  // fetch rules/LOVs from the story + the attached Xray steps
  load: (story_key, test_key, jira_secret) =>
    post("/load", { story_key, test_key, jira_secret }),
  // run steps against rules/LOVs, get an Xray-importable result
  validate: (story_description, xray_steps, test_key, prefer_ai = true) =>
    post("/validate", { story_description, xray_steps, test_key, prefer_ai }),
  // push a result back into Xray
  import: (result, jira_secret) => post("/import", { result, jira_secret }),
  // one-shot: load + validate + optional import
  run: (story_key, test_key, prefer_ai, do_import, jira_secret) =>
    post("/run", { story_key, test_key, prefer_ai, do_import, jira_secret }),
};
