import React, { useState } from "react";
import {
  Download,
  Search,
  Sparkles,
  PlayCircle,
  UploadCloud,
  CheckCircle2,
  XCircle,
  Loader2,
  FileCode2,
  ListChecks,
  Database,
  GitBranch,
  Copy,
  FileDown,
  Scale,
  Rocket,
  Cpu,
  Radio,
  Circle,
  ArrowRightLeft,
  PenLine,
  Boxes,
  CircleDot,
} from "lucide-react";
import { xrayApi } from "./api.js";
import "./XrayValidationTab.css";

export default function XrayValidationTab() {
  const [mode, setMode] = useState("jira"); // 'manual' | 'jira'
  const [projectId, setProjectId] = useState("");
  const [storyKey, setStoryKey] = useState("");
  const [spec, setSpec] = useState(null);
  const [script, setScript] = useState(null);
  const [scriptTab, setScriptTab] = useState("script");
  const [execution, setExecution] = useState(null);
  const [pushResult, setPushResult] = useState(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [stream, setStream] = useState([]);

  const log = (agent, status, text) =>
    setStream((s) => [...s, { agent, status, text }]);

  const run = async (fn, key) => {
    setBusy(key);
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy("");
    }
  };

  const doImport = () =>
    run(async () => {
      setStream([]);
      log(
        "orch",
        "START",
        `Workflow started · engine: Mistral LLM · story: ${storyKey}`,
      );
      log("gen", "READ", "Generation Agent: reading JIRA story description…");
      const s = await xrayApi.importStory(storyKey.trim());
      log(
        "gen",
        "PROCESS",
        "Generation Agent: extracting business rules & LOVs…",
      );
      setSpec(s);
      setScript(null);
      setExecution(null);
      setPushResult(null);
    }, "import");

  const doGenerate = () =>
    run(async () => {
      log(
        "gen",
        "PROCESS",
        "Generation Agent: synthesizing Playwright SQL test…",
      );
      const g = await xrayApi.generate(spec);
      log(
        "gen",
        "ARTIFACT",
        `Generation Agent: produced ${(g.test_steps || []).length} steps + SQL script.`,
      );
      log(
        "gen",
        "HANDSHAKE",
        "Generation Agent: complete. Handing off to Execution Agent.",
      );
      setScript(g);
      setExecution(null);
      setPushResult(null);
    }, "generate");

  const doExecute = () =>
    run(async () => {
      log(
        "exec",
        "START",
        "Execution Agent: running SQL against target table…",
      );
      const r = await xrayApi.execute(script);
      log(
        "exec",
        "ARTIFACT",
        `Execution Agent: ${r.overall_status} — ${r.passed}/${r.passed + r.failed} checks passed.`,
      );
      log("exec", "DONE", "Execution Agent: analysis complete.");
      setExecution(r);
      setPushResult(null);
    }, "execute");

  const doPush = () =>
    run(async () => {
      log(
        "exec",
        "PROCESS",
        "Execution Agent: creating Xray Test & pushing results…",
      );
      const p = await xrayApi.push(storyKey.trim(), execution, script);
      log(
        "orch",
        "END",
        `Workflow finished · Xray ${p.test_key} · verdict: ${execution.overall_status}`,
      );
      setPushResult(p);
    }, "push");

  const started = stream.length > 0;

  return (
    <div className="xvt xvt-grid">
      {/* ---------------- LEFT: Source ---------------- */}
      <div>
        <div className="segment">
          <button
            className={mode === "manual" ? "active" : ""}
            onClick={() => setMode("manual")}
          >
            <PenLine size={15} /> Manual
          </button>
          <button
            className={mode === "jira" ? "active" : ""}
            onClick={() => setMode("jira")}
          >
            <Boxes size={15} /> JIRA
          </button>
        </div>

        <div className="card">
          <div className="card-title">
            <Download size={16} /> Import from JIRA
            <span className="spacer" />
            <span className="badge cyan">Cloud</span>
          </div>

          <div className="two-col">
            <div className="field">
              <label className="field-label">Project ID</label>
              <input
                className="input"
                placeholder="ETL"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
              />
            </div>
            <div className="field">
              <label className="field-label">Story Key</label>
              <input
                className="input"
                placeholder="ETL-123"
                value={storyKey}
                onChange={(e) => setStoryKey(e.target.value)}
              />
            </div>
          </div>

          <button
            className="btn"
            disabled={!storyKey || busy}
            onClick={doImport}
          >
            {busy === "import" ? (
              <Loader2 size={16} className="spin" />
            ) : (
              <Search size={16} />
            )}
            Find Business Rules & LOVs
          </button>

          {spec && (
            <div className="jira-item">
              <div className="row">
                <span className="key">{spec.story_key}</span>
                <span className="badge amber">Imported</span>
                <span className="spacer" style={{ marginLeft: "auto" }} />
                <span className="badge cyan">
                  {(spec.business_rules || []).length} rules
                </span>
              </div>
              <div className="title">
                {spec.summary || "ETL transformation validation"}
              </div>
            </div>
          )}
        </div>

        {spec && (
          <div className="card">
            <div className="card-title">
              <ListChecks size={16} /> Extracted Spec
            </div>
            <div className="grid2">
              <div className="spec-box">
                <div className="lbl">
                  <Database size={13} /> Source Table
                </div>
                <div className="val">{spec.source_table || "—"}</div>
              </div>
              <div className="spec-box">
                <div className="lbl">
                  <ArrowRightLeft size={13} /> Target Table
                </div>
                <div className="val">{spec.target_table || "—"}</div>
              </div>
            </div>

            <div className="section-label">
              <Scale size={12} style={{ verticalAlign: -2 }} /> Business Rules
            </div>
            <ul className="list">
              {(spec.business_rules || []).map((r, i) => (
                <li key={r.id || i}>
                  <span className="rnum">{i + 1}</span> {r.description}
                </li>
              ))}
            </ul>

            <div className="section-label">LOV Mappings</div>
            <table className="tbl">
              <thead>
                <tr>
                  <th>Field</th>
                  <th>Source</th>
                  <th>Target</th>
                </tr>
              </thead>
              <tbody>
                {(spec.lovs || []).map((l, idx) => (
                  <tr key={idx}>
                    <td>{l.field}</td>
                    <td className="mono">{l.source_value}</td>
                    <td className="mono">{l.target_value}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <button className="btn mt" disabled={busy} onClick={doGenerate}>
              {busy === "generate" ? (
                <Loader2 size={16} className="spin" />
              ) : (
                <Sparkles size={16} />
              )}
              Generate SQL Test (Mistral AI)
            </button>
          </div>
        )}
      </div>

      {/* ---------------- CENTER: Agents ---------------- */}
      <div>
        {error && (
          <div className="alert error">
            <XCircle size={16} /> {error}
          </div>
        )}

        {!spec && !script && !busy && (
          <div className="card hero">
            <div className="rocket">
              <Rocket size={30} />
            </div>
            <h3>Agentic ETL Validation</h3>
            <p>
              Import a <b>JIRA story</b>, and run. <b>Generation Agent</b>{" "}
              synthesizes a Playwright SQL test from the business rules & LOVs;{" "}
              <b>Execution Agent</b> validates the target table, and on success
              an <b>Xray Test</b> is created under the story with steps &
              results.
            </p>
          </div>
        )}

        {/* ---- Generation Agent panel ---- */}
        {(busy === "generate" || script) && (
          <div className="card">
            <div className="card-title">
              <Cpu size={16} /> Generation Agent · SQL Test Generator
              <span className="spacer" />
              {busy === "generate" ? (
                <span className="agent-status">
                  <Loader2 size={14} className="spin" /> generating…
                </span>
              ) : (
                <span className="badge purple">LLM</span>
              )}
            </div>

            {busy === "generate" && !script ? (
              <div className="waiting">
                <div className="wait-head">
                  <Loader2 size={14} className="spin" /> Waiting for generation…
                </div>
                <div className="skel-line w60" />
                <div className="skel-block" />
                <div className="skel-line w40" />
                <div className="skel-grid">
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                </div>
              </div>
            ) : (
              script && (
                <>
                  <div className="subtabs">
                    <button
                      className={`subtab ${scriptTab === "script" ? "active" : ""}`}
                      onClick={() => setScriptTab("script")}
                    >
                      Playwright SQL
                    </button>
                    <button
                      className={`subtab ${scriptTab === "steps" ? "active" : ""}`}
                      onClick={() => setScriptTab("steps")}
                    >
                      Structured Steps
                    </button>
                  </div>

                  {scriptTab === "script" ? (
                    <>
                      <div className="code-head">
                        <FileCode2 size={13} />{" "}
                        <span className="small">
                          {spec?.target_table || "target"}_validation.sql
                        </span>
                        <span
                          className="spacer"
                          style={{ marginLeft: "auto" }}
                        />
                        <button className="btn ghost sm">
                          <Copy size={13} /> Copy
                        </button>
                        <button className="btn ghost sm">
                          <FileDown size={13} /> .sql
                        </button>
                      </div>
                      <pre className="code">{script.sql_script}</pre>
                    </>
                  ) : (
                    <table className="tbl">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Action</th>
                          <th>Data (SQL)</th>
                          <th>Expected</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(script.test_steps || []).map((s) => (
                          <tr key={s.index}>
                            <td>{s.index}</td>
                            <td>{s.action}</td>
                            <td className="mono small">{s.data}</td>
                            <td className="small">{s.expected_result}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}

                  <button
                    className="btn mt"
                    disabled={busy}
                    onClick={doExecute}
                  >
                    {busy === "execute" ? (
                      <Loader2 size={16} className="spin" />
                    ) : (
                      <PlayCircle size={16} />
                    )}
                    Execute Against Target Table
                  </button>
                </>
              )
            )}
          </div>
        )}

        {/* ---- Execution Agent panel ---- */}
        {(busy === "execute" || execution) && (
          <div className="card">
            <div className="card-title">
              <PlayCircle size={16} /> Execution Agent · Executor & Validator
              <span className="spacer" />
              {busy === "execute" ? (
                <span className="agent-status">
                  <Loader2 size={14} className="spin" /> executing test…
                </span>
              ) : (
                <span className="badge green">LLM Verdict</span>
              )}
            </div>

            {busy === "execute" && !execution ? (
              <div className="waiting">
                <div className="wait-head">
                  <Loader2 size={14} className="spin" /> Waiting for execution…
                </div>
                <div className="skel-block tall" />
                <div className="skel-grid">
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                  <div className="skel-tile" />
                </div>
                <div className="skel-line w80" />
                <div className="skel-line w60" />
              </div>
            ) : (
              execution && (
                <>
                  <div
                    className={`verdict-banner ${execution.overall_status === "PASS" ? "" : "bad"}`}
                  >
                    <div className="ic">
                      {execution.overall_status === "PASS" ? (
                        <CheckCircle2 size={18} />
                      ) : (
                        <XCircle size={18} />
                      )}
                    </div>
                    <div>
                      <div className="t">
                        {execution.overall_status === "PASS"
                          ? "Passed"
                          : "Failed"}
                      </div>
                      <div className="s">
                        {execution.passed}/{execution.passed + execution.failed}{" "}
                        checks passed
                      </div>
                    </div>
                  </div>

                  <div className="stats">
                    <div className="stat total">
                      <div className="num">
                        {execution.passed + execution.failed}
                      </div>
                      <div className="lab">Total</div>
                    </div>
                    <div className="stat pass">
                      <div className="num">{execution.passed}</div>
                      <div className="lab">Passed</div>
                    </div>
                    <div className="stat fail">
                      <div className="num">{execution.failed}</div>
                      <div className="lab">Failed</div>
                    </div>
                    <div className="stat evi">
                      <div className="num">
                        {(script?.test_steps || []).length}
                      </div>
                      <div className="lab">Steps</div>
                    </div>
                  </div>

                  <table className="tbl">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Action</th>
                        <th>Expected</th>
                        <th>Actual</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(execution.step_results || []).map((s) => (
                        <tr key={s.index}>
                          <td>{s.index}</td>
                          <td>{s.action}</td>
                          <td className="small">{s.expected_result}</td>
                          <td className="mono small">{s.actual_result}</td>
                          <td>
                            <span
                              className={`pill ${s.status === "PASS" ? "ok" : s.status === "ERROR" ? "err" : "bad"}`}
                            >
                              {s.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <button
                    className="btn mt"
                    disabled={busy || execution.overall_status !== "PASS"}
                    onClick={doPush}
                    title={
                      execution.overall_status !== "PASS"
                        ? "Push enabled only on successful validation"
                        : ""
                    }
                  >
                    {busy === "push" ? (
                      <Loader2 size={16} className="spin" />
                    ) : (
                      <UploadCloud size={16} />
                    )}
                    Create Xray Task & Push Results
                  </button>

                  {pushResult && (
                    <div className="alert success mt">
                      <GitBranch size={16} />
                      Created Xray Test <b>
                        &nbsp;{pushResult.test_key}&nbsp;
                      </b>{" "}
                      (Execution {pushResult.test_execution_key}).{" "}
                      <a href={pushResult.url} target="_blank" rel="noreferrer">
                        Open in JIRA
                      </a>
                    </div>
                  )}
                </>
              )
            )}
          </div>
        )}
      </div>

      {/* ---------------- RIGHT: Agent Workflow Stream ---------------- */}
      <div>
        <div className="card">
          <div className="card-title">
            <Radio size={16} /> Agent Workflow Stream
            <span className="spacer" />
            {started && <span className="badge live">Live</span>}
          </div>

          {!started ? (
            <div className="empty">
              The live agent workflow will appear here when you run a
              validation.
            </div>
          ) : (
            <>
              <div className={`stream-bar ${busy ? "active" : ""}`} />
              <div className="stream">
                {stream.map((w, i) => {
                  const cls = w.agent;
                  // The final item is "in progress" while a task is running.
                  const inProgress = busy && i === stream.length - 1;
                  const label =
                    w.agent === "orch"
                      ? "ORCHESTRATOR"
                      : w.agent === "gen"
                        ? "GEN AGENT"
                        : "EXEC AGENT";
                  const StepIcon =
                    w.agent === "orch"
                      ? Circle
                      : w.agent === "gen"
                        ? Cpu
                        : PlayCircle;
                  return (
                    <div
                      className={`wf-item ${inProgress ? "in-progress" : "done"}`}
                      key={i}
                    >
                      <div
                        className={`wf-dot ${cls} ${inProgress ? "loading" : ""}`}
                      >
                        {inProgress ? (
                          <Loader2 size={13} className="spin" />
                        ) : (
                          <CheckCircle2 size={13} />
                        )}
                      </div>
                      <div className="wf-body">
                        <div className="wf-tags">
                          <span className={`wf-agent ${cls}`}>{label}</span>
                          <span
                            className={`wf-status ${inProgress ? "running" : ""}`}
                          >
                            {w.status}
                          </span>
                        </div>
                        <div
                          className={`wf-text ${inProgress ? "strong" : ""}`}
                        >
                          <StepIcon size={13} className="wf-line-ic" /> {w.text}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
