import { useState } from "react";
import { FolderKanban, Globe, Plus, X, Check, Loader2 } from "lucide-react";
import { createProject } from "../services/api.js";

export default function ProjectSelector({
  projects,
  selectedId,
  onSelect,
  onCreated,
}) {
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", aut_url: "", description: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const selected = projects.find((p) => p.id === selectedId);

  const submit = async () => {
    if (!form.name.trim() || !form.aut_url.trim()) {
      setErr("Name and AUT URL are required.");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const p = await createProject(form);
      setForm({ name: "", aut_url: "", description: "" });
      setAdding(false);
      onCreated?.(p);
    } catch (e) {
      setErr(e.message || "Failed to create project");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="card">
      <div className="card-head">
        <span className="icon">
          <FolderKanban size={18} />
        </span>
        <h2>Project</h2>
        {!adding && (
          <button className="mini-btn" onClick={() => setAdding(true)}>
            <Plus size={14} /> New
          </button>
        )}
      </div>
      <div className="card-body">
        {!adding ? (
          <>
            <label className="field">
              Select a project (Application-Under-Test)
            </label>
            <div className="proj-select">
              {projects.map((p) => (
                <button
                  key={p.id}
                  className={`proj-chip ${p.id === selectedId ? "active" : ""}`}
                  onClick={() => onSelect(p.id)}
                >
                  <span className="proj-name">{p.name}</span>
                  <span className="proj-url">
                    <Globe size={11} /> {p.aut_url.replace(/^https?:\/\//, "")}
                  </span>
                  {p.run_count > 0 && (
                    <span className="proj-count">{p.run_count} runs</span>
                  )}
                </button>
              ))}
            </div>
            {selected && (
              <div className="aut-banner">
                <Globe size={14} />
                <div>
                  <b>AUT URL</b>
                  <span>{selected.aut_url}</span>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="proj-form">
            <div className="field-group">
              <label className="field">Project name</label>
              <input
                type="text"
                value={form.name}
                placeholder="e.g. Patient Portal"
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="field-group">
              <label className="field">Application-Under-Test (AUT) URL</label>
              <input
                type="text"
                value={form.aut_url}
                placeholder="https://app.example.com"
                onChange={(e) => setForm({ ...form, aut_url: e.target.value })}
              />
            </div>
            <div className="field-group">
              <label className="field">Description (optional)</label>
              <input
                type="text"
                value={form.description}
                placeholder="Short description"
                onChange={(e) =>
                  setForm({ ...form, description: e.target.value })
                }
              />
            </div>
            {err && <div className="report-error">{err}</div>}
            <div className="proj-form-actions">
              <button
                className="btn btn-primary"
                onClick={submit}
                disabled={busy}
              >
                {busy ? (
                  <Loader2 size={15} className="spin" />
                ) : (
                  <Check size={15} />
                )}{" "}
                Create
              </button>
              <button
                className="btn btn-ghost"
                onClick={() => {
                  setAdding(false);
                  setErr(null);
                }}
              >
                <X size={15} /> Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
