import { useCallback, useEffect, useRef, useState } from "react";
import {
  X,
  Copy,
  Check,
  Loader2,
  AlertTriangle,
  FileCode2,
  ListChecks,
  Camera,
  RefreshCw,
} from "lucide-react";
import { getRun } from "../services/api.js";
import EvidenceGallery from "./EvidenceGallery.jsx";
import DownloadBar from "./DownloadBar.jsx";

/**
 * Run detail drawer.
 *
 * FIX — the drawer used to early-return whenever `initialRun` was supplied:
 *
 *     setRun(initialRun || null);
 *     if (initialRun) return;            // <- never fetched the detail
 *     getRun(testId).then(setRun);
 *
 * The history table always passes the table row, and that row comes from the
 * LIST endpoint, which is a summary projection: it carries `evidence_count`
 * but not `evidence`, and no `script`, `step_results` or `analysis` at all.
 * So the header and tabs rendered from the summary while every tab body came
 * up blank.
 *
 * Now `initialRun` is treated purely as an optimistic placeholder so the
 * header paints instantly, and the full record is always fetched unless the
 * object is already hydrated. The fetched detail is MERGED over the summary,
 * and a failed fetch keeps the partial data and says so instead of blanking.
 */

/** Does this object already carry detail fields, or is it a list summary? */
function isHydrated(r) {
  if (!r || r.error) return false;
  return (
    typeof r.script === "string" ||
    Array.isArray(r.step_results) ||
    Array.isArray(r.evidence) ||
    typeof r.analysis === "string"
  );
}

export default function RunDetailDrawer({ testId, initialRun, onClose }) {
  const [run, setRun] = useState(initialRun || null);
  const [tab, setTab] = useState("script");
  const [copied, setCopied] = useState(false);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailError, setDetailError] = useState(null);

  // Keep the latest placeholder without making it an effect dependency —
  // the history table rebuilds that object on every render, which would
  // otherwise re-fire the effect in a loop.
  const initialRef = useRef(initialRun);
  initialRef.current = initialRun;

  const loadDetail = useCallback(async (id, { force = false } = {}) => {
    if (!id) return;
    const placeholder = initialRef.current;

    // ETL runs live only in client state — there is no backend record to
    // fetch, so asking for one would 404 and show a spurious error.
    if (placeholder?.__local) {
      setRun(placeholder);
      return;
    }

    if (!force && isHydrated(placeholder)) {
      setRun(placeholder);
      return;
    }

    setLoadingDetail(true);
    setDetailError(null);
    try {
      const full = await getRun(id);
      if (!full || full.error) throw new Error("Run not found in the store.");
      // Merge so list-only fields (e.g. project_name) survive.
      setRun((prev) => ({ ...(prev || {}), ...full }));
    } catch (e) {
      setDetailError(
        e?.message || "Could not load the full run detail for this test.",
      );
      // Keep whatever we already had; only blank out if we had nothing.
      setRun((prev) => prev || { error: true });
    } finally {
      setLoadingDetail(false);
    }
  }, []);

  useEffect(() => {
    setRun(initialRef.current || null);
    setTab("script");
    loadDetail(testId);
    // testId is the only real identity here.
  }, [testId, loadDetail]);

  const copy = async () => {
    if (!run?.script) return;
    await navigator.clipboard.writeText(run.script);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const evidence = Array.isArray(run?.evidence) ? run.evidence : [];
  const steps = Array.isArray(run?.step_results) ? run.step_results : [];
  // Prefer the real array length once hydrated; fall back to the summary count.
  const evidenceCount = evidence.length || run?.evidence_count || 0;

  const empty = (Icon, title, detail) => (
    <div className="drawer-empty">
      <Icon size={22} />
      <b>{title}</b>
      <span>{detail}</span>
      {detailError && (
        <button
          className="drawer-retry"
          onClick={() => loadDetail(testId, { force: true })}
        >
          <RefreshCw size={13} /> Retry
        </button>
      )}
    </div>
  );

  return (
    <div className="drawer-overlay" onClick={onClose}>
      <aside className="drawer" onClick={(e) => e.stopPropagation()}>
        <div className="drawer-head">
          <div>
            <h3>{run?.title || "Loading…"}</h3>
            {run && !run.error && (
              <span className="drawer-sub">
                <span className={`status-pill ${run.status}`}>
                  {run.status}
                </span>
                {run.project_name && ` · ${run.project_name}`} · {run.language}{" "}
                · {evidenceCount} evidence · {run.evidence_mode}
                {loadingDetail && (
                  <span className="drawer-loading-chip">
                    <Loader2 size={11} className="spin" /> loading detail…
                  </span>
                )}
              </span>
            )}
          </div>
          <button className="lb-btn" onClick={onClose}>
            <X size={16} />
          </button>
        </div>

        {!run ? (
          <div className="drawer-loading">
            <Loader2 size={22} className="spin" /> Loading run…
          </div>
        ) : run.error ? (
          <div className="drawer-loading">Run not found.</div>
        ) : (
          <>
            {detailError && (
              <div className="drawer-error">
                <AlertTriangle size={14} />
                <span>{detailError}</span>
                <button onClick={() => loadDetail(testId, { force: true })}>
                  <RefreshCw size={13} /> Retry
                </button>
              </div>
            )}

            <div className="tabs">
              <button
                className={tab === "script" ? "active" : ""}
                onClick={() => setTab("script")}
              >
                Script
              </button>
              <button
                className={tab === "steps" ? "active" : ""}
                onClick={() => setTab("steps")}
              >
                Result
              </button>
              <button
                className={tab === "evidence" ? "active" : ""}
                onClick={() => setTab("evidence")}
              >
                Evidence ({evidenceCount})
              </button>
            </div>

            <div className="drawer-body">
              {tab === "script" &&
                (loadingDetail && !run.script ? (
                  <div className="drawer-loading">
                    <Loader2 size={20} className="spin" /> Loading script…
                  </div>
                ) : run.script ? (
                  <div className="code-wrap">
                    <pre className="code">{run.script}</pre>
                    <button
                      className="copy-btn"
                      style={{ position: "absolute", top: 10, right: 10 }}
                      onClick={copy}
                    >
                      {copied ? <Check size={14} /> : <Copy size={14} />}
                      {copied ? "Copied" : "Copy"}
                    </button>
                  </div>
                ) : (
                  empty(
                    FileCode2,
                    "No script on this run",
                    "The stored record has no `script` field. Use the downloads below to fetch the generated file.",
                  )
                ))}

              {tab === "steps" &&
                (loadingDetail && !steps.length ? (
                  <div className="drawer-loading">
                    <Loader2 size={20} className="spin" /> Loading results…
                  </div>
                ) : steps.length || run.analysis ? (
                  <>
                    {run.analysis && (
                      <div className="analysis" style={{ marginBottom: 14 }}>
                        <span className="tag">AI Verdict</span>
                        {run.analysis}
                      </div>
                    )}
                    <ul className="steps">
                      {steps.map((s, i) => (
                        <li key={i} className="step-item">
                          <span
                            className="step-num"
                            style={{
                              background:
                                s.status === "passed"
                                  ? "var(--ok)"
                                  : "var(--fail)",
                            }}
                          >
                            {s.status === "passed" ? "✓" : "✕"}
                          </span>
                          <div>
                            <div className="txt">{s.name}</div>
                            {s.message && (
                              <span
                                className="exp"
                                style={{ color: "var(--fail)" }}
                              >
                                {s.message}
                              </span>
                            )}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </>
                ) : (
                  empty(
                    ListChecks,
                    "No step results on this run",
                    "The stored record has no `step_results` or `analysis`.",
                  )
                ))}

              {tab === "evidence" &&
                (loadingDetail && !evidence.length ? (
                  <div className="drawer-loading">
                    <Loader2 size={20} className="spin" /> Loading evidence…
                  </div>
                ) : evidence.length ? (
                  <EvidenceGallery
                    evidence={evidence}
                    mode={run.evidence_mode}
                  />
                ) : (
                  empty(
                    Camera,
                    "No evidence attached",
                    run.evidence_count
                      ? `The run reports ${run.evidence_count} screenshots but the record returned none — try Retry, or download the evidence bundle.`
                      : "This run captured no screenshots.",
                  )
                ))}

              <div className="drawer-downloads">
                <DownloadBar testId={run.test_id || testId} title={run.title} />
              </div>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
