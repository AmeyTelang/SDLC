import { useCallback, useEffect, useState } from "react";
import { Coins, Cpu, DollarSign, RefreshCw, Layers, Hash } from "lucide-react";
import {
  getUsageList,
  getUsageModules,
  getUsageSummary,
} from "../../services/usageApi.js";
import "./TokenUsage.css";

const fmtTokens = (n) => (n ?? 0).toLocaleString();
const fmtCost = (n) => `$${Number(n ?? 0).toFixed(4)}`;
const fmtWhen = (iso) => {
  if (!iso) return "";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
};

/**
 * TokenUsagePage — shared, module-aware AI token & cost dashboard.
 * Rendered as a top-level header view ("Token Usage"). Both ETL Validation
 * and Web Studio calls are aggregated here; filter by module to drill in.
 *
 * Props:
 *   refreshKey  (number) optional — bump to force a reload after an AI run.
 */
export default function TokenUsagePage({ refreshKey = 0 }) {
  const [modules, setModules] = useState([]); // [{id,label}]
  const [module, setModule] = useState("all"); // "all" | "etl" | "web-studio"
  const [summary, setSummary] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const labelFor = useCallback(
    (id) => modules.find((m) => m.id === id)?.label || id,
    [modules],
  );

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const mod = module === "all" ? undefined : module;
      const [sum, list] = await Promise.all([
        getUsageSummary({ module: mod }),
        getUsageList({ module: mod, limit: 300 }),
      ]);
      setSummary(sum);
      setItems(list.items || []);
    } catch (e) {
      setError(e.message || "Failed to load usage");
    } finally {
      setLoading(false);
    }
  }, [module]);

  useEffect(() => {
    getUsageModules()
      .then((r) => setModules(r.modules || []))
      .catch(() => setModules([]));
  }, []);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  return (
    <div className="tup-page">
      <div className="tup-page__head">
        <div className="tup-page__title">
          <span className="tup-page__icon">
            <Coins size={20} />
          </span>
          <div>
            <h2>Token Usage & Cost</h2>
            <p>AI token consumption and USD cost across TestGenX modules.</p>
          </div>
        </div>

        <div className="tup-page__controls">
          <div className="tup-seg" role="tablist" aria-label="Module filter">
            <button
              role="tab"
              aria-selected={module === "all"}
              className={module === "all" ? "active" : ""}
              onClick={() => setModule("all")}
            >
              <Layers size={14} /> All
            </button>
            {modules.map((m) => (
              <button
                key={m.id}
                role="tab"
                aria-selected={module === m.id}
                className={module === m.id ? "active" : ""}
                onClick={() => setModule(m.id)}
              >
                {m.label}
              </button>
            ))}
          </div>
          <button
            className="tup-refresh"
            onClick={load}
            disabled={loading}
            title="Refresh"
          >
            <RefreshCw size={15} className={loading ? "tup-spin" : ""} />
          </button>
        </div>
      </div>

      {error && <div className="tup-error">{error}</div>}

      {/* KPI cards */}
      <div className="tup-cards">
        <div className="tup-card">
          <span className="tup-card__label">
            <Cpu size={13} /> Total tokens
          </span>
          <span className="tup-card__value">
            {fmtTokens(summary?.total_tokens)}
          </span>
          <span className="tup-card__sub">
            in {fmtTokens(summary?.prompt_tokens)} · out{" "}
            {fmtTokens(summary?.completion_tokens)}
          </span>
        </div>
        <div className="tup-card">
          <span className="tup-card__label">
            <DollarSign size={13} /> Total cost
          </span>
          <span className="tup-card__value tup-accent">
            {fmtCost(summary?.total_cost)}
          </span>
          <span className="tup-card__sub">{summary?.calls ?? 0} AI calls</span>
        </div>
        <div className="tup-card">
          <span className="tup-card__label">
            <Hash size={13} /> Avg cost / call
          </span>
          <span className="tup-card__value">
            {fmtCost(
              summary && summary.calls ? summary.total_cost / summary.calls : 0,
            )}
          </span>
          <span className="tup-card__sub">
            {module === "all" ? "all modules" : labelFor(module)}
          </span>
        </div>
      </div>

      {/* Per-module breakdown (only meaningful when viewing All) */}
      {module === "all" && summary?.by_module?.length > 0 && (
        <div className="tup-panel">
          <h3 className="tup-panel__title">By module</h3>
          <div className="tup-bars">
            {summary.by_module.map((m) => {
              const pct =
                summary.total_cost > 0
                  ? Math.max(4, (m.total_cost / summary.total_cost) * 100)
                  : 0;
              return (
                <div className="tup-bar" key={m.module}>
                  <div className="tup-bar__top">
                    <span className="tup-pill">{m.label || m.module}</span>
                    <span className="tup-bar__meta">
                      {fmtTokens(m.total_tokens)} tok · {m.calls} calls
                    </span>
                    <span className="tup-bar__cost tup-accent">
                      {fmtCost(m.total_cost)}
                    </span>
                  </div>
                  <div className="tup-bar__track">
                    <div
                      className="tup-bar__fill"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Per call-type breakdown */}
      {summary?.by_call_type?.length > 0 && (
        <div className="tup-panel">
          <h3 className="tup-panel__title">By operation</h3>
          <div className="tup-bytype">
            {summary.by_call_type.map((t) => (
              <div
                className="tup-bytype__row"
                key={`${t.module}-${t.call_type}`}
              >
                <span className="tup-pill tup-pill--soft">
                  {labelFor(t.module)}
                </span>
                <span className="tup-bytype__op">{t.call_type}</span>
                <span>{fmtTokens(t.total_tokens)} tokens</span>
                <span className="tup-bytype__cost tup-accent">
                  {fmtCost(t.total_cost)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Per-call log */}
      <div className="tup-panel" style={{ height: "500px", overflow: "auto" }}>
        <h3 className="tup-panel__title">Recent AI calls</h3>
        <div className="tup-table-wrap">
          <table className="tup-table">
            <thead>
              <tr>
                <th>When</th>
                <th>Module</th>
                <th>Operation</th>
                <th>Model</th>
                <th>Story</th>
                <th className="tup-num">In</th>
                <th className="tup-num">Out</th>
                <th className="tup-num">Total</th>
                <th className="tup-num">Cost</th>
              </tr>
            </thead>
            <tbody>
              {items.length === 0 && !loading && (
                <tr>
                  <td colSpan={9} className="tup-empty">
                    No AI calls recorded yet.
                  </td>
                </tr>
              )}
              {items.map((r) => (
                <tr key={r.id}>
                  <td className="tup-when">{fmtWhen(r.created_at)}</td>
                  <td>
                    <span className="tup-pill tup-pill--soft">
                      {labelFor(r.module)}
                    </span>
                  </td>
                  <td>{r.call_type}</td>
                  <td className="tup-muted">{r.model}</td>
                  <td className="tup-muted">{r.story_key || "—"}</td>
                  <td className="tup-num">{fmtTokens(r.prompt_tokens)}</td>
                  <td className="tup-num">{fmtTokens(r.completion_tokens)}</td>
                  <td className="tup-num">{fmtTokens(r.total_tokens)}</td>
                  <td className="tup-num tup-accent">
                    {fmtCost(r.total_cost)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
