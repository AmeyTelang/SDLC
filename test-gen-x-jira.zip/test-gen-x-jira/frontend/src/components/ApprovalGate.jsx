import { useState } from "react";
import {
  ShieldCheck,
  ThumbsUp,
  RotateCcw,
  Loader2,
  UserCheck,
  PauseCircle,
  X,
  History,
} from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

const ACTION_LABEL = {
  generated: "generated",
  submitted: "submitted for review",
  sent_back: "sent back for regeneration",
  approved: "approved",
  rejected: "rejected",
  withdrawn: "withdrawn",
  executed: "executed",
};

/**
 * TEST LEAD · review gate.
 *
 * Two outcomes: approve (releases Agent Y) or send back for regeneration
 * with mandatory feedback. Sending back is NOT terminal — the script returns
 * to the engineer, who revises and resubmits.
 */
export default function ApprovalGate({
  gate,
  onApprove,
  onSendBack,
  onClose,
  busy = false,
}) {
  const [comment, setComment] = useState("");
  const [mode, setMode] = useState(null); // null | "sendback"
  const [showHistory, setShowHistory] = useState(false);
  const { user } = useAuth();

  if (!gate) return null;

  const history = gate.history || [];
  const resubmitted = (gate.iteration || 1) > 1;
  const canSendBack = mode === "sendback" && comment.trim().length > 0;

  return (
    <div className="card approval-card" id="approval-gate">
      <div className="card-head">
        <span className="icon approval-icon">
          <ShieldCheck size={18} />
        </span>
        <h2>Review & Approve</h2>
        <span className="spacer" />
        <span className="badge gate-badge">
          <PauseCircle size={12} /> Hand-off paused
        </span>
        <button
          className="gate-close"
          onClick={onClose}
          title="Return to queue without deciding"
          aria-label="Return to queue"
        >
          <X size={14} />
        </button>
      </div>

      <div className="card-body approval-body">
        <p className="approval-note">
          Reviewing <b>{gate.title || "this test"}</b>
          {gate.step_count ? ` · ${gate.step_count} steps` : ""}
          {gate.iteration ? ` · iteration ${gate.iteration}` : ""}
          {gate.requested_by ? (
            <>
              {" "}
              · submitted by <b>{gate.requested_by}</b>
            </>
          ) : null}
          . Approving records your decision as <b>{user?.name}</b> and releases{" "}
          <b>Agent Y</b>. Sending it back returns it to the engineer to revise.
        </p>

        {resubmitted && (
          <div className="resubmit-note">
            Resubmitted after your earlier feedback — this is revision{" "}
            {gate.iteration}.
          </div>
        )}

        {history.length > 0 && (
          <>
            <button
              className="history-toggle"
              onClick={() => setShowHistory((v) => !v)}
            >
              <History size={13} />
              {showHistory ? "Hide" : "Show"} review history ({history.length})
            </button>
            {showHistory && (
              <ul className="review-history">
                {history.map((h, i) => (
                  <li key={i}>
                    <span className={`rh-dot ${h.action}`} />
                    <span className="rh-text">
                      <b>{h.actor}</b> {ACTION_LABEL[h.action] || h.action}
                      <i> · iter {h.iteration}</i>
                      {h.comment && (
                        <span className="rh-comment">“{h.comment}”</span>
                      )}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </>
        )}

        <input
          className="approval-comment"
          type="text"
          value={comment}
          placeholder={
            mode === "sendback"
              ? "What needs to change? (required)"
              : "Reviewer comment (optional)…"
          }
          onChange={(e) => setComment(e.target.value)}
        />

        {mode === "sendback" && !comment.trim() && (
          <p className="sendback-hint">
            Tell the engineer what to fix — this is sent back with the script.
          </p>
        )}

        <div className="approval-actions">
          {mode === "sendback" ? (
            <>
              <button
                className="btn sendback-btn"
                disabled={busy || !canSendBack}
                onClick={() => onSendBack(gate.test_id, comment.trim())}
              >
                {busy ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <RotateCcw size={15} />
                )}
                {busy ? "Sending back…" : "Send back for regeneration"}
              </button>
              <button
                className="btn btn-ghost"
                disabled={busy}
                onClick={() => setMode(null)}
              >
                Cancel
              </button>
            </>
          ) : (
            <>
              <button
                className="btn btn-primary approve-btn"
                disabled={busy}
                onClick={() => onApprove(gate.test_id, comment)}
              >
                {busy ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <ThumbsUp size={16} />
                )}
                {busy ? "Releasing to Agent Y…" : "Approve & Execute"}
              </button>
              <button
                className="btn btn-ghost sendback-toggle"
                disabled={busy}
                onClick={() => setMode("sendback")}
              >
                <RotateCcw size={15} /> Send back
              </button>
            </>
          )}

          <span className="approval-meta">
            <UserCheck size={13} /> {gate.file_name || gate.test_id}
          </span>
        </div>
      </div>
    </div>
  );
}
