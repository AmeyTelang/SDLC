import { useEffect, useRef, useState } from "react";
import {
  History,
  Bot,
  Globe,
  DatabaseZap,
  Coins,
  ShieldCheck,
  ScrollText,
  LogOut,
  ChevronDown,
  Ticket,
} from "lucide-react";

import NotificationCenter from "./NotificationCenter.jsx";
import { useAuth } from "../context/AuthContext.jsx";

/**
 * Navigation, gated by capability.
 *
 * `authoring` (Test Case Studio) sits on "story.import", which BOTH roles
 * hold - the engineer authors there, the lead approves and creates the JIRA
 * test there. It leads the order because it is the upstream step: a story
 * becomes a test case, the test case becomes an Xray test, and only then is it
 * imported into the Web Studio to generate a script.
 *
 * `audit` sits on "audit.view", also held by both, and is placed last as a
 * cross-cutting governance surface rather than a step in either flow.
 */
const NAV = [
  {
    id: "authoring",
    label: "Test Case Lab",
    icon: Ticket,
    cap: "story.import",
  },
  { id: "studio", label: "Web Studio", icon: Globe, cap: "test.generate" },
  {
    id: "review",
    label: "Review & Approve",
    icon: ShieldCheck,
    cap: "review.approve",
  },
  { id: "etl", label: "ETL Studio", icon: DatabaseZap, cap: null },
  { id: "usage", label: "Token Usage", icon: Coins, cap: "usage.view" },
  { id: "history", label: "Run History", icon: History, cap: "history.view" },
  { id: "audit", label: "Audit Trail", icon: ScrollText, cap: "audit.view" },
];

function initialsOf(user) {
  return (user?.name || user?.email || "?")
    .split(/[\s.@]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

export default function Header({ view, setView, onOpenApproval }) {
  const { user, logout, can, isLead } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const onDocumentDown = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", onDocumentDown);
    return () => document.removeEventListener("mousedown", onDocumentDown);
  }, []);

  const items = NAV.filter((item) => !item.cap || can(item.cap));
  const initials = initialsOf(user);
  const year = new Date().getFullYear();

  return (
    <header className="header">
      <div className="brand">
        <div className="brand-mark">
          <Bot size={22} strokeWidth={2.2} />
        </div>
        <div>
          <h1>TestGenX</h1>
          <p>Test Automation Prototype</p>
        </div>
      </div>

      <nav className="nav">
        {items.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={view === id ? "active" : ""}
            onClick={() => setView(id)}
          >
            <Icon size={16} /> {label}
          </button>
        ))}
      </nav>

      <div className="header-right">
        <span
          className="header-copyright"
          title={`© ${year} Tata Consultancy Services · All rights reserved.`}
        >
          © {year} Tata Consultancy Services
          <br />
          All rights reserved
        </span>

        {isLead && <NotificationCenter onOpenApproval={onOpenApproval} />}

        <div className="user-menu" ref={menuRef}>
          <button className="user-btn" onClick={() => setMenuOpen((v) => !v)}>
            <span className={`avatar ${isLead ? "lead" : ""}`}>{initials}</span>
            <span className="user-meta">
              <b>{user?.name}</b>
              <i>{user?.role_label}</i>
            </span>
            <ChevronDown size={14} />
          </button>

          {menuOpen && (
            <div className="user-panel">
              <div className="user-panel-head">
                <span className={`avatar lg ${isLead ? "lead" : ""}`}>
                  {initials}
                </span>
                <div>
                  <b>{user?.name}</b>
                  <span>{user?.email}</span>
                </div>
              </div>
              <button className="user-logout" onClick={logout}>
                <LogOut size={15} /> Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
