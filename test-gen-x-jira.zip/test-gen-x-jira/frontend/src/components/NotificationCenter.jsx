import { useEffect, useRef, useState } from "react";
import { Bell, CheckCircle2, ShieldCheck, X } from "lucide-react";
import { useNotifications } from "../context/NotificationsContext.jsx";

function ago(d) {
  const s = Math.max(
    1,
    Math.round((Date.now() - new Date(d).getTime()) / 1000),
  );
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}

/** Test Lead only — push feed for scripts awaiting review. */
export default function NotificationCenter({ onOpenApproval }) {
  const { items, unread, markAllRead, clear } = useNotifications();
  const [open, setOpen] = useState(false);
  const [pulse, setPulse] = useState(false);
  const ref = useRef(null);
  const lastCount = useRef(0);

  useEffect(() => {
    if (items.length > lastCount.current) {
      setPulse(true);
      const t = setTimeout(() => setPulse(false), 2200);
      lastCount.current = items.length;
      return () => clearTimeout(t);
    }
    lastCount.current = items.length;
  }, [items.length]);

  useEffect(() => {
    const onDoc = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const toggle = () =>
    setOpen((v) => {
      if (!v) markAllRead();
      return !v;
    });

  return (
    <div className="notif" ref={ref}>
      <button
        className={`notif-btn ${pulse ? "pulse" : ""}`}
        onClick={toggle}
        aria-label={`Notifications${unread ? ` (${unread} unread)` : ""}`}
        title="Notifications"
      >
        <Bell size={18} />
        {unread > 0 && (
          <span className="notif-badge">{unread > 9 ? "9+" : unread}</span>
        )}
      </button>

      {open && (
        <div className="notif-panel" role="menu">
          <div className="notif-head">
            <span>
              <Bell size={14} /> Notifications
            </span>
            <button
              className="notif-clear"
              onClick={clear}
              aria-label="Clear all"
            >
              <X size={14} />
            </button>
          </div>

          <div className="notif-list">
            {items.length === 0 && (
              <div className="notif-empty">
                You&apos;re all caught up. Scripts awaiting your review will
                appear here.
              </div>
            )}
            {items.map((n) => (
              <button
                key={n.id}
                className={`notif-item ${n.read ? "" : "unread"}`}
                onClick={() => {
                  setOpen(false);
                  onOpenApproval?.(n.testId);
                }}
              >
                <span
                  className={`notif-ico ${n.kind === "approved" ? "ok" : "gate"}`}
                >
                  {n.kind === "approved" ? (
                    <CheckCircle2 size={14} />
                  ) : (
                    <ShieldCheck size={14} />
                  )}
                </span>
                <span className="notif-text">
                  <b>{n.title}</b>
                  <span>{n.body}</span>
                  <i>{ago(n.at)}</i>
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
