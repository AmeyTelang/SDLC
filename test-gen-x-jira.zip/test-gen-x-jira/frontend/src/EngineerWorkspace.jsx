import { useCallback, useEffect, useRef, useState } from "react";
import {
  Rocket,
  Pen,
  PencilRuler,
  Network,
  Ticket,
  PenLine,
  Inbox,
} from "lucide-react";
import ProjectSelector from "./components/ProjectSelector.jsx";
import NewTestCard from "./components/NewTestCard.jsx";
import Modal from "./components/Modal.jsx";
import TestStepsInput from "./components/TestStepsInput.jsx";
import AgentWorkflowStream from "./components/AgentWorkflowStream.jsx";
import ScriptViewer from "./components/ScriptViewer.jsx";
import JiraImport from "./components/JiraImport.jsx";
import MyScriptsPanel from "./components/MyScriptsPanel.jsx";
import DraftReviewCard from "./components/DraftReviewCard.jsx";
import { GenerationSkeleton } from "./components/SkeletonPanels.jsx";
import { listProjects } from "./services/api.js";
import {
  runGenerationStream,
  listMyScripts,
  fetchMyScript,
  submitForReview,
  withdrawSubmission,
  discardDraft,
} from "./services/approvalApi.js";
import { defaultsForProject } from "./services/projectDefaults.js";

const ENV_DEFAULT_SOURCE =
  (import.meta?.env?.VITE_DEFAULT_SOURCE || "manual").toLowerCase() === "jira"
    ? "jira"
    : "jira";
const LOCK_SOURCE =
  String(import.meta?.env?.VITE_LOCK_SOURCE || "").toLowerCase() === "true";

const BLANK_FORM = {
  title: "",
  natural_language_steps: "",
  language: "python",
};

export default function EngineerWorkspace() {
  const appliedDefaultsRef = useRef(null);

  const [source, setSource] = useState(ENV_DEFAULT_SOURCE);
  const [projects, setProjects] = useState([]);
  const [projectId, setProjectId] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [jiraIssueKey, setJiraIssueKey] = useState("");

  const [form, setForm] = useState({
    title: "Login and add to cart",
    natural_language_steps:
      "Open the application\nLogin with username standard_user and password secret_sauce\nVerify that Products is visible\nClick on Add to cart",
    language: "python",
  });

  const [rework, setRework] = useState(null);

  const [events, setEvents] = useState([]);
  const [progress, setProgress] = useState(0);
  const [gen, setGen] = useState(null);
  const [draft, setDraft] = useState(null);
  const [running, setRunning] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [banner, setBanner] = useState(null);

  const [myScripts, setMyScripts] = useState([]);
  const [scriptsLoading, setScriptsLoading] = useState(false);

  // Ids retired during this session. A slow in-flight poll can still return
  // them, so we filter defensively on every list update.
  const retiredRef = useRef(new Set());

  const loadProjects = () =>
    listProjects()
      .then((ps) => {
        setProjects(ps);
        setProjectId((cur) => cur || (ps[0]?.id ?? null));
      })
      .catch(() => setProjects([]));

  /** Apply the retired-id filter to any list before it reaches state. */
  const sanitise = useCallback(
    (list) => (list || []).filter((i) => !retiredRef.current.has(i.test_id)),
    [],
  );

  const refreshMine = useCallback(async () => {
    setScriptsLoading(true);
    try {
      setMyScripts(sanitise(await listMyScripts()));
    } catch {
      /* keep last known */
    } finally {
      setScriptsLoading(false);
    }
  }, [sanitise]);

  useEffect(() => {
    loadProjects();
    refreshMine();
    const t = setInterval(refreshMine, 20000);
    return () => clearInterval(t);
  }, [refreshMine]);

  useEffect(() => {
    if (rework) return;
    if (!projectId || appliedDefaultsRef.current === projectId) return;
    const proj = projects.find((p) => p.id === projectId);
    if (!proj) return;
    appliedDefaultsRef.current = projectId;
    const d = defaultsForProject(proj);
    if (d)
      setForm((f) => ({
        ...f,
        title: d.title,
        natural_language_steps: d.steps,
      }));
  }, [projectId, projects, rework]);

  const project = projects.find((p) => p.id === projectId) || null;

  const resetWorkspace = useCallback(() => {
    setEvents([]);
    setProgress(0);
    setGen(null);
    setDraft(null);
    setError(null);
  }, []);

  /**
   * Replace a card in the local list the instant the server confirms it, and
   * drop any ids the server says were superseded.
   *
   * Without this the resolved change request would keep showing its amber
   * state until the next 20s poll — and an orphaned record would never
   * disappear at all.
   */
  const applyDraftToList = useCallback((summary, supersededIds = []) => {
    if (!summary?.test_id) return;
    const retired = new Set(
      [...supersededIds, summary.superseded_by].filter(Boolean),
    );
    retired.forEach((id) => retiredRef.current.add(id));

    setMyScripts((prev) => {
      const kept = prev.filter(
        (i) => i.test_id !== summary.test_id && !retired.has(i.test_id),
      );
      return [summary, ...kept];
    });
  }, []);

  // ------------------------------------------------------------------
  // Generation — fired only from the steps popup
  // ------------------------------------------------------------------
  const runGeneration = async (payload) => {
    resetWorkspace();
    setBanner(null);
    setRunning(true);
    const revisingId = payload.test_id || null;

    try {
      await runGenerationStream(payload, (ev) => {
        setEvents((prev) => [...prev, ev]);
        if (typeof ev.progress === "number") setProgress(ev.progress);
        if (ev.agent === "generation" && ev.phase === "artifact" && ev.data)
          setGen(ev.data);

        if (ev.agent === "approval" && ev.phase === "draft" && ev.data) {
          const summary = ev.data.draft || null;
          setDraft(summary);
          applyDraftToList(summary, ev.data.superseded || []);
        }
      });

      setRework(null);
      await refreshMine();

      if (revisingId) {
        setBanner(
          "Script regenerated — the change request is resolved. Review the new draft, then submit it.",
        );
      }

      setTimeout(
        () =>
          document
            .getElementById("draft-review")
            ?.scrollIntoView({ behavior: "smooth", block: "center" }),
        80,
      );
    } catch (e) {
      setError(e.message || "Generation failed");
    } finally {
      setRunning(false);
    }
  };

  const onRun = async () => {
    setShowModal(false);
    const payload = { ...form, project_id: projectId };
    // Pin the record being revised so the backend increments the iteration
    // instead of creating a parallel one.
    if (rework?.test_id) payload.test_id = rework.test_id;
    await runGeneration(payload);
  };

  const openNewTest = () => {
    setRework(null);
    setForm((f) => ({ ...BLANK_FORM, language: f.language }));
    const d = project ? defaultsForProject(project) : null;
    if (d)
      setForm((f) => ({
        ...f,
        title: d.title,
        natural_language_steps: d.steps,
      }));
    setShowModal(true);
  };

  const onReviseAndRegenerate = async (testId) => {
    setBusy(true);
    setError(null);
    try {
      const item = await fetchMyScript(testId);
      const src = item.source || {};

      setForm({
        title: src.title || item.title || "",
        natural_language_steps: src.natural_language_steps || "",
        language: src.language || item.language || "python",
      });
      if (src.project_id) setProjectId(src.project_id);
      if (src.jira_issue_key) setJiraIssueKey(src.jira_issue_key);

      setRework({
        test_id: item.test_id,
        iteration: item.iteration,
        feedback: item.feedback,
        approver: item.approver,
        title: item.title,
      });
      setShowModal(true);
    } catch (e) {
      setError(e.message || "Could not load the original test steps.");
      refreshMine();
    } finally {
      setBusy(false);
    }
  };

  const onSubmit = async (testId, note) => {
    setBusy(true);
    setError(null);
    const title = draft?.title;
    try {
      const updated = await submitForReview(testId, note);
      applyDraftToList(updated);
      resetWorkspace();
      setRework(null);
      refreshMine();
      setBanner(
        `“${title}” submitted to the Test Lead. The workspace is ready for your next test case.`,
      );
    } catch (e) {
      setError(e.message || "Could not submit this script.");
    } finally {
      setBusy(false);
    }
  };

  const onWithdraw = async (testId) => {
    try {
      const updated = await withdrawSubmission(testId);
      applyDraftToList(updated);
      refreshMine();
      setBanner("Submission withdrawn — the script is a draft again.");
    } catch (e) {
      setError(e.message || "Could not withdraw this submission.");
    }
  };

  const onDiscard = async (testId) => {
    try {
      await discardDraft(testId);
      retiredRef.current.add(testId);
      setMyScripts((prev) => prev.filter((i) => i.test_id !== testId));
      resetWorkspace();
      setRework(null);
      refreshMine();
      setBanner("Draft discarded.");
    } catch (e) {
      setError(e.message || "Could not discard this draft.");
    }
  };

  const onOpen = async (testId) => {
    setBanner(null);
    setError(null);
    try {
      const item = await fetchMyScript(testId);
      if (item.status === "changes_requested") {
        await onReviseAndRegenerate(testId);
        return;
      }
      setEvents([
        {
          agent: "approval",
          phase: "draft",
          message: `Draft “${item.title}” re-opened for review.`,
          progress: 60,
        },
      ]);
      setProgress(60);
      setGen(item.artifact || null);
      setDraft(item);
      setTimeout(
        () =>
          document
            .getElementById("draft-review")
            ?.scrollIntoView({ behavior: "smooth", block: "center" }),
        80,
      );
    } catch (e) {
      setError(e.message || "Could not open this script.");
      refreshMine();
    }
  };

  const onJiraImport = (t) => {
    setRework(null);
    setForm((f) => ({
      ...f,
      title: t.summary || t.key,
      natural_language_steps:
        Array.isArray(t.steps) && t.steps.length > 0
          ? t.steps.join("\n")
          : f.natural_language_steps,
    }));
    setJiraIssueKey(t.key || "");
    setShowModal(true);
  };

  const started = events.length > 0 || running;

  return (
    <div className="container">
      <div className="grid-3">
        {/* LEFT — import / author + my scripts */}
        <aside className="col-left">
          {/* {!LOCK_SOURCE && (
            <div
              className="source-toggle"
              role="tablist"
              aria-label="Test source"
            >
              <button
                role="tab"
                aria-selected={source === "manual"}
                className={source === "manual" ? "active" : ""}
                onClick={() => setSource("manual")}
              >
                <PenLine size={14} /> Manual
              </button>
              <button
                role="tab"
                aria-selected={source === "jira"}
                className={source === "jira" ? "active" : ""}
                onClick={() => setSource("jira")}
              >
                <Ticket size={14} /> JIRA
              </button>
            </div>
          )} */}

          {source === "jira" ? (
            <JiraImport
              defaultProjectKey={project?.jira_project_key || ""}
              onImport={onJiraImport}
            />
          ) : (
            <>
              <ProjectSelector
                projects={projects}
                selectedId={projectId}
                onSelect={setProjectId}
                onCreated={(p) => {
                  setProjects((prev) => [...prev, p]);
                  setProjectId(p.id);
                }}
              />
              <NewTestCard
                project={project}
                running={running}
                onOpen={openNewTest}
              />
            </>
          )}

          <MyScriptsPanel
            items={myScripts}
            activeTestId={draft?.test_id || rework?.test_id || null}
            loading={scriptsLoading}
            onOpen={onOpen}
            onWithdraw={onWithdraw}
            onRefresh={refreshMine}
          />
        </aside>

        {/* MIDDLE — generate + self-review */}
        <main className="col-mid">
          {error && (
            <div className="card">
              <div className="card-body" style={{ color: "var(--fail)" }}>
                {error}
              </div>
            </div>
          )}

          {banner && (
            <div className="ws-banner queued">
              <Inbox size={15} />
              <span>{banner}</span>
              <button onClick={() => setBanner(null)} aria-label="Dismiss">
                ×
              </button>
            </div>
          )}

          {rework && !showModal && !running && !gen && (
            <div className="ws-banner rework-pending">
              <PencilRuler size={15} />
              <span>
                Revising <b>{rework.title}</b> — the test steps are waiting for
                your edits.
              </span>
              <button
                className="reopen-steps"
                onClick={() => setShowModal(true)}
                aria-label="Reopen steps"
              >
                Reopen steps
              </button>
            </div>
          )}

          {!started && !gen && !rework && (
            <div className="card">
              <div className="empty">
                <div className="ico">
                  <Rocket size={28} />
                </div>
                <h3>Generate a test script</h3>
                <p>
                  Import a test case from <b>JIRA</b> or author one in plain
                  English, then run <b>Agent X</b>. The script stays with you as
                  a <b>draft</b> — review it, then <b>submit it for approval</b>{" "}
                  when you&apos;re happy with it.
                </p>
              </div>
            </div>
          )}

          {gen ? <ScriptViewer gen={gen} /> : started && <GenerationSkeleton />}

          {draft && !running && (
            <DraftReviewCard
              draft={draft}
              onSubmit={onSubmit}
              onReviseAndRegenerate={onReviseAndRegenerate}
              onDiscard={onDiscard}
              busy={busy}
            />
          )}
        </main>

        {/* RIGHT — workflow stream */}
        <aside className="col-right">
          {started ? (
            <AgentWorkflowStream
              events={events}
              progress={progress}
              running={running}
              awaitingApproval={!!draft && !running}
            />
          ) : (
            <div className="card">
              <div className="card-head">
                <span className="icon">
                  <Network size={18} />
                </span>
                <h2>Agent Workflow Stream</h2>
                <span className="spacer" />
              </div>
              <div className="card-body">
                <div className="wf-idle">
                  The live agent workflow will appear here when you generate a
                  test.
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>

      <Modal
        open={showModal}
        onClose={() => setShowModal(false)}
        width={640}
        title={rework ? "Revise Test Steps & Regenerate" : "New Test"}
        icon={
          rework ? (
            <PencilRuler
              size={18}
              style={{ marginRight: 8, color: "var(--rework, #fb923c)" }}
            />
          ) : (
            <Pen
              size={18}
              style={{ marginRight: 8, color: "var(--primary)" }}
            />
          )
        }
      >
        <TestStepsInput
          form={form}
          setForm={setForm}
          onRun={onRun}
          running={running}
          project={project}
          rework={rework}
          embedded
        />
      </Modal>
    </div>
  );
}
